<?php
$api_settings =  get_option( 'nft_plugin_options' );
define('APIURL',$api_settings['api_url']);
define('APIKEY',$api_settings['apikey']);
define('TRANSACTIONURL',$api_settings['transaction_url']);
define('TRANSACTIONURLORDER',$api_settings['transaction_url_order']);
define('AccessToken',$api_settings['authorization']);
define('ContractAddress',$api_settings['contractaddress']);
define('AdminWallletAddress',$api_settings['adminwallet']);
define('CurrencyConversionApiUrl',$api_settings['currency_conversion_api_url']);
define('ScheduleEvent',$api_settings['schedule_event']);

//add_filter( 'xmlrpc_enabled', '__return_false' );
function ibid_search_filter_commerce($query) {
    if ($query->is_search && !isset($_GET['post_type'])) {
        $query->set('post_type', 'post');
    }else if ($query->is_search && isset($_GET['post_type'])){
		$search = $_GET['s'];
		$args = [
			'meta_key' 			=> 'pv_shop_name', 
  			'meta_value'   		=> $search,
			'meta_compare' => 'LIKE',
			'role' => array('vendor')
		];
		$wp_user_query = get_users( $args );
		$arrayUserID = [];
		$i = 0;
		if($wp_user_query){
			foreach($wp_user_query as $userList){
			$userData = $userList->ID;
			array_push($arrayUserID,$userData);
			
			}
		}
		//print_r($arrayUserID);
		$array = new WP_Query($query); 
		   if ($query->have_posts()){ 
		     
		   return $query;
		   }else{
			  $query->set('s', $search); 
			 // $query->set('author','4');  
		   }
		//print_r($query);
		
	}
    return $query;
}
if( !is_admin() ){
    add_filter('pre_get_posts','ibid_search_filter_commerce');
}




if (!function_exists('ibid_woocommerce_show_top_custom_block')) {
    function ibid_woocommerce_show_top_custom_block() {
        $args = array();
        global $product;
        global $ibid_redux;
        echo '<div class="thumbnail-and-details" style="position:relative;min-height:300px;">';    
                  
            wc_get_template( 'loop/sale-flash.php' );
            
            echo '<div class="overlay-container">';
                echo '<div class="thumbnail-overlay"></div>';
                echo '<div class="overlay-components">';

                    echo '<div class="component add-to-cart">';
                        woocommerce_template_loop_add_to_cart();
                    echo '</div>';

                 //    if ( class_exists( 'YITH_WCWL' ) ) {
    	            //     echo '<div class="component wishlist">';
    	            //         echo do_shortcode( "[yith_wcwl_add_to_wishlist]" );
    	            //     echo '</div>';
    	            // }

                    if (  class_exists( 'YITH_WCQV' ) ) {
                        echo '<div class="component quick-view">';
                            echo '<a href="'.esc_url('#').'" class="button yith-wcqv-button " data-tooltip="'.esc_attr__('Quickview', 'ibid').'" data-product_id="' . esc_attr(yit_get_prop( $product, 'id', true )) . '"><i class="fa fa-search"></i></a>';
                        echo '</div>';
                    }

                echo '</div>';
            echo '</div>';
		 $op = get_field('select_option', $product->get_id());
	if($op == 'video'){
		$video = get_field('add_video',$product->get_id());
		 echo '<a class="woo_catalog_media_images" title="'.the_title_attribute('echo=0').'" href="'.esc_url(get_the_permalink(get_the_ID())).'"> <video width="100%" muted loop autoplay src="' . $video . '"></video></a>';
		
	}else if($op == 'audio'){
		$audio = get_field('add_audio',$product->get_id());
		 echo '<a class="woo_catalog_media_images audioStyle" title="'.the_title_attribute('echo=0').'"><div class="ready-player-1 player" > 
		 <audio crossorigin> <source src="'.$audio.'" type="audio/mpeg"> </audio> </div></video></a>';
	}else {
	
            echo '<a class="woo_catalog_media_images" title="'.the_title_attribute('echo=0').'" href="'.esc_url(get_the_permalink(get_the_ID())).'">'.woocommerce_get_product_thumbnail();
			
                if (class_exists('ReduxFrameworkPlugin')) {
	                if (ibid_redux('ibid-archive-secondary-image-on-hover') != '0' && ibid_redux('ibid-archive-secondary-image-on-hover') != '') {
		                // SECONDARY IMAGE (FIRST IMAGE FROM WOOCOMMERCE PRODUCT GALLERY)
		                $product = new WC_Product( get_the_ID() );
		                $attachment_ids = $product->get_gallery_image_ids();

		                if ( is_array( $attachment_ids ) && !empty($attachment_ids) ) {
		                    $first_image_url = wp_get_attachment_image_url( $attachment_ids[0], 'ibid_portfolio_pic400x400' );
		                    echo '<img class="woo_secondary_media_image" src="'.esc_url($first_image_url).'" alt="'.the_title_attribute('echo=0').'" />';
		                }
	                }
                }
                if ( function_exists('modeltheme_framework') && class_exists( 'ReduxFrameworkPlugin' )) {
                    if ( $ibid_redux['ibid-countdown-status'] == true ) {
                        if ( class_exists( 'WooCommerce_simple_auction' ) ) {
                            $meta_auction_dates_to = get_post_meta( get_the_ID(), '_auction_dates_to', true );
                            $meta_auction_closed = get_post_meta( get_the_ID(), '_auction_closed', true );

                            if ($meta_auction_closed == '') {
                                if ($meta_auction_dates_to && !empty($meta_auction_dates_to)) {
                                    $date = date_create($meta_auction_dates_to);
                                    echo do_shortcode('[shortcode_countdown_v2 insert_date="'.esc_attr(date_format($date, 'Y-m-d H:i:s')).'"]');
                                }
                            }
                        }
                    }
                }
            echo '</a>';
	}
        echo '</div>';
    }
    add_action( 'woocommerce_before_shop_loop_item_title', 'ibid_woocommerce_show_top_custom_block',20 );
}

/* custom fetch function overwrite of search form */
if (!function_exists('ibid_search_form_data_fetch')) {
    add_action('wp_ajax_ibid_search_form_data_fetch' , 'ibid_search_form_data_fetch',20);
    add_action('wp_ajax_nopriv_ibid_search_form_data_fetch','ibid_search_form_data_fetch',20);
    function ibid_search_form_data_fetch(){
        if (  esc_attr( $_POST['keyword'] ) == null ) { die(); }
          	$taxnomy = $_POST['tax'];
			  echo $taxnomy;
			if($taxnomy){
				   $args =  array( 'post_type'=> 'product', 'post_per_page' =>  get_option('posts_per_page'), 'search_prod_title'=>esc_attr( $_POST['keyword'] ),'post_status' => 'publish','tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $taxnomy
			),

        ) );
			}else{
				   $args =  array( 'post_type'=> 'product', 'post_per_page' =>  get_option('posts_per_page'), 'search_prod_title'=>esc_attr( $_POST['keyword'] ),'post_status' => 'publish' ) ;
				   
			}
			add_filter( 'posts_where', 'title_filter', 10, 2 );
			$the_query = new WP_Query($args);
			remove_filter( 'posts_where', 'title_filter', 10 );
            $count_tax = 0;
			$html = '';
			$html .= '<ul class="search-result">'; 
			$dummyImage = get_site_url().'/wp-content/themes/ibidchildtheme/img/placeholderimage.png';
            if( $the_query->have_posts() ) : 
                          
                     while( $the_query->have_posts() ): $the_query->the_post(); 
					 $post_type = get_post_type_object( get_post_type() ); 
                      $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),'ibid_post_widget_pic70x70' );  
$stock = get_post_meta( get_the_ID() , '_stock_status', true );
						if($stock != 'outofstock'){							  
                        $html .= '<li><a href="'.esc_url( get_permalink() ).'">';
                                 if($thumbnail_src) { 
                                    $html .= '<img width="70" height="70" src="'.get_the_post_thumbnail_url( get_the_ID() , 'post-thumbnail' ).'" >';
                                 } else{
									 $html .= '<img width="70" height="70" src="'.$dummyImage.'" >';
								 }
                                $html .= get_the_title();
                           $html .='</a></li>';
						}
                                   
                   endwhile; 
                       
               wp_reset_postdata();  
            
            endif;
			 if(class_exists('WCV_Vendors')){
			$args = [
			       'meta_key' => 'nickname', 
					'meta_value' => esc_attr( $_POST['keyword'] ),
					'meta_compare' => 'LIKE',
					'role' => array('vendor')
				];
		     $wp_user_query = get_users( $args );
			 if($wp_user_query){
				 $html .= '<li>--Creator Name---<li>';
				foreach($wp_user_query as $userList){
			     $userData = $userList->ID;
			     $html .= '<li><a href="'.WCV_Vendors::get_vendor_shop_page( $userData ).'"><img width="70" height="70" src="'.$dummyImage.'" >'.WCV_Vendors::get_vendor_shop_name($userData).'</a></li>';
			
			}
			 }
		
			 }
			$html .='</ul>';
			
			echo $html;
        die();
    }
}
function title_filter( $where, &$wp_query )
{
    global $wpdb;
    // 2. pull the custom query in here:
    if ( $search_term = $wp_query->get( 'search_prod_title' ) ) {
        $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql( like_escape( $search_term ) ) . '%\'';
    }
    return $where;
}
/* initialize wallet to user after registration */
add_action('user_register','wallet_create');

function wallet_create($user_id){
 
 $ch = curl_init(APIURL.'/wallet/');
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
 $response = curl_exec($ch);
 curl_close($ch);
 $result = json_decode($response);

 if($result->success == true){
	 $walletData = $result->result;
	 if($walletData) {
		 
		 update_user_meta($user_id,'walletAddress',$walletData->publicAddress); 
		 update_user_meta($user_id,'balance','0');
	 }	
 }
 
}

/*generate wallet address */
add_action('wp_ajax_generateaddress', 'generateaddress');
function generateaddress(){
	
    $user_id = get_current_user_id();
    $results = [];
	
    $ch = curl_init(APIURL.'/wallet/');
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));

	/* $ch = curl_init('https://cities-abc-blockchain-prod.devtomaster.com/wallet/'); */
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
     $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response);
		/* var_dump($result); */
 if($result->success == true){
     $walletData = $result->result;
     if($walletData) {
         update_user_meta($user_id,'walletAddress',$walletData->publicAddress); 
         update_user_meta($user_id,'balance','0'); 
          $results['status']='success';
          $results['msg']='success.';
          $results['wallet']=$walletData->publicAddress;
     }else{
          $results['status']='error';
     $results['msg']='something goes wrong!! please try again.';
     }  
 }else{
     $results['status']='error';
     $results['msg']='something goes wrong!! please try again.';
 }
 echo json_encode($results);
 exit;
}


/*table create */
  add_action("after_switch_theme", "create_tables");
function create_tables() {
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        $sql = 'CREATE TABLE IF NOT EXISTS wp_wallet_transaction_history  (
            `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
            `userid` varchar(250) NOT NULL,
            `fromAddress` VARCHAR(250) NOT NULL,
			`toAddress` VARCHAR(250) NOT NULL,
			`amount` VARCHAR(250) NOT NULL,
			`type` VARCHAR(250) NOT NULL,
			`txHash` VARCHAR(250) NOT NULL,
            `create_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ) ENGINE=InnoDB DEFAULT CHARSET=latin1;';

         dbDelta($sql);
        global $wpdb;

 
       
    }

	
	
/*callback api for payment transaction*/

add_action('rest_api_init', function () {
    register_rest_route('api/v1', '/transaction-detail', array(
        'methods' => 'POST',
        'callback' => 'transactionDetail',
        'permission_callback' => '__return_true',
        'args' => [
            'toAddress' => [
                'required' => true,
            ], 
			'fromAddress' => [
                'required' => true,
            ],
			'amount' => [
                'required' => true,
            ],
			'txhash' => [
                'required' => true,
            ],
			'type' => [
                'required' => true,
            ],
        ]
    ));
});

add_action('rest_api_init', function () {
    register_rest_route('api/v1', '/mint-details', array(
        'methods' => 'POST',
        'callback' => 'MintDetails',
        'permission_callback' => '__return_true',
        'args' => [
            'tokenId' => [
                'required' => true,
            ], 
			'txhash' => [
                'required' => true,
            ]
        ]
    ));
});

function transactionDetail(WP_REST_Request $request){
	
    $result = array();
    $auth = apache_request_headers();
    if (array_key_exists("authorization", $auth)) {
        global $wpdb;
		
        if ($auth['authorization'] == AccessToken) {
            
            $toAddress = $request['toAddress'];
            $fromAddress = $request['fromAddress'];
			$amount = $request['amount'];
			$txhash = $request['txhash'];
			$type = $request['type'];
			$sql = 'Select * from wp_usermeta where meta_key="walletAddress" AND meta_value ="' . $toAddress . '"';
            $row = $wpdb->get_row($sql);
			if($row){
				
				$user_id = $row->user_id;
				
				$balance = get_user_meta($user_id,'balance',true);
				if($balance){
					$balance = $balance + $amount;
					update_user_meta($user_id,'balance',$balance);
					
				}else{
					$balance = $amount;
					update_user_meta($user_id,'balance',$balance);
				}
				
$sql_insert = 'INSERT INTO  `wp_wallet_transaction_history` (`userid`,`fromAddress`,`toAddress`,`amount`,`txHash`,`type`)VALUES("' . $user_id. '","' . $fromAddress. '","' . $toAddress. '","' . $amount. '","' . $txhash. '","' . $type. '")';
                $wpdb->query($sql_insert);
				$result['status'] = 'success';
				$result['messsage'] = 'Transaction details has been saved!!';
					
			}else{
		   $result['status'] = 'fail';
            $result['messsage'] = "This Toaddress doesn't exists!!";
				
			}
            
        } else {
            $result['status'] = 'fail';
            $result['messsage'] = 'please provide valid access token for authorization';
        }
    } else {
        $result['status'] = 'fail';
        $result['messsage'] = 'please provide access token for authorization';
    }
    return $result;	
	
}


/* API for mint after the purchase product API */

function MintDetails(WP_REST_Request $request){
	
	$result = array(); 
    $auth = apache_request_headers();
	
    if (array_key_exists("authorization", $auth)) {
		
        if ($auth['authorization'] == AccessToken) {
            $tokenId = $request['tokenId'];
			$txhash = $request['txhash'];
			$exist = get_post( $tokenId );
			if($exist){
			update_post_meta($tokenId,'mintDetails',$txhash);  
            $result['status'] = 'success';
            $result['messsage'] = 'Data has been updated!!';
			}else{
			$result['status'] = 'fail';
            $result['messsage'] = "token id doesn't exists!!!";
				
			}
						
        } else {
            $result['status'] = 'fail';
            $result['messsage'] = 'please provide valid access token for authorization';
        }
    } else {
        $result['status'] = 'fail';
        $result['messsage'] = 'please provide access token for authorization';
    }
    return $result;	
	
	
}



/* transaction history data in user panel */

add_action('wp_ajax_transactionHistory', 'transactionHistory');

function transactionHistory(){
	
	$user_id = $_POST['userid'];
	
	global $wpdb;
   $sql = 'SELECT * FROM wp_wallet_transaction_history where userid=' . $user_id;
   $row = $wpdb->get_results($sql);
   $i = 1;
   if($row){?>
   
   <h3 style="text-align:center;">Transaction History</h3>
<div class="table-responsive">
<table class="table" border="1" 
           cellpadding="10" style="width:100%;">
<thead>
<tr><th>S.no</th>
<th>Detials </th>
<th>Amount</th>
<th>Type</th>
<th>Date</th></tr>
</thead>
<tbody>
<?php foreach($row as $transactionData){
	
	?>
<tr><td><?php echo $i;?></td>
<td><b style="font-weight:900;">To Address:</b> <?php echo $transactionData->toAddress;?> <br>
<b style="font-weight:900;">From Address:</b> <?php echo $transactionData->fromAddress;?><br>
<b style="font-weight:900;">Txhash:</b> <?php echo $transactionData->txHash;?></td>
<td><?php echo $transactionData->amount;?></td>
<td><?php echo $transactionData->type;?></td>
<td><?php echo $transactionData->create_date;?></td></tr>
<?php $i++;}?>

</tbody>
</table>
</div>
<?php }else{?>
	
	<h3>No Transaction History</h3>
<?php }
	exit;
	
}

/*Update Wallet Balance and Transaction History */
/*function insert_transaction_history()
{

    global $wpdb;
	$toAddress= $_POST['toAddress'];
	$amount= $_POST['amount'];
	$txhash=  $_POST['hash'];
	$fromAddress=$_POST['from_walAddress'];
	$type=$_POST['type'];
	$user_id=$_POST['user_id'];
	$sql_insert = 'INSERT INTO  `wp_wallet_transaction_history` (`userid`,`fromAddress`,`toAddress`,`amount`,`txHash`,`type`)VALUES("' . $user_id. '","' . $fromAddress. '","' . $toAddress. '","' . $amount. '","' . $txhash. '","' . $type. '")';
	$wpdb->query($sql_insert);
	$result['status'] = 'success';
	$result['messsage'] = 'Transaction details has been saved!!';

	$balance = get_user_meta($user_id,'balance',true);
	if($balance){
		$balance = $balance - $amount;
		update_user_meta($user_id,'balance',$balance);
		
	}else{
		$balance = $amount;
		update_user_meta($user_id,'balance',$balance);
	}
	echo'completed';
            
    die(); 
		
}


add_action( 'wp_ajax_insert_transaction_history', 'insert_transaction_history' );
add_action("wp_ajax_nopriv_insert_transaction_history", "insert_transaction_history");*/

function insert_transaction_history()
{
	global $wpdb;
	
	$data = [
		'amount' => $_POST['amount'],
		'toAddress' => $_POST['toAddress'],
	];
	
	$headers = [
		"Content-type: application/json; charset=utf-8",
		"Accept: application/json",
		'x-api-key:'.APIKEY
	];
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_URL, APIURL.'/wallet/withdraw-transfer');
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	
	$result = json_decode($response);

	if($result->success == true){
		$trxHash = $result->result->txHash;
		if ($trxHash) {
			$sql_insert = 'INSERT INTO  `wp_wallet_transaction_history`
				(`userid`,`fromAddress`,`toAddress`,`amount`,`txHash`,`type`)
				VALUES (
					"' . $_POST['from_walUserid']. '",
					"' . $_POST['walletAdress']. '",
					"' . $_POST['toAddress']. '",
					"' . $_POST['amount']. '",
					"' . $trxHash. '",
					"withdraw"
				)';
			$wpdb->query($sql_insert);

			$user = new WP_User( $_POST['from_walUserid'] );
			if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
			    foreach ( $user->roles as $role )
			        $roles[] = $role;
			}

			if(in_array('vendor', $roles)){

				$vendorbalance = get_user_meta( $_POST['from_walUserid'], 'vendorbalance' , TRUE);
				$pendingvendorbalance = get_user_meta( $_POST['from_walUserid'], 'pendingvendorbalance' , TRUE);

				if(!empty($pendingvendorbalance)) {
					$remainingbalance = $pendingvendorbalance;
				} else {
					$remainingbalance = $vendorbalance;
				}

				$postamountusd = convert_eth_to_usd($_POST['amount']);
				$balance = $remainingbalance - $postamountusd;
				$balance = number_format($balance,5);

				$user_id = get_current_user_id();
				$sql = 'SELECT * FROM wp_wallet_transaction_history where userid=' . $user_id;
				$row = $wpdb->get_results($sql);

				foreach($row as $transactionData){
					if($transactionData->type == 'withdraw') {
						$test = convert_eth_to_usd($transactionData->amount);
						$sumtest += $test;
					}
				}
				
				$vendorbal = $vendorbalance - $sumtest;
				
				if($vendorbal < 1) {
					update_user_meta($_POST['from_walUserid'],'pendingvendorbalance','0.00000');
				} else {
					update_user_meta($_POST['from_walUserid'],'pendingvendorbalance',$vendorbal);
				}
				

			} else {

				$balance = get_user_meta($_POST['from_walUserid'],'balance',true);

				if ($balance){
					$balance = $balance - $_POST['amount'];
					update_user_meta($_POST['from_walUserid'],'balance',$balance);
					
				} else {
					$balance = $_POST['amount'];
					update_user_meta($_POST['from_walUserid'],'balance',$balance);
				}	


			}

			/*$conversion_rate = get_option('convertion_rate1');
			$eth = $conversion_rate->ETH;
			$normal_ETH = $balance*$eth;
			$normal_ETH = number_format($normal_ETH,7);

			if ($normal_ETH){
				$normal_ETH = $normal_ETH - $eth;
				$dollarAmount = $conversion_rate->USD / $conversion_rate->ETH;
				$amount = $dollarAmount * $normal_ETH;
				update_user_meta($_POST['from_walUserid'],'balance',$amount);
				
			} else {
				$dollarAmount = $conversion_rate->USD / $conversion_rate->ETH;
				$amount = $dollarAmount * $eth;
				update_user_meta($_POST['from_walUserid'],'balance',$amount);
			}*/
			$finalResult['success'] = true;
			$current_user = wp_get_current_user();
			$data = $current_user->data;
			$user_email = $data->user_email;
            $username = $data->user_login;
			$date = current_time( 'l, F jS, Y h:i:s A');
			$toplogo = get_site_url().'/wp-content/uploads/2021/11/citiesabc-blue-logo.png';
			 $logo = '<img src="'.$toplogo.'" alt="Citiesabc" style="display:block; height: auto; margin:0 auto; max-width:260px; ">';
			$subject = 'Withdrawn From Your Account';
			$messsage = '<html><body style="background:#efefef;">';
			$messsage .= '<table class="table" cellpadding="0" cellspacing="0" width="850" align="center" style=" border-radius: 4px; overflow: hidden;">';
			$messsage .= '<tbody>	
							<tr>
						<td colspan="2" style="background:#f7f7f7;padding-bottom: 20px;border: 1px solid #17134b;">
							<table class="header" cellpadding="0" cellspacing="0" width="100%" style="padding: 30px 40px;">
								<tbody>
									<tr><td>&nbsp;</td></tr>
									<tr><td style="color: #fff; font-family: sans-serif; font-size: 32px; font-weight: normal; letter-spacing: 1px; line-height: 40px;text-align: center;">' . $logo. '</td></tr>
									<tr><td>&nbsp;</td></tr>
								</tbody>
							</table>
						</td>
					</tr>';
			$messsage .= '<tr class="col-text-tr" >
						<td class="col-text" colspan="2" 
							style="font-family: sans-serif;font-family: sans-serif;background:#fff;
							padding: 30px 40px;
							font-size: 16px;">
							<h4 style="font-size: 25px; font-weight: bold;text-align: center;">' . $subject. '</h4>			
							<p>Dear '.$username.'</p>
							<p>A value '.number_format($_POST['amount'],5).' ETH is withdrawn from your account to '.$_POST['toAddress'].' at '.$date.'.</p> <br>
							<p>Thank you</p>
							<br><p>-- Citiesabc Team</p>
						</td>
					</tr>
					</tbody>
					</table></body></html>';
			send_mail('Withdraw',$messsage,$user_email);
			
			
		} else {
			$finalResult['success'] = false;
		}
	} else {
		$finalResult['success'] = false;
	}
		 
	echo json_encode($finalResult);
	exit;
}


add_action( 'wp_ajax_insert_transaction_history', 'insert_transaction_history' );
add_action("wp_ajax_nopriv_insert_transaction_history", "insert_transaction_history");

function my_hidden_field() {

    
        echo '<input type="hidden" id="adminurl" value="'.get_site_url().'/wp-admin/admin-ajax.php">';
    
}

add_action('admin_notices', 'my_hidden_field');


/*API Key Setting */

function nft_register_settings() {
    register_setting( 'nft_plugin_options', 'nft_plugin_options', 'nft_plugin_options_validate' );
    add_settings_section( 'api_settings', 'API Settings', 'nft_plugin_section_text', 'nft_plugin' );

    add_settings_field( 'nft_plugin_setting_api_url', 'API Url', 'nft_plugin_setting_api_url', 'nft_plugin', 'api_settings' );
 add_settings_field( 'nft_plugin_setting_apikey', 'API Key', 'nft_plugin_setting_apikey', 'nft_plugin', 'api_settings' );
   
    add_settings_field( 'nft_plugin_setting_crypto_compre_key', 'Crypto Compare Key', 'nft_plugin_setting_crypto_compre_key', 'nft_plugin', 'api_settings' );
    add_settings_field( 'nft_plugin_setting_transaction_url', 'Transaction URL', 'nft_plugin_setting_transaction_url', 'nft_plugin', 'api_settings' );
    add_settings_field( 'nft_plugin_setting_transaction_url_order', 'Transaction URL for Order Page', 'nft_plugin_setting_transaction_url_order', 'nft_plugin', 'api_settings' );
    add_settings_field( 'nft_plugin_setting_authorization', 'Authorization AccessToken', 'nft_plugin_setting_authorization', 'nft_plugin', 'api_settings' );
	add_settings_field( 'nft_plugin_setting_contractaddress', 'Contract Address', 'nft_plugin_setting_contractaddress', 'nft_plugin', 'api_settings' );
	 add_settings_field( 'nft_plugin_setting_metamasknetwork', 'Metamask Network', 'nft_plugin_setting_metamasknetwork', 'nft_plugin', 'api_settings' );
	    add_settings_field( 'nft_plugin_setting_adminwallet', 'Admin Wallet Address', 'nft_plugin_setting_adminwallet', 'nft_plugin', 'api_settings' );
	add_settings_field( 'nft_plugin_setting_currency_conversion_api_url', 'Currency Conversion API Url', 'nft_plugin_setting_currency_conversion_api_url', 'nft_plugin', 'api_settings' );

	add_settings_field( 'nft_plugin_setting_schedule_event', 'Conversion Schedule Event(in minutes)', 'nft_plugin_setting_schedule_event', 'nft_plugin', 'api_settings' );

}
add_action( 'admin_init', 'nft_register_settings' );

function nft_plugin_section_text() {
    echo '<p>Here you can set all the options for using the API</p>';
}

function nft_plugin_setting_api_url() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_api_key' name='nft_plugin_options[api_url]' type='text' value='" . esc_attr( $options['api_url'] ) . "' />";
}

function nft_plugin_setting_crypto_compre_key() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_api_key_only' name='nft_plugin_options[crypto_compre_key]' type='text' value='" . esc_attr( $options['crypto_compre_key'] ) . "' />";
}
function nft_plugin_setting_apikey() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_api_key' name='nft_plugin_options[apikey]' type='text' value='" . esc_attr( $options['apikey'] ) . "' />";
}

function nft_plugin_setting_transaction_url() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_results_limit' name='nft_plugin_options[transaction_url]' type='text' value='" . esc_attr( $options['transaction_url'] ) . "' />";
}
function nft_plugin_setting_transaction_url_order() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_transaction_url_order' name='nft_plugin_options[transaction_url_order]' type='text' value='" . esc_attr( $options['transaction_url_order'] ) . "' />";
}
function nft_plugin_setting_authorization() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_results_limit' name='nft_plugin_options[authorization]' type='text' value='" . esc_attr( $options['authorization'] ) . "' />";
}
function nft_plugin_setting_schedule_event() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_schedule_event' name='nft_plugin_options[schedule_event]' type='text' value='" . esc_attr( $options['schedule_event'] ) . "' />";
}
function nft_plugin_setting_currency_conversion_api_url() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_currency_conversion_api_key' name='nft_plugin_options[currency_conversion_api_url]' type='text' value='" . esc_attr( $options['currency_conversion_api_url'] ) . "' /><br>";
	$conversion_rate = get_option('convertion_rate');
	if($conversion_rate){
	echo "<span style='margin-top:10px;'>Default Currency: ".get_woocommerce_currency()."</span><table border='2'><tr><td>".$conversion_rate->ETH." ETH</td><td>".$conversion_rate->USD." USD</td><td>".$conversion_rate->BTC." BTC</td><td>".$conversion_rate->EUR." EUR</td></tr></table>";  	
	}
	
}
function nft_plugin_setting_contractaddress() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_contractaddress' name='nft_plugin_options[contractaddress]' type='text' value='" . esc_attr( $options['contractaddress'] ) . "' />";
}
function nft_plugin_setting_metamasknetwork() {
    $options = get_option( 'nft_plugin_options' );
    echo "<select id='dbi_plugin_setting_metamasknetwork' name='nft_plugin_options[metamasknetwork]' ><option value=''>---Select Network--</option><option value='1'>Mainnet</option><option value='42'>Kovan</option><option value='3'>Ropsten</option><option value='4'>Rinkeby</option><option value='5'>Goerli</option><option value='5'>Goerli</option><option value='137'>polygon-mainnet</option><option value='80001'>polygon-mumbai</option></select><script>jQuery('#dbi_plugin_setting_metamasknetwork').val('" . esc_attr( $options['metamasknetwork'] ) . "')</script>";
}
function nft_plugin_setting_adminwallet() {
    $options = get_option( 'nft_plugin_options' );
    echo "<input id='dbi_plugin_setting_schedule_event' name='nft_plugin_options[adminwallet]' type='text' value='" . esc_attr( $options['adminwallet'] ) . "' />";
}

function nft_plugin_options_validate( $input ) {
    

    return $input;
}

function nft_plugin_settings_page() {
    ?>
   
    <form action="options.php" method="post">
        <?php 
        settings_fields( 'nft_plugin_options' );
        do_settings_sections( 'nft_plugin' ); ?>
        <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
    </form>
    <?php
}
function nft_add_settings_page() {
    add_options_page( 'API Settings Page', 'API Settings Menu', 'manage_options', 'nft-plugin', 'nft_plugin_settings_page' );
}
add_action( 'admin_menu', 'nft_add_settings_page' );


/* call api when order has been completed */
add_action( 'woocommerce_order_status_completed', 'pushAssetForMinting', 10, 1);
function pushAssetForMinting($order_id) {
	
	$order = wc_get_order($order_id);
	$productId = '';
	
$order_wallet_address = $order->get_meta('_billing_wallet_address');

$payment_address = '';
$user_id = $order->get_user_id();
$exist_order_wallet_address = get_user_meta($user_id,'metamaskAddress',true);
if($exist_order_wallet_address){
	update_user_meta($user_id,'metamaskAddress',$order_wallet_address);
}else{ 
	add_user_meta($user_id,'metamaskAddress',$order_wallet_address);
}
        foreach($order->get_items() as $item) {
		   $product = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
		   $product_name = $item['name'];
		   $resellby = get_post_meta($product->get_id(),'resellBy',true);
		 
	
		   $resellList = get_post_meta($product->get_id(),'reselluserList',true);
		   $productId = $product->get_id();
		   $quantity = get_post_meta($product->get_id(),'_stock',true);
		    $stock_status = get_post_meta($product->get_id(),'_stock_status',true);
			
			
			
		   if($quantity > 0){
			 
			   /* duplicate product create */
			   $new_product_details = productCreate($productId);
			   $array_blank = [];
		      $newproduct = [];
			  
			  $wallet_store_onprod_purchase = get_post_meta($new_product_details,'wallet_store_onprod_purchase',true);
			if($wallet_store_onprod_purchase){ 
				array_push($wallet_store_onprod_purchase,$order_wallet_address);
				update_post_meta($new_product_details,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);

			}else{
				$wallet_store_onprod_purchase = array();
				$wallet_store_onprod_purchase[] = $order_wallet_address;
				add_post_meta($new_product_details,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);
			}
		    
			    if($resellList){
					$newproduct['userId'] = $user_id;
					$newproduct['product_id'] = $new_product_details;
					$newproduct['product_cat'] =get_the_terms( $product->get_id(), 'product_cat' );
					$newproduct['orderID'] = $order_id;
					array_push($resellList,$newproduct);
					update_post_meta($productId,'reselluserList',$resellList);
				}else{
					$newproduct['userId'] = $user_id;
					$newproduct['product_id'] = $new_product_details;
					$newproduct['product_cat'] =get_the_terms( $product->get_id(), 'product_cat' );
					$newproduct['orderID'] = $order_id;
					array_push($array_blank,$newproduct);
					add_post_meta($productId,'reselluserList',$array_blank);
				}
			
			 $newproduct['userId'] = $user_id;
			 $newproduct['product_id'] = $new_product_details;
			array_push($array_blank,$newproduct);
			add_post_meta($productId,'reselluserList',$array_blank);
	       $currentpurchased_user = get_post_meta($new_product_details,'currentpurchased_user',true);
		   if($currentpurchased_user){
			    update_post_meta($new_product_details,'currentpurchased_user',$user_id);
		   }else{
			   add_post_meta($new_product_details,'currentpurchased_user',$user_id);
		   }
		$data = array(
		  'tokenId' => $new_product_details,
		  'contractAddress'=>ContractAddress,
		  'toAddress' => $order_wallet_address
		);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/pushAssetForMinting/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		
		update_post_meta( $order_id, 'apiresponse',$result );
			   
		   }else if(($quantity == '') && ($stock_status == 'instock')){
			     $new_product_details = productCreate($productId);
			   $array_blank = [];
		      $newproduct = [];
			  
			  
			  
			  $wallet_store_onprod_purchase = get_post_meta($new_product_details,'wallet_store_onprod_purchase',true);
			if($wallet_store_onprod_purchase){ 
				array_push($wallet_store_onprod_purchase,$order_wallet_address);
				update_post_meta($new_product_details,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);

			}else{
				$wallet_store_onprod_purchase = array();
				$wallet_store_onprod_purchase[] = $order_wallet_address;
				add_post_meta($new_product_details,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);
			}
		    
			    if($resellList){
					$newproduct['userId'] = $user_id;
					$newproduct['product_id'] = $new_product_details;
					$newproduct['orderID'] = $order_id;
					array_push($resellList,$newproduct);
					update_post_meta($productId,'reselluserList',$resellList);
				}else{
					$newproduct['userId'] = $user_id;
					$newproduct['product_id'] = $new_product_details;
					$newproduct['orderID'] = $order_id;
					array_push($array_blank,$newproduct);
					add_post_meta($productId,'reselluserList',$array_blank);
				}
			
			 $newproduct['userId'] = $user_id;
			 $newproduct['product_id'] = $new_product_details;
			array_push($array_blank,$newproduct);
			add_post_meta($productId,'reselluserList',$array_blank);
	       $currentpurchased_user = get_post_meta($new_product_details,'currentpurchased_user',true);
		   if($currentpurchased_user){
			    update_post_meta($new_product_details,'currentpurchased_user',$user_id);
		   }else{
			   add_post_meta($new_product_details,'currentpurchased_user',$user_id);
		   }
		$data = array(
		  'tokenId' => $new_product_details,
		  'contractAddress'=>ContractAddress,
		  'toAddress' => $order_wallet_address
		);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/pushAssetForMinting/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		
		update_post_meta( $order_id, 'apiresponse',$result );
			   
		   }else{
			   
			   $wallet_store_onprod_purchase = get_post_meta($productId,'wallet_store_onprod_purchase',true);
			if($wallet_store_onprod_purchase){ 
				array_push($wallet_store_onprod_purchase,$order_wallet_address);
				update_post_meta($productId,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);

			}else{
				$wallet_store_onprod_purchase = array();
				$wallet_store_onprod_purchase[] = $order_wallet_address;
				add_post_meta($productId,'wallet_store_onprod_purchase',$wallet_store_onprod_purchase);
			}
			     	  
		   if($resellby){
		   		  add_post_meta($order_id,'resellProduct','yes');
			      $currentpurchased_user = get_post_meta($productId,'currentpurchased_user',true);
		   if($currentpurchased_user){
			    update_post_meta($productId,'currentpurchased_user',$user_id);
		   }else{
			   add_post_meta($productId,'currentpurchased_user',$user_id);
		   }
			 
				 $payment_address = get_user_meta( $resellby, 'metamaskAddress',true);
				 $previous_userData = get_post_meta($productId,'previousResellData',true);
				
				 if($previous_userData){
					// $userArray = $previous_userData;
					 array_push($previous_userData,$resellby);
					 update_post_meta($productId,'previousResellData',$previous_userData);
					 
				 }else{
					 $userData = array();
					 array_push($userData,$resellby);
					 add_post_meta($productId,'previousResellData',$userData);
				 }
				 $data = array(
				'tokenId' => $productId,
				'fromAddress'=>$payment_address,/*purchased user metamask address*/
				'toAddress' => $order_wallet_address /*resell user meta address*/
				);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/pushAssetForTransfering/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		
		update_post_meta( $order_id, 'apiresponse',$result );
		 //$date = date('l jS \of F Y h:i:s A');
			 $current_user = wp_get_current_user();
			//$data = $current_user->data;
			 $product = wc_get_product( $productId );
		     $user_name = $current_user->user_login;
			 $productPrice = $product->get_price();
			 $conversion_rate = get_option('convertion_rate');
			 if($conversion_rate){
				$productPrice = $productPrice * $conversion_rate->ETH; 
			 }else{
				 $productPrice = $productPrice ;
			 }
			 $productPrice = number_format($productPrice,5);

			 $user = get_user_by( 'ID', $resellby );
			 $userData = $user->data;
			 $user_email = $userData->user_email;
             $username = $userData->user_login;
			$date = current_time( 'l, F jS, Y h:i:s A');
			$toplogo = get_site_url().'/wp-content/uploads/2021/11/citiesabc-blue-logo.png';
			 $logo = '<img src="'.$toplogo.'" alt="Citiesabc" style="display:block; height: auto; margin:0 auto; max-width:260px; ">';
			 $subject = 'Sold Out';
			 $messsage = '<html><body style="background:#efefef;">';
			 $messsage .= '<table class="table" cellpadding="0" cellspacing="0" width="850" align="center" style=" border-radius: 4px; overflow: hidden;">';
			 $messsage .= '<tbody>	
							 <tr>
						 <td colspan="2" style="background:#fff;padding-bottom: 20px;border: 1px solid #17134b;">
							 <table class="header" cellpadding="0" cellspacing="0" width="100%" style="padding: 30px 40px;">
								 <tbody>
									 <tr><td>&nbsp;</td></tr>
									 <tr><td style="color: #fff; font-family: sans-serif; font-size: 32px; font-weight: normal; letter-spacing: 1px; line-height: 40px;text-align: center;">' . $logo. '</td></tr>
									 <tr><td>&nbsp;</td></tr>
								 </tbody>
							 </table>
						 </td>
					 </tr>';
			 $messsage .= '<tr class="col-text-tr" >
						 <td class="col-text" colspan="2" 
							 style="font-family: sans-serif;font-family: sans-serif;background:#fff;
							 padding: 30px 40px;
							 font-size: 16px;">
							 <h4 style="font-size: 25px; font-weight: bold;text-align: center;">' . $subject. '</h4>			
							 <p>Dear '.$username.'</p>
							  <p>Congratulations! Your '.get_the_title($productId).' product is sold to '.$user_name.' with a value '.$productPrice.' ETH  at '. $date.' .</p> <br>
							 <p>Thank you</p>
							 <br><p>-- Citiesabc Team</p>
						 </td>
					 </tr>
					 </tbody>
					 </table></body></html>';
			
				send_mail('Sold Out',$messsage,$user_email);
				
				
			 }else{
			  $currentpurchased_user = get_post_meta($productId,'currentpurchased_user',true);
		   if($currentpurchased_user){
			    update_post_meta($productId,'currentpurchased_user',$user_id);
		   }else{
			   add_post_meta($productId,'currentpurchased_user',$user_id);
		   }	
		$data = array(
		  'tokenId' => $productId,
		  'contractAddress'=>ContractAddress,
		  'toAddress' => $order_wallet_address
		);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/pushAssetForMinting/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		
		update_post_meta( $order_id, 'apiresponse',$result );
				 
			 }
		   }
		
		
		}	
	
}





function productCreate($productId){
	$current_user_id = get_current_user_id();
	$post_tmp = get_post($productId);
	$author_id = $post_tmp->post_author;
	$product = wc_get_product($productId);
    $resellList = get_post_meta($productId,'resellList',true);
	$content = get_the_content('','',$productId);
	$attach_id = get_post_thumbnail_id($productId);
	if($resellList){
		$resellList = $resellList + 1;
		update_post_meta($productId,'resellList',$resellList);
		
	}else{
		$resellList =  1;
		add_post_meta($productId,'resellList',$resellList);
	}
	$title = get_the_title($productId).' #'.$resellList;
	$cat = get_the_terms($productId,'product_cat');
	$catArray = [];
	foreach($cat as $term_id){
		array_push($catArray,$term_id->term_id);
	}
	 $post    = array(
      'post_title' => $title,
      'post_status' => 'draft',
      'post_type' => 'product',
	  'post_content' => $content,
      'post_author' => $author_id
    );
    $new_post_id = wp_insert_post($post);
	 $updatePost = array(   
        'ID' => $new_post_id, 
        'post_title'    => get_the_title($productId).' #'.$new_post_id, // Updated title
    );
	  wp_update_post( $updatePost );
    $data = get_post_custom($productId);
    foreach ( $data as $key => $values) {
      foreach ($values as $value) {
        add_post_meta( $new_post_id, $key, $value );
      }
    }
	if($attach_id){
		 set_post_thumbnail($new_post_id, $attach_id);
	}
  
	add_post_meta($new_post_id,'resell_parent_product',$productId);
	delete_post_meta($new_post_id,'resellProduct');
	delete_post_meta($new_post_id,'resellBy');
	delete_post_meta($new_post_id,'reselluserList');
	update_post_meta($new_post_id,'_stock','0');
    update_post_meta($new_post_id,'_stock_status','outofstock');
    if($new_post_id) {
        update_post_meta($new_post_id,'productType', 'multistock'); 
    }

	$my_post = array(
      'ID'           => $new_post_id,
      'post_status' => 'publish',
  );
  if($catArray){
		$product = wc_get_product($new_post_id);
		$product->set_category_ids($catArray);
		$product->save();
		
	}
  
  wp_update_post( $my_post );
  
  
  /* add assets api on the time new product create */
	
	
	      $id = $new_post_id;
		  $name = get_the_title($id);
		  $description = get_the_content('','',$id);
		  $featured_image = get_the_post_thumbnail_url($id);
		  $featured_image = get_the_post_thumbnail_url($id);
	  
		   $op = get_field('select_option', $id);
		  
	  if($op == 'video'){
		  $full_video = get_field('add_video',$id);
		  if($full_video){	
		  $featured_image= $full_video;
		  }else{
			  $video = get_field('full_video',$id);
		  $featured_image= $video;
		  }
		  
	  }else if($op == 'audio'){
		  $audio = get_field('add_audio',$id);
		  $featured_image= $audio;
		  
	  }else{
		  $featured_image= $featured_image;
	  }
		  
		  $data = array(
			'tokenId' => $id,
			'name' => $name,
			'description'=>$description,
			'image' => $featured_image
		  );
		  
		  $sendData = json_encode($data);
		  $url = APIURL.'/assets/';
  
		  $ch = curl_init();
		  curl_setopt($ch, CURLOPT_URL,$url);
		  curl_setopt($ch, CURLOPT_POST, 1);
  
		  curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);
  
		  //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		  //curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
		  
		  curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));
		  
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  
		  $result = curl_exec($ch); 
		  
		  curl_close($ch);
		  //exit();
		  update_post_meta($id,'assetsResponse',$result);
	
    return $new_post_id;	
}

/*remove out of stock product from search page */
add_action( 'pre_get_posts', 'custom_pre_get_posts_query' );

function custom_pre_get_posts_query( $q ) {

if ( ! $q->is_main_query() ) return;
if ( ! $q->is_post_type_archive() ) return;
if ( ! is_admin() ) {


$q->set( 'meta_query', array(array(
    'key'       => '_stock_status',
    'value'     => 'outofstock',
    'compare'   => 'NOT IN'
)));

}

remove_action( 'pre_get_posts', 'custom_pre_get_posts_query' );

}

add_filter( 'woocommerce_shortcode_products_query', function( $query_args, $atts, $loop_name ){
    if( $loop_name == 'recent_products' ){
        $query_args['meta_query'] = array( array(
            'key'     => '_stock_status',
            'value'   => 'outofstock',
            'compare' => 'NOT LIKE',
        ) );
    }else if($loop_name == 'top_rated_products'){
		  $query_args['meta_query'] = array( array(
            'key'     => '_stock_status',
            'value'   => 'outofstock',
            'compare' => 'NOT LIKE',
        ) );
	}
    return $query_args;
}, 10, 3);

function getactivelistData($user_id){
	$array = array();
	
	$args_one = array(
			        'post_type'      => 'product',
			        'posts_per_page' => -1,
			        'author' => $user_id,
					'orderby' => 'date',
					'order'   => 'ASC',
					'meta_query' => array(
						'relation' => 'OR',
						array(
							'key'     => 'woo_ua_order_id',
							/* 'value'   => $user_id, */
							'compare' => 'NOT EXISTS',
						), 
					),
					);
				$args_two = array(
			        'post_type'      => 'product',
			        'posts_per_page' => -1,
					'orderby' => 'date',
					'order'   => 'ASC',				
					/*  'meta_query' => array(
						'relation' => 'OR',
						array(
							'key'     => 'resellBy',	
							'compare' => 'EXISTS',
						),  */ 
					/* array(
						 'key' => 'meta_author_id',
						 'value' =>  $authorid,
						 'compare' => 'LIKE',
						), 
						
						 array(
						 'key' => 'currentpurchased_user',
						 'value' =>  $authorid,
						 'compare' => '='
						), 
					) */
			   );
   $loop_one = new WP_Query( $args_one );
   if ( $loop_one->have_posts() ) {
	    $rr =0;
	while ( $loop_one->have_posts() ) : $loop_one->the_post(); 
	 $product_id = get_the_ID();
	 $product_temp = wc_get_product( $product_id );
	 $prod_type = $product_temp->get_type();

	
	 /* if($prod_type == 'auction'){
		 echo '<pre>';
		var_dump(get_post_meta($product_id,'woo_ua_auction_current_bider',true));
		$rr++;
	 } */
	  $current_user_id = get_post_meta($product_id,'currentpurchased_user',true);
	 
	 if($current_user_id == ''){
		 array_push($array,$product_id); 
	 }
	endwhile;
	
   }
   
    $loop_two = new WP_Query( $args_two );
    if ( $loop_two->have_posts() ) {
	while ( $loop_two->have_posts() ) : $loop_two->the_post(); 
	 $product_id = get_the_ID();
	  $current_user_id = get_post_meta($product_id,'currentpurchased_user',true);
	  $resellBy = get_post_meta($product_id,'resellBy',true);
	  $resell_on = get_post_meta($product_id,'resellProduct',true);
	$pro_price_array = get_post_meta($product_id,'resell_user_id_list',true);
		 /* var_dump($last_key); */
		$last_element = end($pro_price_array);
	
	  if(($current_user_id == $user_id)  && ($last_element == $user_id)){
		
		   array_push($array,$product_id);
	  }
	
	endwhile;
	
   } 
    
   return array_unique($array);
					
}


function getsoldlistData($user_id){
	$array = array();
	
	$args_one = array(
			        'post_type'      => 'product',
			        'posts_per_page' => -1,
			        'author' => $user_id,
					'orderby' => 'date',
					'order'   => 'ASC',
					);
   $loop_one = new WP_Query( $args_one );
   if ( $loop_one->have_posts() ) {
	while ( $loop_one->have_posts() ) : $loop_one->the_post(); 
	 $product_id = get_the_ID();
	 $current_user_id = get_post_meta($product_id,'currentpurchased_user',true);
	 $auction_current_bider = get_post_meta($product_id,'woo_ua_auction_current_bider',true);
	 $woo_ua_order_id = get_post_meta($product_id,'woo_ua_order_id',true);
	 if(($current_user_id && ($current_user_id != $user_id)) || (($auction_current_bider != '') && ($woo_ua_order_id !=''))){
		 array_push($array,$product_id); 
	 }
	endwhile;
   }
   
   
   $statuses = ['completed'];
   $orders = wc_get_orders( array('numberposts' => -1,   'customer_id' => $user_id , 'status' => $statuses) );
   $i = 1;
   if($orders){
	$item_count = '';
	foreach( $orders as $order ){ 
	$orderId = $order->get_id();
	foreach( $order->get_items() as $item ){ 
	     $product_id = $item->get_product_id(); 
	
		
         $resellList = get_post_meta($product_id,'reselluserList',true);
		 
         $arrayOrderData = array();
       
         if($resellList){
         	foreach($resellList as $dataList){
         		if(array_key_exists('orderID',$dataList)){
         	 if($dataList['orderID'] == $orderId && $dataList['userId'] == $user_id){
         		
         		 array_push($arrayOrderData,$dataList);
         	 }
         	}
         }
         }else{
         	$arrayOrderData = array();
         	
         }
		
         	
         if($arrayOrderData){
		 $product_id = $arrayOrderData[0]['product_id'];
		 $resellp = get_post_meta($product_id,'resellProduct',true);
		 $currentpurchased_user = get_post_meta($product_id,'currentpurchased_user',true);
         if($resellp == 'yes'){
          $resellID = get_post_meta($product_id,'resellBy',true);
          if($resellID == $user_id){
           $val = 'no';
           
          }else{
           $val = 'yes';
          }
         }else{
           $val = 'yes';
         } 
		  if($val == 'no'){
			   if($currentpurchased_user){
										if($currentpurchased_user != $user_id){
											array_push($array,$product_id);
											
										}
			  }
		  }else{
			   if($currentpurchased_user){
										if($currentpurchased_user != $user_id){
											array_push($array,$product_id);
											
										}
			  }
			 
		  }
			 
			 
			 
			 
		 }else{
         $product_id = $product_id; 
         $resellp = get_post_meta($product_id,'resellProduct',true);
		 $currentpurchased_user = get_post_meta($product_id,'currentpurchased_user',true);
         if($resellp == 'yes'){
          $resellID = get_post_meta($product_id,'resellBy',true);
          if($resellID == $user_id){
           $val = 'no';
           
          }else{
           $val = 'yes';
          }
         }else{
           $val = 'yes';
         }

				 if($val == 'no'){
			   if($currentpurchased_user){
										if($currentpurchased_user != $user_id){
											array_push($array,$product_id);
											
										}
			  }
		  }else{
			   if($currentpurchased_user){
										if($currentpurchased_user != $user_id){
											array_push($array,$product_id);
											
										}
			  }
			 
		  }
          }
	  }

	}
   
   }
   
    
   return array_unique($array);
					
}
//Author Page Product Grid 
function author_product_box($listID_active,$tab_name,$authorid){
	$product_active = wc_get_product( $listID_active);
	$pro_price = $product_active->get_price_html();
	 $op = get_field('select_option', $listID_active);
	if($op == 'video'){
		$video = get_field('add_video',$listID_active);
		$pro_image = ' <video width="100%" muted loop autoplay src="' . $video . '"></video>';
		
	}else if($op == 'audio'){
		$audio = get_field('add_audio',$listID_active);
		 $pro_image = '<div class="ready-player-1 player" > 
		 <audio crossorigin> <source src="'.$audio.'" type="audio/mpeg"> </audio> </div></video>';
	}else{
		$pro_image = get_the_post_thumbnail_url($listID_active)?get_the_post_thumbnail_url($listID_active):get_stylesheet_directory_uri().'/img/woocommerce-placeholder-400x425.png';
		$pro_image =  '<img  src="'.$pro_image.'" class="fea_pro" alt="">';
	}
	$wishlist_icon = do_shortcode('[yith_wcwl_add_to_wishlist product_id='.$listID_active.']');
	$pro_terms = get_the_terms( $listID_active, 'product_cat' );

		$html_cat = '';
	if($pro_terms){
		$html_cat .= '<div class="cat_icon_pro">';
		foreach ( $pro_terms as $term ) {
				
			 $cat_id = $term->term_id;
			
			 $cat_link = get_term_link($cat_id);
			 $thumb_id = get_woocommerce_term_meta( $cat_id, 'thumbnail_id', true );
			 
			 $term_img = wp_get_attachment_url(  $thumb_id );
			if($term_img){
				$html_cat .= '<img style="width: 22.5px;" class="term_img" src="'.$term_img.'"/>';
			}
		}
		$html_cat .= '</div>';
	}
	
	if($tab_name == 'sold'){
		$prod_href = 'javascript:void(0)';
		$prod_href_cover = 'javascript:void(0)';
		$pro_price_array = get_post_meta($listID_active,'user_sold_price',true);
		 /* var_dump($pro_price_array); */
		foreach( $pro_price_array as $key=>$value){
			if($key == $authorid){ // incase of user purchase the resell product again....so loop the whole array list
				$pro_price = 'ETH '.$value;
				
			}
			
		}
	}else{
		if(($op == 'audio') || ($op == 'video')){
			$prod_href_cover = 'javascript:void(0)';
		}else{
			$prod_href_cover =  get_the_permalink($listID_active);
			
		}
		$prod_href = get_the_permalink($listID_active);
	}
	
	
	if($tab_name == 'owned'){
		$encrpytData = "ResellProductByuser_".$authorid;
		$resellp = get_post_meta($listID_active,'resellProduct',true);
	   if($resellp == 'yes'){
		   $resellID = get_post_meta($listID_active,'resellBy',true);
		   if($resellID == $user_id){
			   $val = 'no';
			   $resell_html = '';
		   }else{
			   $val = 'yes';
			    $resell_html = '<a class="resell_btn_author" href="'. get_the_permalink($listID_active).'?resell='. base64_encode($encrpytData).'">Re-Sell</a>';
		   }
	   }else{
			$val = 'yes';
			 $resell_html = '<a class="resell_btn_author" href="'. get_the_permalink($listID_active).'?resell='. base64_encode($encrpytData).'">Re-Sell</a>';
	   }
	  
		if(is_user_logged_in() && ($authorid == get_current_user_id() )){ 
			$owned_resell =  '<div class="Resell_author_btn">'. $resell_html.'</div>';
		} 
	}
	
	echo '	<div class="Child-Flx-1">
                <div class="padding-20-border">
                  <a href="'.$prod_href_cover.'">
                    <div class="Image-Wrap tetetet">
                      '.$pro_image.'
					  '.$html_cat.'
                    </div>
					
				  </a>
                    <div class="Content-Bottom-R">
					 <a href="'.$prod_href.'">
                      <div class="Normal-Heading">
                        <p>'.get_the_title($listID_active).'</p>
                      </div>
					  </a>
                      <div class="Flex-w">
                        <div class="Flex-w-child">
                          <span class="eth"><img src="'.get_stylesheet_directory_uri().'/img/mask.svg" alt="Pay with Metamask"></span>
                          <span class="Txt-Amt">'.$pro_price.'</span>
                        </div>
                        <div class="Flex-w-child wishlist_auth">
                          <!--span class="Icons-divs"></span><span class="Txt-Lft"></span-->
                          '.$wishlist_icon.'
                        </div>
						
                      </div>
                    </div>
                  
                </div>
              </div>';
}


function send_mail($subject, $message,$email){
		
		
		$to = $email;
	$subject = $subject;
	$body = $message;
	$headers = array(); 
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	
	$emailsent = wp_mail($to, $subject, $body, $headers);
		
		
	}
//
add_action('init', 'vendor_change_role_name');
function vendor_change_role_name() {
	global $wp_roles;
	if ( ! isset( $wp_roles ) ){
		$wp_roles = new WP_Roles();
	}
		$wp_roles->roles['vendor']['name'] = 'Creator';
		$wp_roles->role_names['vendor'] = 'Creator';

		$wp_roles->roles['pending_vendor']['name'] = 'Pending Creator';
		$wp_roles->role_names['pending_vendor'] = 'Pending Creator';
		
	 remove_role( 'seller');
	
}

 add_filter('wc_stripe_PAYMENT_METHOD_settings ','convert_etcch_usd_stripe',10,1);
function convert_etcch_usd_stripe($settings){
	
	/* var_dump($settings); */
	return $settings;
}


 add_filter('wc_stripe_payment_metadata','convert_eth_usd_stripe',10,3);
function convert_eth_usd_stripe($metadata, $order, $prepared_source){
	
	$metadata['customer_name']= 'abhinav gghhh';
	/* var_dump($metadata); */
	return $metadata;
}

/* add_filter('wc_stripe_PAYMENT_METHOD_settings ','convert_eth_usd_payment'); */
/* add_filter('wc_stripe_generate_payment_request ','convert_eth_usd_payment'); */
/* add_filter('wc_stripe_generate_payment_request','convert_eth_usd_payment',10,3);
function convert_eth_usd_payment($post_data, $order, $prepared_source){
	
	$post_data['currency']='usd';
	return $post_data;
	
}  
add_action('woocommerce_cart_calculate_fees','custom_handling_fee',10,1);
function custom_handling_fee($cart){
    if(is_admin() && ! defined('DOING_AJAX'))
        return;
    if('stripe' === WC()->session->get('chosen_payment_method')){
        $extra_cost = 0.015;
        $cart_total = $cart->cart_contents_total; 
        $fee = $cart_total * $extra_cost;
        if($fee != 0)
        $cart->add_fee('COD Charge',$fee,true);
		//add_filter('woocommerce_currency_symbol', 'change_existing_currency_symbol', 10, 2);
    }
}



function change_existing_currency_symbol( $currency_symbol, $currency ) {
     switch( $currency ) {
          case 'ETH': $currency_symbol = '$'; break;
     }
     return $currency_symbol;
} */

add_action( 'wp_footer','custom_checkout_jqscript');
function custom_checkout_jqscript(){
    if(is_checkout() && ! is_wc_endpoint_url()):
    ?>
    <script type="text/javascript">
    jQuery( function(){
        jQuery('form.checkout').on('change', 'input[name="payment_method"]', function(){
            jQuery(document.body).trigger('update_checkout');
        });
    });
    </script>
    <?php
    endif;
}

add_action( 'woocommerce_single_product_summary', 'custom_product_category', 6 );
function custom_product_category(){
	global $post;
	$terms = get_the_terms( $post->ID, 'product_cat' );
	$cat_link = get_term_link($terms);
	$thumb_id = get_woocommerce_term_meta( $terms, 'thumbnail_id', true );
	$term_img = wp_get_attachment_url(  $terms );
	
	foreach ($terms as $term) {
	   $produc_cat = $term->name .' ';
	}
	echo "<span class='product_cat'>".$produc_cat."</span>";
}add_filter( 'product_type_selector', 'remove_product_types' );

function remove_product_types( $types ){
    unset( $types['grouped'] );
    unset( $types['external'] );
    unset( $types['variable'] );
	

    return $types;
}add_filter( 'woocommerce_allow_marketplace_suggestions', '__return_false' );
function remove_tab($tabs){
    unset($tabs['linked_product']); // Removes the tab section for cross & upsells
    unset($tabs['shipping']); // Removes the tab section for cross & upsells
    unset($tabs['attribute']); // Removes the tab section for cross & upsells
    //unset($tabs['advanced']); // Removes the tab section for cross & upsells
    return($tabs);
}
add_filter('woocommerce_product_data_tabs', 'remove_tab', 10, 1);
add_filter( 'wc_product_sku_enabled', '__return_false' );
add_filter( 'woocommerce_product_backorders_allowed', '__return_false', 10, 3 );
add_action('woocommerce_product_options_general_product_data', 'my_custom_hide_product');

function my_custom_hide_product() {
  echo '<style>
    .options_group.show_if_simple.show_if_external.show_if_variable {
    display: none !important;
}p.form-field._backorders_field {
    display: none;
}
    p.form-field._low_stock_amount_field {
    display: none;
}.woocommerce_options_panel label, .woocommerce_options_panel legend {
    float: left;
    width: 170px !important;
    padding: 0;
    margin: 0 0 0 -150px;
}.options_group.hide_if_external.hide_if_grouped {
    display: none !important;
}p.form-field.menu_order_field {
    display: none !important;
}p.form-field.ibid_pdf_attach_field {
    display: none !important;
}input#_sold_individually, input#_manage_stock {
    position: relative;
    opacity: .5;
}p.form-field._sold_individually_field.show_if_simple.show_if_variable:before, p.form-field._manage_stock_field.show_if_simple.show_if_variable:before{
	position: absolute;
	content :"";
	background: #00000000;
    width: 71%;
    height: 41px;
    left: 94px;
    z-index: 9999;
    right: 0;
    margin: 0 auto;
}
  </style>';
  echo
  '<script>
  jQuery(document).ready(function($) {
	  $( "#submitdiv" ).on( "click", "#publish", function( e ) {
    var $checked = jQuery( "#title" ).val();
	
    if( $checked.length <= 0 ) {
        alert( "Title should not be empty please enter title" );
        return false;
    } else { 
        return true;
    }
} );
  $( "#submitdiv" ).on( "click", "#publish", function( e ) {
    var $checked = jQuery( "#product_cat-all li input:checked" );
	
    if( $checked.length <= 0 ) {
        alert( "Please Select atleast one category" );
        return false;
    } else { 
        return true;
    }
} );

} );
</script>';
}add_filter( 'product_type_options', function( $options ) {

	// remove "Virtual" checkbox
	if( isset( $options[ 'virtual' ] ) ) {
		unset( $options[ 'virtual' ] );
	}

	

	return $options;

} );
add_filter( 'woocommerce_show_auction_price', '__return_true');

// disable add to cart for owned product

add_filter('woocommerce_is_purchasable', 'woocommerce_is_purchasable_filter_callback', 10, 2 );
	function woocommerce_is_purchasable_filter_callback( $purchasable, $product ) {
		$product_id= $product->get_id();
		$currentpurchased_user = get_post_meta($product_id,'currentpurchased_user',true);
		$author_id = get_the_author_meta( 'ID' , $currentpurchased_user );
		$logged_in_user = get_current_user_id();
		if($author_id == $logged_in_user ){
			$purchasable = false;
		}
	return $purchasable;    
	}
	add_action( 'wp_footer', 'vanish_private_success' );
function vanish_private_success() {
  ?>
    
    <script type="text/javascript">
    jQuery(document).ready(function(){
       //jQuery('#uwa_private_msg_success').hide();
jQuery("#uwa_private_send").click(function(){
	//jQuery('#uwa_private_msg_success').show();
	setTimeout(function () { jQuery('#uwa_private_msg_success').show(); }, 5000);
    setTimeout(function () { jQuery('#uwa_private_msg_success').hide(); }, 15000);
});
//
   // setTimeout(function(){
   //     jQuery('#uwa_private_msg_success').hide();
   // },25000);
   
   
    });

   
    </script>
    <?php
  }
  
  add_filter( 'gettext', 'theme_change_comment_field_names', 20, 3 );
function theme_change_comment_field_names( $translated_text, $text, $domain ) {
        switch ( $translated_text ) {
            case 'Checkout is not available whilst your cart is empty.' :
                $translated_text = __( 'Checkout is not available because your cart is empty.', 'theme_text_domain' );
                break;
        }
 
    return $translated_text;
}

add_filter( 'password_hint', function( $hint )
{
  return __( 'Hint: The password should be at least ten characters long. To make it stronger, use upper and lower case letters, numbers, and symbols like ! " ? $ % ^ & ).' );
} );
add_filter( 'gettext', 'biogrphy_gettext', 10, 2 );
function biogrphy_gettext( $translation, $original )
{
    
    if ( 'Biographical Info' == $original ) {
        return 'Biographical Info(short bio)';
    }
    return $translation;
}
add_filter('validate_username' , 'custom_validate_username', 10, 2);

function custom_validate_username($valid, $username ) {
		if (preg_match("/\\s/", $username)) {
			
   			// there are spaces
			return $valid=false;
		}

	return $valid;
}

function profile_description_length_limit() {

    global $current_user;
    get_currentuserinfo();

    if(strlen(($description = get_user_meta($current_user->ID, 'description', true))) > 90) {
        update_user_meta($current_user->ID, 'description', substr($description, 0, 90));
		//echo "hello---------------->";
    } // end if

} // end custom_profile_description
add_action('profile_personal_options', 'profile_description_length_limit');

/***********************new**********************************/
add_filter( 'admin_footer', 'my_registration_errors');
function my_registration_errors( ) 
{
   echo
  '<script>
  jQuery(document).ready(function($) {
	  $( ".submit" ).on( "click", "#createusersub", function( e ) {
    var $checked = jQuery( "#user_login" ).val();
	
    if( $checked.length <= 2 ) {
        alert( "Username field allowed only alphanumeric and underscore and between 3 to 20 characters!!.");
		return false;
    } else if( $checked.length >= 20 ) { 
	alert( "Username field allowed only alphanumeric and underscore and between 3 to 20 characters!!.");
		return false;
    }
	else{ 
        return true;
    }
} );
  $( ".submit" ).on( "click", "#submit", function( e ) {
    var $checked = jQuery( "#description" ).val();
	
    if( $checked.length >= 91 ) {
        alert( "Please enter 90 characters only. In the short Bio." );
        return false;
    } else { 
        return true;
    }
} );

} );
</script>';
}

// Delete commision when order deleted
function onOrderDelete($orderId){
	global $wpdb;
    $post_type = get_post_type($orderId);
    if($post_type !== 'shop_order') {
        return;
    }
    $table = $wpdb->prefix . 'pv_commission';
	$wpdb->delete( $table, array( 'id' => $orderId ) );

}
add_action('wp_trash_post', 'onOrderDelete', 10, 1);
add_action('before_delete_post', 'onOrderDelete', 10, 1);


add_shortcode( 'footag', 'wpdocs_footag_func' );
function wpdocs_footag_func( $atts ) {
    ob_start();
    include 'templates/template-custom-header.php';
    return ob_get_clean(); 
}

function sort_by_title1( array $a, array $b ) {
	return strcasecmp( $a['title'], $b['title'] );
}

function get_vendor_from_product1( $product_id ) {

		// Make sure we are returning an author for products or product variations only
	if ( 'product' === get_post_type( $product_id ) || 'product_variation' === get_post_type( $product_id ) ) {
		$parent = get_post_ancestors( $product_id );
		if ( $parent ) {
			$product_id = $parent[0];
		}

		$post   = get_post( $product_id );
		$author = $post ? $post->post_author : 1;
		$author = apply_filters( 'pv_product_author', $author, $product_id );
	} else {
		$author = - 1;
	}

	return $author;
}


function sum_orders_for_products1( array $product_ids, array $args = array() ) {
	global $wpdb;


	$defaults = array(
		'status' => apply_filters( 'wcvendors_completed_statuses', array( 'completed', 'processing' ) ),
	);

	foreach ( $product_ids as $id ) {
			$posts = get_posts(
				array(
					'numberposts' => -1,
					'post_type'   => 'product_variation',
					'post_parent' => $id,
				)
			);

			if ( ! empty( $posts ) ) {
				foreach ( $posts as $post ) {
					$product_ids[] = $post->ID;
				}
			}
		}

	$args = wp_parse_args( $args, $defaults );

	/*MB $sql = "
			SELECT COUNT(order_id) as total_orders,
			       SUM(total_due + total_shipping + tax) as line_total,
			       SUM(qty) as qty,
			       product_id*/
		$sql = "
			SELECT *

			FROM {$wpdb->prefix}pv_commission

			WHERE   product_id IN ('" . implode( "','", $product_ids ) . "')
			AND     status != 'reversed'
		";

		if ( ! empty( $args['vendor_id'] ) ) {
			$sql .= "
				AND vendor_id = {$args['vendor_id']}
			";
		}

		/*MB $sql .= '
			GROUP BY product_id
			ORDER BY time DESC;
		';*/
		$sql .= '
			ORDER BY time DESC;
		';

		$orders = $wpdb->get_results( $sql );

		return $orders;
}


function get_default_commission1( $vendor_id ) {

	return get_user_meta( $vendor_id, 'pv_custom_commission_rate', true );
}

function get_commission_rate1( $product_id ) {

	$commission = 0;

	$parent = get_post_ancestors( $product_id );
	if ( $parent ) {
		$product_id = $parent[0];
	}

	$vendor_id = get_vendor_from_product1( $product_id );

	$product_commission = get_post_meta( $product_id, 'pv_commission_rate', true );
	$vendor_commission  = get_default_commission1( $vendor_id );
	$default_commission = get_option( 'wcvendors_vendor_commission_rate' );

	if ( '' != $product_commission && false !== $product_commission ) {
		$commission = $product_commission;
	} elseif ( '' != $vendor_commission && false !== $vendor_commission ) {
		$commission = $vendor_commission;
	} elseif ( '' != $default_commission && false !== $default_commission ) {
		$commission = $default_commission;
	}

	return apply_filters( 'wcv_commission_rate_percent', $commission, $product_id );
}

function format_product_details1( $products ) {
	if ( empty( $products ) ) {
		return false;
	}

	$orders_page_id     = get_option( 'wcvendors_product_orders_page_id' );
	$orders_page        = get_permalink( $orders_page_id );
	$default_commission = get_option( 'wcvendors_vendor_commission_rate' );
	$total_qty          = $total_cost = 0;
	$data               = array(
		'products'   => array(),
		'total_qty'  => '',
		'total_cost' => '',
	);

	foreach ( $products as $product ) {
		$ids[] = $product->ID;
	}


	$orders = sum_orders_for_products1( $ids, array( 'vendor_id' => get_current_user_id() ) );


	if ( $orders ) {
		foreach ( $orders as $order_item ) {
			if ( $order_item->qty < 1 ) {
				continue;
			}

			$commission_rate = get_commission_rate1( $order_item->product_id );

			$_product        = wc_get_product( $order_item->product_id );
				$parent_id       = $_product->get_parent_id();
				$id              = ! empty( $parent_id ) ? $parent_id : $order_item->product_id;
				$cid              = $order_item->id;
				/*MB $data['products'][ $id ]*/
				$data['products'][ $cid ] = array(
					'id'              => $id,
					'title'           => $_product->get_title(),
					'qty'             => ! empty( $data['products'][ $id ] ) ? $data['products'][ $id ]['qty'] + $order_item->qty : $order_item->qty,
					/*MB 'cost'            => ! empty( $data['products'][ $id ] ) ? $data['products'][ $id ]['cost'] + $order_item->line_total : $order_item->line_total,*/
					'cost'            => ! empty( $data['products'][ $id ] ) ? $data['products'][ $id ]['cost'] + $order_item->total_due + $order_item->total_shipping + $order_item->tax : $order_item->total_due + $order_item->total_shipping + $order_item->tax,
					'view_orders_url' => esc_url( add_query_arg( 'orders_for_product', $id, $orders_page ) ),
					'commission_rate' => $commission_rate,
					'orderTotal' => $order_item->order_id,
				);

				$total_qty  += $order_item->qty;
				/*MB $total_cost += $order_item->line_total;*/
				$total_cost += $order_item->total_due + $order_item->total_shipping + $order_item->tax;

		}
	}

	$data['total_qty']  = $total_qty;
	$data['total_cost'] = $total_cost;


		// Sort by product title
	if ( ! empty( $data['products'] ) ) {
		usort( $data['products'], 'sort_by_title1' );
	}


	return $data;
}	



function get_commission_products1( $user_id ) {
	global $wpdb;

	$vendor_products = array();
	$sql             = '';

	$sql .= "SELECT product_id FROM {$wpdb->prefix}pv_commission WHERE vendor_id = {$user_id} ";

	
	$sql .= " AND status != 'reversed' GROUP BY product_id";

	$results = $wpdb->get_results( $sql );

	foreach ( $results as $value ) {
		$ids[] = $value->product_id;
	}

	if ( ! empty( $ids ) ) {
		$vendor_products = get_posts(
			array(
				'numberposts' => -1,
				'orderby'     => 'post_date',
				'post_type'   => array( 'product', 'product_variation' ),
				'order'       => 'DESC',
				'include'     => $ids,
			)
		);
	}

	return $vendor_products;
}



function get_orders_for_products1( array $product_ids, array $args = array() ) {
	global $wpdb;

	if ( empty( $product_ids ) ) {
		return false;
	}


	$defaults = array(
		'status' => apply_filters( 'wcvendors_completed_statuses', array( 'completed', 'processing' ) ),
		
	);

	$args = wp_parse_args( $args, $defaults );

	$sql = "
	SELECT order_id
	FROM {$wpdb->prefix}pv_commission as order_items
	WHERE   product_id IN ('" . implode( "','", $product_ids ) . "')
	AND     status != 'reversed'
	";

	if ( ! empty( $args['vendor_id'] ) ) {
		$sql .= "
		AND vendor_id = {$args['vendor_id']}
		";
	}

	$sql .= '
	GROUP BY order_id
	ORDER BY time DESC
	';

	$orders = $wpdb->get_results( $sql );

	return $orders;
}

/*owner list in the single product */
function cities_custom_metabox($post_type) {
	$post_types = array('product');     //limit meta box to certain post types
 global $post;
 $product = get_product( $post->ID );
 if ( in_array( $post_type, $post_types ) && ($product->product_type == 'simple' ) ) {
	  add_meta_box(
			 'diwp-metabox', 'Owner Lists', 'cities_custom_metabox_callback', $post_type , 'advanced', 'high' );
 }     
}

// Get post id from Meta value and key

function ld_get_post_id_from_meta( $meta_key, $meta_value ) {
    return $wpdb->get_var( $wpdb->prepare("
        SELECT post_id 
        FROM {$wpdb->prefix}postmeta
        WHERE meta_key = '%s' 
        AND meta_value = '%s'", 
    $meta_key, $meta_value ) );
}

add_action('add_meta_boxes', 'cities_custom_metabox');

 function cities_custom_metabox_callback() {
	 global $post;
	 $currency = get_woocommerce_currency_symbol();
	  $currentpurchased_user = get_post_meta($post->ID,'currentpurchased_user',true);
	  $author_admin_id = $post->post_author;
	  $author_admin = get_the_author_meta( 'display_name' , $author_admin_id );
	  $post_date = $post->post_date;
	  if (empty($currentpurchased_user)) {
	  echo '<h3>Current Owner: ' . $author_admin . '</h3>';
	  }
	  else
	  {
		$author_name = get_the_author_meta( 'display_name' , $currentpurchased_user );
		echo '<h3>Current Owner: ' . $author_name . '</h3>';
	  }
		 $previous_userData = get_post_meta($post->ID,'previousResellData',true);
		 //echo "GK" . "<pre>";print_r($previous_userData);
			 
			 echo '<h4>Ownership history:</h4><ul>';
			 echo '<table border ="1" class="wp-list-table widefat fixed striped table-view-list posts">
			 <tr>
			   <th>Ownership name</th>
			   <th>Price</th>
			   <th>Time</th>
			 </tr>';
			 		 // Get order for current purchased user
					  $customer_orders_current = get_posts(array(
						'numberposts' => -1,
						'meta_key' => '_customer_user',
						'orderby' => 'date',
						'order' => 'DESC',
						'meta_value' => $currentpurchased_user,
						'post_type' => wc_get_order_types(),
						'post_status' => array_keys(wc_get_order_statuses()), 'post_status' => array('wc-completed'),
					));
					$Order_Array_c = []; //
					foreach ($customer_orders_current as $customer_order) {
						$orderq = wc_get_order($customer_order);
						$Order_Array_c[] = [
							"ID" => $orderq->get_id(),
							"Value" => $orderq->get_total(),
							"Date" => $orderq->get_date_created()->date_i18n('Y-m-d H:i:s'),
							"UserID" => $currentpurchased_user,
						];
					}
					if($Order_Array_c[0]['UserID'] == $currentpurchased_user && !empty($currentpurchased_user) ){
						echo '<tr>';
						echo '<td><a href="'.get_site_url().'/wp-admin/user-edit.php?user_id='.$currentpurchased_user.'">'.$author_name.'</td>';
						echo '<td>'.$currency.' '.$Order_Array_c[0]['Value'].'</td>';
						echo '<td>'.$Order_Array_c[0]['Date'].'</td>
				 	   </tr>';
				}
			 foreach($previous_userData as $userDatalist){			 
				 $author_name_l = get_the_author_meta( 'display_name' , $userDatalist );
				 // Get all customer orders(Past orders)
					 $customer_orders = get_posts(array(
						 'numberposts' => -1,
						 'meta_key' => '_customer_user',
						 'orderby' => 'date',
						 'order' => 'DESC',
						 'meta_value' => $userDatalist,
						 'post_type' => wc_get_order_types(),
						 'post_status' => array_keys(wc_get_order_statuses()), 'post_status' => array('wc-completed'),
					 ));
				 
					 $Order_Array = []; //
					 foreach ($customer_orders as $customer_order) {
						 $orderq = wc_get_order($customer_order);
						 $Order_Array[] = [
							 "ID" => $orderq->get_id(),
							 "Value" => $orderq->get_total(),
							 "Date" => $orderq->get_date_created()->date_i18n('Y-m-d H:i:s'),
							 "UserID" => $userDatalist,
						 ];
					 }

					if($Order_Array[0]['UserID'] == $userDatalist && !empty($currentpurchased_user) ){
						echo '<tr>';
						echo '<td><a href="'.get_site_url().'/wp-admin/user-edit.php?user_id='.$userDatalist.'">'.$author_name_l.'</td>';
						echo '<td>'.$currency.' '.$Order_Array[0]['Value'].'</td>';
						echo '<td>'.$Order_Array[0]['Date'].'</td>
				 	   </tr>';
				}
			 }
			 echo '<tr><td><b><a href="'.get_site_url().'/wp-admin/user-edit.php?user_id='.$author_admin_id.'">'.$author_admin.'</b></a></td>';
			 echo '<td> - </td><td> - </td></tr>';
			 echo '</table>';	 

}

function convert_eth_to_usd($balance) {
	$conversion_rate = get_option('convertion_rate');
	$dollarAmount = $conversion_rate->USD / $conversion_rate->ETH;
	$amount = $dollarAmount * $balance;
	$amount1 = number_format($amount,5);
	return $amount1;
}

function convert_usd_to_eth($amount) {
	$conversion_rate = get_option('convertion_rate');
	$eth = $conversion_rate->ETH;
	$normal_ETH = $amount*$eth;
	$normal_ETH = number_format($normal_ETH,5);
	return $normal_ETH;
}


add_action( 'init', 'update_data' );
 
function update_data() {

    $user_id = get_current_user_id();

    $vendor_products = get_commission_products1( $user_id );
	$vendor_summary = format_product_details1( $vendor_products );

    foreach ( $vendor_summary['products'] as $product ) :
	$_product = wc_get_product( $product['id'] );
	$pricehtml = $_product->get_sale_price();

	if(empty($pricehtml)) {
		$pricehtml = $_product->get_regular_price();
	}

	$commision = $product['commission_rate'];
	$resellby = get_post_meta($_product->get_id(),'resellBy',true);

	if($resellby){
		$pricehtml = $_product->get_regular_price();
		$commision = get_option('wcvendors_vendor_creatore_royalty', true);
	}

	$percentage = ($pricehtml*$commision)/100;
	$percentage = round($product['cost'],2);
	$sumpercentage += $percentage;
	endforeach; 

	global $wpdb;
	$sql = 'SELECT * FROM wp_wallet_transaction_history where userid=' . $user_id;
	$row = $wpdb->get_results($sql);

	foreach($row as $transactionData){
		if($transactionData->type == 'resellproductamount') {
			$resellproductamount += $transactionData->amount;
		}
	}
	$sumpercentage += $resellproductamount;
	update_user_meta($user_id,'vendorbalance',$sumpercentage);



	if($vendorbalance >= $sumpercentage_vendor) {
		$vendorbal = $vendorbalance - $sumtest;
		update_user_meta($user_id,'pendingvendorbalance',$vendorbal);
	}

	$vendorbalance = get_user_meta( $user_id, 'vendorbalance' , TRUE);
	$vendorbalanceeth = convert_usd_to_eth($vendorbalance);

	$pendingvendorbalance = get_user_meta( $user_id, 'pendingvendorbalance' , TRUE);
	$pendingvendorbalanceeth = convert_usd_to_eth($pendingvendorbalance);

	foreach($row as $transactionData){
		if($transactionData->type == 'withdraw') {
			$test = convert_eth_to_usd($transactionData->amount);
			$sumtest += $test;
		}
	}

	if($vendorbalance >= $sumpercentage_vendor) {
		$vendorbal = $vendorbalance - $sumtest;
		update_user_meta($user_id,'pendingvendorbalance',$vendorbal);
	}

}


add_action( 'woocommerce_update_product', 'wpse_110037_new_posts_new' );

function wpse_110037_new_posts_new($post_id){
    $WC_Product = wc_get_product( $post_id);
    $resellby =  get_post_meta($post_id,'resellBy',true);
    $userId = get_current_user_id();
    if(empty($resellby)) {
        if($WC_Product->get_stock_quantity() == '1'){
            update_post_meta($post_id,'productType', 'primary');
        } else {
            update_post_meta($post_id,'productType', 'multistock');
        }
    }
}


add_action( 'woocommerce_product_write_panel_tabs', 'custom_add_tab' );
add_action( 'woocommerce_product_data_panels'     , 'custom_add_panel' );
add_action( 'woocommerce_process_product_meta'    , 'custom_save_panel' );

function custom_add_tab() {
 $user = wp_get_current_user(); // getting & setting the current user 
	 $roles = $user->roles; 
    ?>
    <li class="custom_commission_tab">
        <a href="#commission"><span><?php _e( 'Commission', 'wc-vendors' ); ?></span></a>
    </li>
    <?php
}
function custom_add_panel() {

    global $post;
	 $user = wp_get_current_user(); // getting & setting the current user 
	 $roles = $user->roles; 
    ?>

    <div id="commission" class="panel woocommerce_options_panel">
        <fieldset>

            <p class='form-field commission_rate_field'>
                <label for='pv_commission_rate_custom'><?php _e( 'Creator Commission', 'wc-vendors' ); ?> (%)</label>
                <input
                        type='number'
                        id='pv_commission_rate'
                        name='pv_commission_rate1'
                        class='short'
                        max="100"
                        min="0"
                        step='any'
                        placeholder='<?php _e( 'Leave blank for default', 'wc-vendors' ); ?>'
                        value="<?php echo get_post_meta( $post->ID, 'pv_commission_rate', true ); ?>"
                />
            </p>

            <p class='form-field royalty_commission_rate_field'>
                <label for='pv_royalty_commission_rate'><?php _e( 'Royalty commission', 'wc-vendors' ); ?> (%)</label>
                <input
                        type='number'
                        id='pv_royalty_commission_rate'
                        name='pv_royalty_commission_rate1'
                        class='short'
                        max="100"
                        min="0"
                        step='any'
                        placeholder='<?php _e( 'Leave blank for default', 'wc-vendors' ); ?>'
                        value="<?php echo get_post_meta( $post->ID, 'pv_royalty_commission_rate', true ); ?>"
                />
            </p>

        </fieldset>
    </div>
    <?php
}

function custom_save_panel( $post_id ) {
	
	$user = wp_get_current_user(); // getting & setting the current user 
 	$roles = $user->roles; 

    if ( isset( $_POST['pv_commission_rate1'] ) ) {
        update_post_meta( $post_id, 'pv_commission_rate', is_numeric( $_POST['pv_commission_rate1'] ) ? (float) $_POST['pv_commission_rate1'] : false );
    }
    if ( isset( $_POST['pv_royalty_commission_rate1'] ) ) {
        update_post_meta( $post_id, 'pv_royalty_commission_rate', is_numeric( $_POST['pv_royalty_commission_rate1'] ) ? (float) $_POST['pv_royalty_commission_rate1'] : false );
    }

}


function save_metadata($post_id) {
    global $post;
    if ( isset( $_POST['pv_commission_rate1'] ) ) {
        update_post_meta( $post_id, 'pv_commission_rate', is_numeric( $_POST['pv_commission_rate1'] ) ? (float) $_POST['pv_commission_rate1'] : false );
    }
    if ( isset( $_POST['pv_royalty_commission_rate1'] ) ) {
        update_post_meta( $post_id, 'pv_royalty_commission_rate', is_numeric( $_POST['pv_royalty_commission_rate1'] ) ? (float) $_POST['pv_royalty_commission_rate1'] : false );
    }
}
add_action( 'save_post', 'save_metadata');



 add_action('wp_ajax_checkUsername', 'checkUsername_callback');
add_action('wp_ajax_nopriv_checkUsername', 'checkUsername_callback');
function checkUsername_callback() {

    $username = sanitize_user($_POST['uname']);
    if ( username_exists( $username ) ) {
        $msg['msg'] = 'u_taken';
        $msg['message'] = 'Username already taken.';
    } else {
        $msg['msg'] = 'u_not_taken';
        $msg['message'] = 'Username available.';
    }
    $result = $msg;
    echo json_encode($result);
    exit;

}