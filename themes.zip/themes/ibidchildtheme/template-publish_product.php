<?php 
/*
* Template Name: Publish Product Page
*/
$user_id = get_current_user_id();
/* $walletAddress = get_user_meta($user_id,'billing_wallet_address',true); */
$walletAddress = get_user_meta($user_id,'metamaskAddress',true);

if(!is_user_logged_in()){
	$url = get_site_url();
   wp_redirect($url);
   exit;
}else{
	 if($_GET){
	  if($_GET['resellID']){
		  $resell = base64_decode($_GET['resellID']);
		  $resell = explode("_",$resell);
		  $exist = user_id_exists($resell[1]); 
		  if($exist){
			  $product = wc_get_product($resell[2]);
			  
			  
		  }else{
			 $url = get_site_url();
   wp_redirect($url);
   exit; 
		  }
	  }
  }else{
	   $url = get_site_url();
   wp_redirect($url);
   exit; 
  }
}
get_header( 'shop' ); 





$wallet_store_onprod_purchase = get_post_meta($product->get_id(),'wallet_store_onprod_purchase',true);
$last_element_stored = end($wallet_store_onprod_purchase);
?>
<div class="container">
	<div class="row">
		<div class="tabsWrap">
			<h3><?php echo $product->get_name();?></h3>
			<ul class="nav nav-tabs mb-3 cstmNavTabs" id="pills-tab" role="tablist">
				<li class="nav-item cstmNavItem active">
					<a class="nav-link cstmNavLink active" id="pills-price-tab" data-toggle="pill" href="#pills-price" role="tab" aria-controls="pills-price" aria-selected="true">Price</a>
				</li>
				<!-- <li class="nav-item cstmNavItem">
					<a class="nav-link cstmNavLink" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Profile</a>
				</li>
				<li class="nav-item cstmNavItem">
					<a class="nav-link cstmNavLink" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Contact</a>
				</li> -->
			</ul>
						<div class="tab-pane cstmPane fade show active in" id="pills-price" role="tabpanel" aria-labelledby="pills-price-tab">
			
					<label for="add-price cstmLabel">Current Price</label>
					<div class="form-group cstmFormGroup">
						<div class="input-group-text"><?php echo get_woocommerce_currency_symbol(); ?></div>
						<input type="text" class="form-control cstmInput" id="add-price" placeholder="Add Price" value="<?php echo $product->get_price();?>" readonly>
					</div>
					<label for="add-price cstmLabel">Updated Price</label>
					<div class="form-group cstmFormGroup">
						
						<div class="input-group-text"><?php echo get_woocommerce_currency_symbol(); ?></div>
						<input type="text" class="form-control cstmInput" id="update-price" placeholder="Add Updated Price"  value="<?php echo $product->get_price();?>">
					</div>
					<button class="btn btn-primary cstmSubmitBtn" id="submitData">Publish Product</button>
					<input type="hidden" id="metamask-network" value="<?php echo $api_settings['metamasknetwork'];?>">
					<input type="hidden" id="contract-address" value="<?php echo $api_settings['contractaddress'];?>">
					
					<input type="hidden" id="metamask_connected" name="metamask_connected">
					<input type="hidden" class="input-text " name="billing_wallet_address" id="billing_wallet_address" placeholder="Wallet Address" value="<?php echo $walletAddress; ?>">
					<input type="hidden" class="input-text " name="wallet_store_onprod_purchase" id="wallet_store_onprod_purchase" placeholder="product stored Address" value="<?php echo $last_element_stored; ?>">
					<input type="hidden" id="account" value="">
					<input type="hidden" id="resell_page_identity" value="yes">
				
				</div>
		</div>
	</div>
</div>
<input type="hidden" id="pid" value="<?php echo $resell[2]; ?>">
<input type="hidden" id="url" value="<?php echo get_site_url(); ?>/wp-admin/admin-ajax.php">
<?php get_footer( 'shop' ); ?>

  