<?php
  get_header();
$author = get_user_by('slug', get_query_var('author_name'));
 $authorid =$author->ID;
/* var_dump($authorid);
var_dump(get_user_meta($authorid)); */
 $full_name = get_user_meta($author->ID, 'first_name', true) . ' ' . get_user_meta($author->ID, 'last_name', true);
 $aut_dec = get_user_meta($author->ID, 'description', true);
  $website = get_user_meta($author->ID, 'url', true);
 $author_avatar = get_wp_user_avatar($author->ID, 180);
 $author_avatar = $author_avatar?$author_avatar:'<img src="/wp-content/uploads/2021/05/user.png">';
   $user_location = get_field('user_location','user_'.$authorid); 
    /* $user_location_city =  get_user_meta( $authorid, 'billing_city', true );
	 $user_location_country = get_user_meta( $authorid, 'billing_state', true ); */
    $user_bio = get_field('user_biography','user_'.$authorid);
    $user_fb = get_field('facebook_link','user_'.$authorid);
    $user_youtube = get_field('youtube_link','user_'.$authorid);
    $user_insta = get_field('instagram_link','user_'.$authorid);
    $user_twitter = get_field('twitter_link','user_'.$authorid);
	
    $user_category = get_field('select_category','user_'.$authorid);
  
	
	
	/* if ( $wishlist && $wishlist->has_items() ) :
		foreach ( $wishlist_items as $item ) : */
		
	
     ?>
<!--
  <div class="container">
  <div class="row">
  
  
  
  
  </div>
  </div> 
   --->
<div class="Wrap-TOP">
  <div class="container">
    <div class="Wrap-Section-One">
      <div class="Wrap-Parent">
        <div class="Wrap-Parent-Image">
          <div class="Border-Dv">
			<?php echo $author_avatar; ?>
          </div>
        </div>
        <div class="Wrap-Parent-Doc">
          <div class="Wrap-Author-Data">
            <h2><?php echo  $full_name; ?></h2>
            <div class="List-Image wrap-two">
              <ul>
			  <?php 
				foreach($user_category as $term_id){
					$thumb_id = get_woocommerce_term_meta( $term_id, 'thumbnail_id', true );
					$term_img = wp_get_attachment_url(  $thumb_id );
					$term_name = get_term( $term_id )->name;
				?>
                <li>
                  <span class="img-small">
                    <img style="width: 15px;" class="term_img" src="<?php echo $term_img; ?>"/>
                  </span>
                  <span class="itt-txt"><?php echo $term_name; ?></span>
                </li>
				<?php } ?>
               
              </ul>
            </div>
            <div class="Location-Data">
			<?php if($user_location){
					/* $user_location = 	$user_location_city?$user_location_city.', ':''; 
					$user_location .= $user_location_country?$user_location_country:''; */ ?>
              <span>
                <svg width="12" height="16" viewBox="0 0 12 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M5.84945 0C2.62404 0 0 2.67119 0 5.95454C0 7.79111 0.928877 10.0203 2.76091 12.5801C4.1016 14.4535 5.42273 15.7895 5.47832 15.8455C5.58051 15.9484 5.71495 16 5.84954 16C5.98023 16 6.11101 15.9513 6.21239 15.8537C6.26811 15.8 7.59258 14.518 8.9358 12.6705C10.7693 10.1486 11.699 7.88905 11.699 5.95451C11.6989 2.67119 9.0748 0 5.84945 0ZM5.84945 8.5252C4.27257 8.5252 2.98972 7.24233 2.98972 5.66548C2.98972 4.08863 4.2726 2.80576 5.84945 2.80576C7.4263 2.80576 8.70917 4.08863 8.70917 5.66548C8.70917 7.24233 7.42626 8.5252 5.84945 8.5252Z" fill="#6F7591"/>
                </svg>
              </span>
			  
				<span class="noraml-txt"><?php echo $user_location; ?></span>
			  <?php } ?>
            </div>
            <div class="Doc-More">
              <p>
               <?php echo $aut_dec; ?>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="Wrap-Child">
		
		<?php if(is_user_logged_in() && ($authorid == get_current_user_id() )){ ?>
        <div class="User-Social-btn">
          <a href="" data-toggle="modal" data-target="#EditProfile" >
          Edit Profile
          </a>
        </div>
		<?php } ?>

        <div class="All-Social-Icons">
          <ul>
		 <?php if($user_insta){ ?>
                <li>
                  <a href="<?php echo $user_insta; ?>" target="_blank">
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M2.31035 0H15.6895C16.9601 0 17.9997 0.940699 17.9997 2.31016V15.6897C17.9997 17.0592 16.9601 17.9999 15.6895 17.9999H2.31035C1.03939 17.9999 0 17.0592 0 15.6897V2.31016C0 0.940699 1.03939 0 2.31035 0ZM13.1121 1.99986C12.6664 1.99986 12.3021 2.36431 12.3021 2.81027V4.74988C12.3021 5.19565 12.6664 5.56029 13.1121 5.56029H15.1465C15.5923 5.56029 15.957 5.19565 15.957 4.74988V2.81027C15.957 2.36431 15.5923 1.99986 15.1465 1.99986H13.1121ZM15.9655 7.61208H14.3812C14.5311 8.10147 14.6123 8.61987 14.6123 9.1562C14.6123 12.1502 12.1069 14.5771 9.01703 14.5771C5.92733 14.5771 3.42237 12.1502 3.42237 9.1562C3.42237 8.6195 3.50332 8.10128 3.65339 7.61208H2.00023V15.2155C2.00023 15.6089 2.32218 15.9311 2.71583 15.9311H15.2502C15.6439 15.9311 15.9658 15.6091 15.9658 15.2155V7.61208H15.9655ZM9.01685 5.45809C7.0205 5.45809 5.4019 7.02623 5.4019 8.96085C5.4019 10.8955 7.0205 12.4636 9.01685 12.4636C11.0134 12.4636 12.6322 10.8955 12.6322 8.96085C12.6322 7.02623 11.0136 5.45809 9.01685 5.45809Z" fill="#070E5B"/>
</svg>

                  </a>
                </li>
		 <?php } if($user_fb){ ?>
                <li>
                  <a href="<?php echo $user_fb; ?>" target="_blank">
                    <svg width="10" height="19" viewBox="0 0 10 19" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M9.45735 0.528474C9.16806 0.485616 8.17163 0.399902 7.01449 0.399902C4.59306 0.399902 2.93234 1.87848 2.93234 4.58919V6.92491H0.200195V10.0963H2.93234V18.2285H6.21092V10.0963H8.93235L9.35021 6.92491H6.21092V4.89991C6.21092 3.98919 6.45735 3.35705 7.7752 3.35705H9.45735V0.528474Z" fill="#070E5B"/>
</svg>


                  </a>
                </li>
				 <?php } if($user_twitter){ ?>
                <li>
                  <a href="<?php echo $user_twitter; ?>" target="_blank">
                   <svg width="18" height="15" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.0859 2.22867C16.4645 2.49653 15.7895 2.68939 15.0931 2.76439C15.8109 2.33581 16.3574 1.66081 16.6145 0.857241C15.9502 1.25367 15.2002 1.54296 14.4181 1.69296C13.7859 1.01795 12.8859 0.600098 11.8895 0.600098C9.97163 0.600098 8.42878 2.15367 8.42878 4.06082C8.42878 4.32867 8.46092 4.59653 8.51449 4.85367C5.64306 4.70367 3.08234 3.33224 1.37877 1.23224C1.07877 1.74653 0.907339 2.33581 0.907339 2.97867C0.907339 4.17867 1.51805 5.23939 2.4502 5.86082C1.88234 5.83939 1.34663 5.67868 0.885911 5.42153V5.46439C0.885911 7.14653 2.0752 8.53939 3.66091 8.86082C3.37163 8.93582 3.06091 8.97868 2.7502 8.97868C2.5252 8.97868 2.31091 8.95725 2.09663 8.92511C2.53591 10.2965 3.81091 11.293 5.33234 11.3251C4.14306 12.2573 2.65377 12.8037 1.03591 12.8037C0.746625 12.8037 0.478767 12.793 0.200195 12.7608C1.73234 13.7465 3.55377 14.3144 5.51449 14.3144C11.8788 14.3144 15.3609 9.04296 15.3609 4.46796C15.3609 4.31796 15.3609 4.16796 15.3502 4.01796C16.0252 3.5251 16.6145 2.91439 17.0859 2.22867Z" fill="#070E5B"/>
</svg>


                  </a>
                </li>
				<?php } if($user_youtube){ ?>
                <li>
                  <a href="<?php echo $user_youtube; ?>" target="_blank">
                   <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.8252 0.428312C18.6819 0.659024 19.3574 1.33438 19.5879 2.19115C20.0164 3.75609 19.9999 7.0181 19.9999 7.0181C19.9999 7.0181 19.9999 10.2635 19.5881 11.8286C19.3574 12.6852 18.682 13.3607 17.8252 13.5912C16.2602 14.0032 9.99996 14.0032 9.99996 14.0032C9.99996 14.0032 3.75609 14.0032 2.17467 13.5749C1.3179 13.3442 0.642545 12.6687 0.411833 11.8121C0 10.2635 0 7.00162 0 7.00162C0 7.00162 0 3.75609 0.411833 2.19115C0.642392 1.33453 1.33438 0.642545 2.17452 0.411985C3.73961 0 9.99981 0 9.99981 0C9.99981 0 16.2602 0 17.8252 0.428312ZM13.2117 7.00153L8.00586 9.99988V4.00317L13.2117 7.00153Z" fill="#070E5B"/>
</svg>


                  </a>
                </li>
				<?php } ?>
              </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="Author-Tab">
  <div class="container">
    <div class="Tab-70">
      <div class="exTab1">
        <div class="Wrap-Ul-Tab">
          <ul  class="nav nav-tabs custom-Tabs-txt">
            <li>
              <a   href="#Biography" data-toggle="tab">biography</a>
            </li>
            <li>
              <a class="active" href="#NormalActive" data-toggle="tab">active <span class="small c_active"></span></a>
            </li>
            <li>
              <a href="#Owned" data-toggle="tab">owned <span class="small c_owned"></span></a>
            </li>
            <li>
              <a href="#Sold" data-toggle="tab">sold <span class="small c_resell"></span></a>
            </li>
            <li>
              <a href="#Preferred" data-toggle="tab">preferred <span class="small c_preferred"></span></a>
            </li>
          </ul>
        </div>
        <div class="tab-content Normal-Custom-content clearfix">
          <div class="tab-pane " id="Biography">
            <?php if($user_bio){ echo $user_bio; } else { ?>
			<div class="noFound"><h3>no bio found</h3><p>come back soon!</p></div>
			<?php } ?>
          </div>
          <div class="tab-pane active" id="NormalActive">
            <div class="Author-Flx-Card">
			<?php 
			
			$listID = getactivelistData($authorid);
			
				$count_active=0;
					if($listID){
					foreach($listID as $listID_active){
						
						$count_active++;
						author_product_box($listID_active,'active',$authorid); //custom-function.php
					} }else { ?>
					<div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>
					<?php } ?>
    
            </div>
          </div>
		  <!---------------------------OWNED ------------------------>
          <div class="tab-pane" id="Owned">
			<div class="Author-Flx-Card">
			<?php 	$user_id = $authorid; /*get current user id*/
					
					$encrpytData = "ResellProductByuser_".$user_id; /* user id change in the encrpyted data */
					$statuses = ['completed'];
					$orders = wc_get_orders( array('numberposts' => -1,   'customer_id' => $user_id , 'status' => $statuses) ); /* get all user orders data  */
					$c_owned = 0;
					
					
					/* for auction products */
					/* 	$args_one = array(
			        'post_type'      => 'product',
			        'posts_per_page' => -1,
			      
					'orderby' => 'date',
					'order'   => 'ASC',
					'meta_query' => array(
						'relation' => 'OR',
						array(
							'key'     => 'woo_ua_auction_current_bider',
							'value'   => $user_id,
							'compare' => '=',
						), 
					),
					);
					   $loop_one = new WP_Query( $args_one ); */

					/* END for auction products */
					
					if($orders){
						foreach( $orders as $order ){  
						
						$orderId = $order->get_id();
						
							foreach( $order->get_items() as $item ){ 
								//$product_id = $product->get_id();
								$prod_name = $item->get_name();
								$product_id = $item->get_product_id(); 
								/* echo $product_id; */
								$currentpurchased_user = get_post_meta($product_id,'currentpurchased_user',true);
								/* var_dump($currentpurchased_user); */
								$txhashId = get_post_meta($product_id,'mintDetails',true);
								
								$resellp = get_post_meta($product_id,'resellProduct',true);
							   if($resellp == 'yes'){
								   $resellID = get_post_meta($product_id,'resellBy',true);
								   if($resellID == $user_id){
									   $val = 'no';
									   
								   }else{
									   $val = 'yes';
								   }
							   }else{
									$val = 'yes';
							   }
							
								 /* var_dump($resellBy); */
								 $resellList = get_post_meta($product_id,'reselluserList',true);
		/*  var_dump($resellList); */
								 $arrayOrderData = array();
							   
								 if($resellList){
									foreach($resellList as $dataList){
										if(array_key_exists('orderID',$dataList)){
									 if($dataList['orderID'] == $orderId && $dataList['userId'] == $user_id){
										
										 array_push($arrayOrderData,$dataList);
									 }
									}
								 }
								 }else{
									$arrayOrderData = array();
									
								 }
								 if($arrayOrderData){
			
									 $prod_name = get_the_title($arrayOrderData[0]['product_id']);
									 $product_id = $arrayOrderData[0]['product_id'];
									 $previous_userData = get_post_meta($product_id,'previousResellData',true);
									 $currentpurchased_user = get_post_meta($product_id,'currentpurchased_user',true);
										 
									 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $arrayOrderData[0]['product_id'] ), array(150,150) );
									 $f_image = $image?$image[0]:get_stylesheet_directory_uri().'/img/woocommerce-placeholder-300x300.png';
									 //echo $product_id;
									 
									 $txhashId = get_post_meta($orderId,'txhash',true);
									 $resellp = get_post_meta($arrayOrderData[0]['product_id'],'resellProduct',true);
									 if($resellp == 'yes'){
									  $resellID = get_post_meta($arrayOrderData[0]['product_id'],'resellBy',true);
									  if($resellID == $user_id){
									   $val = 'no';
									   
									  }else{
									   $val = 'yes';
									  }
									 }else{
									   $val = 'yes';
									 }
										 
								  }
								 
								 
								 
								
								

							if($val == 'yes') {
								if($currentpurchased_user){
									
									if($currentpurchased_user == $user_id){	
										$resell_html = '<a class="resell_btn_author" href="'. get_the_permalink($product_id).'?resell='. base64_encode($encrpytData).'">Re-Sell</a>';
									}else {
										//$resell_html = '<a class="resell_btn_author">Sold Out</a>';
										$resell_html = '';
									} 
								}else{
									$resell_html = '<a class="resell_btn_author" href="'. get_the_permalink($product_id).'?resell='. base64_encode($encrpytData).'">Re-Sell</a>';
							
								} 
							}   
							
						if($val == 'yes') {
							if($currentpurchased_user == $user_id){ 
							 $c_owned++;
							 $wishlist_icon = do_shortcode('[yith_wcwl_add_to_wishlist product_id='.$product_id.']');
							 
							 $pro_terms = get_the_terms( $product_id, 'product_cat' );
							 
							

		$html_cat = '';
	if(!empty($pro_terms)){
		$html_cat .= '<div class="cat_icon_pro">';
		foreach ( $pro_terms as $term ) {
				
			 $cat_id = $term->term_id;
			
			 $cat_link = get_term_link($cat_id);
			 $thumb_id = get_woocommerce_term_meta( $cat_id, 'thumbnail_id', true );
			 
			 $term_img = wp_get_attachment_url(  $thumb_id );
			if($term_img){
				$html_cat .= '<img style="width: 22.5px;" class="term_img" src="'.$term_img.'"/>';
			}
		}
		$html_cat .= '</div>';
	}
	
	 $op = get_field('select_option', $product_id);
	if($op == 'video'){
		$video = get_field('add_video',$product_id);
		$pro_image = '<video width="100%" muted loop autoplay src="' . $video . '"></video>';
		
	}else if($op == 'audio'){
		$audio = get_field('add_audio',$product_id);
		 $pro_image = '<div class="ready-player-1 player" > 
		 <audio crossorigin> <source src="'.$audio.'" type="audio/mpeg"> </audio> </div></video>';
	}else{
		
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), array(150,150) );
								$f_image = $image?$image[0]:get_stylesheet_directory_uri().'/img/woocommerce-placeholder-400x425.png';
		$pro_image =  '<img  src="'.$f_image.'" class="fea_pro" alt="">';
	}
	
	if(($op == 'audio') || ($op == 'video')){
			$prod_href_cover = 'javascript:void(0)';
		}else{
			$prod_href_cover =  get_the_permalink($product_id);
			
		}
		$prod_href = get_the_permalink($product_id);
							 
						?>
						<div class="Child-Flx-1 aaaaa">
							<div class="padding-20-border">
							  <a href="<?php echo $prod_href_cover; ?>">
								<div class="Image-Wrap rrr">
								<?php echo $pro_image;
								  echo $html_cat; ?>
								</div>
							  </a>
								<div class="Content-Bottom-R">
								<a href="<?php echo $prod_href ?>">
								  <div class="Normal-Heading">
									<p><?php echo $prod_name; ?></p>
								  </div>
								</a>
								  <div class="Flex-w">
									<div class="Flex-w-child">
									  <span class="eth"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/mask.svg" alt="Pay with Metamask"></span>
									  <span class="Txt-Amt"><?php
									  //echo $currency = get_woocommerce_currency();
								/* translators: 1: formatted order total 2: total order items */
								echo wp_kses_post( sprintf( _n( '%1$s for %2$s item', '%1$s for %2$s items', $item_count, 'woocommerce' ), $order->get_formatted_order_total(), $item_count ) );
								?></span>
								
									</div>
									<div class="Flex-w-child wishlist_auth">
									  <!--span class="Icons-divs"></span><span class="Txt-Lft"></span-->
									  <?php echo $wishlist_icon; ?>
									</div>
									<?php if(is_user_logged_in() && ($authorid == get_current_user_id() )){ ?>
									<div class="Resell_author_btn">
										<?php echo $resell_html; ?>
									</div>
									<?php } ?>
								  </div>
								  
								</div>
							 
							</div>
						</div>
					<?php  }  } } }
							 
							 /* while ( $loop_one->have_posts() ) : $loop_one->the_post(); 
							 $product_id = get_the_ID();
							 $c_owned++;
								author_product_box($product_id,'owned',$authorid); //custom-function.php
							 
							 endwhile; */
							 
							 if( $c_owned == 0){
								 echo '<div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>';
							 }
							 
							 
							 
							 }else{ ?>
							 
								<div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>
							 <?php } ?>
			</div>
          </div>
		  <!---------------------------END OWNED ------------------------>
          <div class="tab-pane" id="Sold">
			<div class="Author-Flx-Card">
			<?php 
			$soldData = getsoldlistData($authorid);
			$count_resell=0;
				  if($soldData){
				  
				  foreach($soldData as $listID_active){
					  $count_resell++;
					  author_product_box($listID_active,'sold',$authorid);	
					}
				  }else{ ?>
				  <div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>
				  <?php }?>
    
            </div>
          </div> 
          <div class="tab-pane" id="Preferred">
			
				<?php 
				 global $wpdb;
				 /* var_dump($authorid); */
            $sql = "SELECT ID FROM {$wpdb->yith_wcwl_wishlists} WHERE user_id = {$authorid}";
			 $results = $wpdb->get_results($sql);
			 /* var_dump($results); */
			 if($results){
			foreach($results as $results_id){
				$wish_id = $results_id->ID;
			}
			/* var_dump($wish_id); */
			if($wish_id){
				echo do_shortcode('[yith_wcwl_wishlist wishlist_id='.$wish_id.']');  
			}else{ ?>
				<script>
				
					jQuery(document).ready(function(){
					jQuery('.custom-Tabs-txt li a span.small.c_preferred').text('(0)');
					});
				</script>
					<div class="Author-Flx-Card">
				  <div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>
				  </div>
			 <?php } }else{ ?>
			 <script>
					jQuery(document).ready(function(){
						jQuery('.custom-Tabs-txt li a span.small.c_preferred').text('(0)');
					});
				</script>
					<div class="Author-Flx-Card">
				  <div class="noFound"><h3>no items found</h3><p>come back soon!</p></div>
				  </div>
				
			 <?php }?>
			
		  </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
jQuery(document).ready(function(){
	jQuery('span.c_active').text('(<?php echo $count_active; ?>)');
	jQuery('span.c_resell').text('(<?php echo $count_resell; ?>)');
	jQuery('span.c_owned').text('(<?php echo $c_owned; ?>)');
	/*  jQuery('span.c_preferred').text('(<?php echo $c_preferred; ?>)');  */
});
</script>
<?php 
require_once('footer.php');
get_footer(); ?>