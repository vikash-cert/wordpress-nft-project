<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<?php 
#Redux global variable

 /* var_dump($_SESSION['logged_in_custom']);  */
/* if((!isset($_SESSION['logged_in_custom'])) && $_GET['custom_logout'] == 'yes'){
	$site_url = get_site_url();
	wp_redirect( $site_url );
	exit;
}  */
//echo get_post_meta(9578,'apiresponse',true);
?>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) { ?>
        <link rel="shortcut icon" href="<?php echo esc_url(ibid_redux('ibid_favicon', 'url')); ?>">
    <?php } ?>
	<script src="https://cdn.tiny.cloud/1/13hcw5okkr20wxb0y9jhx2ex4mpmhux37t7zwgboicdwtcuc/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php  /* $exist_order_wallet_address = get_user_meta(430,'metamaskAddress',true);
	var_dump($exist_order_wallet_address);
	 $wallet_store_onprod_purchase = get_post_meta(9954,'wallet_store_onprod_purchase',true); 
$last_element_stored = end($wallet_store_onprod_purchase);

	var_dump($last_element_stored);  */
    /**
    * Since WordPress 5.2
    */
    if ( function_exists( 'wp_body_open' ) ) {
        wp_body_open();
    }
	
	/* phpinfo(); */

    if (!is_user_logged_in()) {
        if (!in_array('login-register-page', get_body_class())) { ?>
            <div class="modeltheme-modal" id="modal-log-in">
                <div class="modeltheme-content" id="login-modal-content">
                    <h3 class="relative">
                        <?php echo esc_html__('Login to Your Account', 'ibid'); ?>
                    </h3>
                    <div class="modal-content row">
                        <div class="col-md-12">
							<?php echo do_shortcode('[nextend_social_login provider="facebook"]'); ?>
							<?php// echo do_shortcode('[nextend_social_login provider="google"]'); ?>
							<?php echo do_shortcode('[nextend_social_login provider="twitter"]'); ?>
								
                        
					    <form id="login" action="login" method="post">
                                <p class="status"></p>
                                <p class="login-username">
                                    <label for="username"><?php echo esc_html__('Username or Email Address','ibid'); ?></label>
                                    <i class="fa fa-user-o" aria-hidden="true"></i>
                                    <input id="username" type="text" name="username" placeholder="<?php echo esc_attr__('username','ibid'); ?>" required>
                                </p>
                                <p class="login-password">
                                    <label for="password"><?php echo esc_html__('Password','ibid'); ?></label>
                                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                    <input id="password" type="password" name="password" placeholder="<?php echo esc_attr__('password','ibid'); ?>" maxlength="25" required>
                                </p>
                                
                                <div class="row-buttons">
                                     <p class="login-submit">
                                        <input class="submit_button" type="submit" value="<?php echo esc_attr__('Login','ibid'); ?>" name="submit">
                                    </p>
                                    <?php if (  get_option('users_can_register')) { ?>
                                        <p class="btn-register-p">
                                            <a class="btn btn-register" id="register-modal"><?php echo esc_html__('Register','ibid'); ?></a>
                                        </p>
                                    <?php } else { ?>
                                        <p class="um-notice err text-center"><?php echo esc_html__('Registration is currently disabled','ibid'); ?></p>
                                    <?php } ?>
                                </div>
                                <div class="clearfix"></div>
                                <p class="login-remember">
                                    <a class="lost" href="<?php echo wp_lostpassword_url(); ?>"><?php echo esc_html__('Lost your password?','ibid'); ?></a>
                                </p>
                                <?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
                            </form>
							 <form id="OtpForm" style="display:none;">
                                <p class="status"></p>
                                <p class="login-username" style="position:relative;">
                                    <label for="username"><?php echo esc_html__('Please enter OTP','ibid'); ?></label>
                                    <i class="fa fa-key" aria-hidden="true"></i>
                                    <input id="otp" type="text" name="otp" placeholder="<?php echo esc_attr__('OTP','ibid'); ?>">
                                </p>
                               
                                
                                <div class="row-buttons">
                                     <p class="login-submit">
                                        <input class="submit_button" type="submit" value="<?php echo esc_attr__('Submit','ibid'); ?>" name="submit">
                                    </p>
                                    <?php if (  get_option('users_can_register')) { ?>
                                        <p class="btn-register-p">
                                            <a class="btn btn-register" id="register-modal"><?php echo esc_html__('Register','ibid'); ?></a>
                                        </p>
                                    <?php } else { ?>
                                        <p class="um-notice err text-center"><?php echo esc_html__('Registration is currently disabled','ibid'); ?></p>
                                    <?php } ?>
                                </div>
                                <div class="clearfix"></div>
                                <?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
                            </form>

                           
                            <?php if (function_exists('YITH_WC_Social_Login')) { ?>
                                <?php if(get_option('ywsl_facebook_enable') == 'yes' || get_option('ywsl_google_enable') == 'yes' || get_option('ywsl_twitter_enable') == 'yes' ){ ?>
                                    <div class="separator-modal"><?php echo esc_html__('OR ','ibid'); ?></div>
                                    <?php echo do_shortcode("[yith_wc_social_login]"); ?>
                                <?php } ?>
                            <?php } ?>
							
                        </div>
                    </div>
                </div>
                <div class="modeltheme-content" id="signup-modal-content">
                    <h3 class="relative">
                        <?php echo esc_html__('Personal Details','ibid'); ?>
                    </h3>
                    <div class="modal-content row">
                        <div class="col-md-12">
							<?php echo do_shortcode('[nextend_social_login provider="facebook"]'); ?>
							<?php //echo do_shortcode('[nextend_social_login provider="google"]'); ?>
							<?php echo do_shortcode('[nextend_social_login provider="twitter"]'); ?>
								
                        
                            <?php if ( class_exists( 'WooCommerce' ) ) { ?>
                                <?php if ( get_option( 'woocommerce_enable_myaccount_registration' ) === 'yes' ) { ?>
                                    <div class="u-column2 col-2">
                                        <?php do_action( 'woocommerce_before_customer_login_form' ); ?>
                                        <form id="register" method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?>>
                                            <p class="status"></p>
                                            <?php do_action( 'woocommerce_register_form_start' ); ?>
                                            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username"  autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" placeholder="<?php esc_attr_e( 'username', 'ibid' ); ?>" required />
                                                    <span id="valid_username" style="color: red;"></span>
                                                    
                                                </p>
                                            <?php endif; ?>
                                            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email"  value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" placeholder="<?php esc_attr_e( 'email address', 'ibid' ); ?>" required />
                                            </p>
											<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide cstm_mphn">
                                                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="billing_mobile_phone" id="reg_billing_mobile_phone" autocomplete="mobile_phone"  value="<?php echo ( ! empty( $_POST['billing_mobile_phone'] ) ) ? esc_attr(  $_POST['billing_mobile_phone']  ) : ''; ?>" placeholder="<?php esc_attr_e( 'mobile phone', 'ibid' ); ?>" />
                                            </p>
                                            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
                                                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <!--input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" placeholder="<?php esc_attr_e( 'Password', 'ibid' ); ?>" maxlength="25" onKeyUp="checkPasswordStrength();" /-->
													<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" placeholder="<?php esc_attr_e( 'password', 'ibid' ); ?>" maxlength="25"  />
													<span class="show-password-input"></span>
                                                    <span id="password-strength-header"></span>
													<!-- <span  id="password-strength-status"></span> -->
													<small class="cstm_woo_hint" style="display:none;">hint: the password should be at least six characters long. to make it stronger, use upper and lower case letters, numbers, and symbols like ! " ? $ % ^ &amp; ).</small>
                                                </p>
												<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                                                    <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="confirm_password" id="reg_confirm_password" autocomplete="" placeholder="<?php esc_attr_e( 'confirm password', 'ibid' ); ?>"  />
                                                    <span class="show-password-input"></span>
													<span  id="valid_password"></span>

                                                </p>
                                            <?php else : ?>
                                                <p><?php esc_html_e( 'A password will be sent to your email address.', 'ibid' ); ?></p>
                                            <?php endif; ?>
                                            <?php do_action( 'woocommerce_register_form' ); ?>
                                            <p class="woocommerce-FormRow form-row">
                                                <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
                                                <button type="submit" class="woocommerce-Button button" name="register" value="<?php esc_attr_e( 'Register', 'ibid' ); ?>"><?php esc_html_e( 'Register', 'ibid' ); ?></button>
                                                <!-- Back to login -->
                                                <a class="btn btn-login btn-login-p" id="login-modal"><?php echo esc_html__('back to Login','ibid'); ?></a>
                                            </p>

                                            <?php do_action( 'woocommerce_register_form_end' ); ?>
                                            <?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
                                        </form>
										
                                        <?php if (function_exists('YITH_WC_Social_Login')) { ?>
                                            <?php if(get_option('ywsl_facebook_enable') == 'yes' || get_option('ywsl_google_enable') == 'yes' || get_option('ywsl_twitter_enable') == 'yes' ){ ?>
                                                <div class="separator-modal"><?php echo esc_html__('OR ','ibid'); ?></div>
                                                <?php echo do_shortcode("[yith_wc_social_login]"); ?>
                                            <?php } ?>
                                        <?php } ?>
										
                                    </div>
                                <?php } ?>
                            <?php } ?>
                        </div>
                    </div>            
                </div>
            </div>
        <?php } ?>
    <?php } ?>
    <?php
    if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
        if ($ibid_redux['ibid-enable-popup'] == true) {
            echo ibid_popup_modal(); 
        }
    }?>
    <div class="modeltheme-overlay"></div>

    
    <!-- Fixed Search Form -->
    <div class="fixed-search-overlay">
        <!-- Close Sidebar Menu + Close Overlay -->
        <i class="icon-close icons"></i>
        <!-- INSIDE SEARCH OVERLAY -->
        <div class="fixed-search-inside">
            <div class="modeltheme-search">
                <?php do_action('ibid_products_search_form'); ?>
            </div>
        </div>
    </div>
        
    <div id="page" class="hfeed site">
    <?php
        if (is_page()) {
            $mt_custom_header_options_status = get_post_meta( get_the_ID(), 'ibid_custom_header_options_status', true );
            $mt_header_custom_variant = get_post_meta( get_the_ID(), 'ibid_header_custom_variant', true );
            if (isset($mt_custom_header_options_status) AND $mt_custom_header_options_status == 'yes') {
                get_template_part( 'templates/header-template'.esc_html($mt_header_custom_variant) );
            }else{
                if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                    // DIFFERENT HEADER LAYOUT TEMPLATES
                    if ($ibid_redux['header_layout'] == 'first_header') {
                        // Header Layout #1
                        get_template_part( 'templates/header-template1' );
                    }elseif ($ibid_redux['header_layout'] == 'second_header') {
                        // Header Layout #2
                        get_template_part( 'templates/header-template2' );
                    }elseif ($ibid_redux['header_layout'] == 'third_header') {
                        // Header Layout #3
                        get_template_part( 'templates/header-template3' );
                    }elseif ($ibid_redux['header_layout'] == 'fourth_header') {
                        // Header Layout #4
                        get_template_part( 'templates/header-template4' );
                    }elseif ($ibid_redux['header_layout'] == 'fifth_header') {
                        // Header Layout #5
                        get_template_part( 'templates/header-template5' );
                    }elseif ($ibid_redux['header_layout'] == 'sixth_header') {
                        // Header Layout #5
                        get_template_part( 'templates/header-template6' );
                    }elseif ($ibid_redux['header_layout'] == 'seventh_header') {
                        // Header Layout #5
                        get_template_part( 'templates/header-template7' );
                    }else{
                        // if no header layout selected show header layout #1
                        get_template_part( 'templates/header-template1' );
                    } 
                }else{
                    // if no header layout selected show header layout #1
                    get_template_part( 'templates/header-template1' );
                }
            }
        }else{
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                // DIFFERENT HEADER LAYOUT TEMPLATES
                if ($ibid_redux['header_layout'] == 'first_header') {
                    // Header Layout #1
                    get_template_part( 'templates/header-template1' );
                }elseif ($ibid_redux['header_layout'] == 'second_header') {
                    // Header Layout #5
                    get_template_part( 'templates/header-template2' );
                }elseif ($ibid_redux['header_layout'] == 'third_header') {
                    // Header Layout #5
                    get_template_part( 'templates/header-template3' );
                }elseif ($ibid_redux['header_layout'] == 'fourth_header') {
                        // Header Layout #4
                        get_template_part( 'templates/header-template4' );
                }elseif ($ibid_redux['header_layout'] == 'fifth_header') {
                    // Header Layout #5
                    get_template_part( 'templates/header-template5' );
                }elseif ($ibid_redux['header_layout'] == 'sixth_header') {
                    // Header Layout #5
                    get_template_part( 'templates/header-template6' );
                }elseif ($ibid_redux['header_layout'] == 'seventh_header') {
                        // Header Layout #5
                        get_template_part( 'templates/header-template7' );
                }else{
                    // if no header layout selected show header layout #1
                    get_template_part( 'templates/header-template1' );
                }
            }else{
                // if no header layout selected show header layout #1
                get_template_part( 'templates/header-template1' );
            }
        }
		