<?php global $ResaleTransaction;
$ResaleTransaction = new ResaleTransaction();
class ResaleTransaction{
     public function __construct() {
        add_action('admin_menu', [$this, 'create_reports']);

     }
    public function create_reports() {
        if ( class_exists( 'WooCommerce' ) ) {
       add_menu_page( 'Resale Transaction', 'Resale Transaction', 'manage_options', 'resale_transaction', array(&$this, 'resale_transaction'),'dashicons-text-page', '10' );
        }
       
    }

    public function resale_transaction() {
       
        $resaleListTable = new Resale_List_Table();
        $resaleListTable->prepare_items();
        ?>
           <div class="wrap">
                <div id="icon-users" class="icon32"></div>
                <h2>Resale Transaction</h2>
                <form method="get">
                  <input type="hidden" name="page" value="resale_transaction" />
                  <?php $resaleListTable->search_box('search', 'search_id'); ?>
                </form>
                <?php $resaleListTable->display(); ?>
            </div>
        <?php
    }
    
    
    
}
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Resale_List_Table extends WP_List_Table
{
    /**
     * Prepare the items for the table to process
     *
     * @return Void
     */
    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $data = $this->table_data();
        usort( $data, array( &$this, 'sort_data' ) );

        $perPage =15;
        $currentPage = $this->get_pagenum();
        $totalItems = count($data);

        $this->set_pagination_args( array(
            'total_items' => $totalItems,
            'per_page'    => $perPage
        ) );

        $data = array_slice($data,(($currentPage-1)*$perPage),$perPage);

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $data;
    }

    function search_box( $text, $input_id ) {
        if ( empty( $_REQUEST['s'] ) && !$this->has_items() )
            return;
    
        $input_id = $input_id . '-search-input';
    
        if ( ! empty( $_REQUEST['orderby'] ) )
            echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
        if ( ! empty( $_REQUEST['order'] ) )
            echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
        if ( ! empty( $_REQUEST['post_mime_type'] ) )
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        if ( ! empty( $_REQUEST['detached'] ) )
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
    ?>
    <p class="search-box">
    <label class="screen-reader-text" for="<?php echo $input_id ?>"><?php echo $text; ?>:</label>
    <input type="search" id="<?php echo $input_id ?>" name="s" value="<?php _admin_search_query(); ?>" />
    <?php submit_button( $text, 'button', false, false, array('id' => 'search-submit') ); ?>
    </p>
    <?php
    }
    

    /**
     * Override the parent columns method. Defines the columns to use in your listing table
     *
     * @return Array
     */
    public function get_columns()
    {
        $columns = array(
           // 'id'          => 'S.no',
            'userid'       => 'User Name',
            'fromAddress' => 'From Address',
            'toAddress' => 'To Address',
            'amount'        => 'Amount',
            'adminCommision' => 'Admin Commission',
            'royaltyCommision' => 'Royalty Commission',
            'totalAmount' => 'Total Amount',
            'orderId' => 'Order Id',
            'paymentMethod' => 'Payment Method',
            'txHash'    => 'TxHash',
            'create_date' => 'Date'
        );

        return $columns;
    }

    /**
     * Define which columns are hidden
     *
     * @return Array
     */
    public function get_hidden_columns()
    {
        return array();
    }

    /**
     * Define the sortable columns
     *
     * @return Array
     */
    // public function get_sortable_columns()
    // {
    //     return array('title' => array('title', false));
    // }
    function get_sortable_columns() {
        $sortable_columns = array(
          'userid'  => array('userid',false),
          'fromAddress' => array('fromAddress',false),
          'toAddress' => array('toAddress',false),
          'amount' => array('amount',false),
          'adminCommision' => array('adminCommision',false),
          'totalAmount' => array('totalAmount',false),
          'orderId' => array('orderId',false),
          'create_date' => array('create_date',false),
        
        );
        return $sortable_columns;
      }
      
    /**
     * Get the table data
     *
     * @return Array
     */
    private function table_data()
    {
        $data = array();
       global $wpdb;

       $search = ( isset( $_REQUEST['s'] ) ) ? $_REQUEST['s'] : false;
        if($search){
            // search for username only
            $name_array = preg_split("/[\s,]+/", $search);
            $users = new WP_User_Query(array(
                'meta_query' => array(
                    'relation' => 'OR',
                    array(
                        'key' => 'first_name',
                        'value' => $name_array[0],
                        'compare' => 'LIKE'
                    ),
                    array(
                        'key' => 'last_name',
                        'value' => $name_array[1]?$name_array[1]:$name_array[0],
                        'compare' => 'LIKE'
                    ),
                    array(
                        'key' => 'first_name',
                        'value' => $name_array[1]?$name_array[1]:$name_array[0],
                        'compare' => 'LIKE'
                    ),
                    array(
                        'key' => 'last_name',
                        'value' => $name_array[0],
                        'compare' => 'LIKE'
                    )
                )
                    ));
                $users_found = $users->get_results();
                $user_ids = array();
                //echo "<pre>";print_r($users_found);
                foreach($users_found as $users_founds){
                    $user_ids[] = $users_founds->data->ID;
                    //WHERE genre IN (1, 8, 3)                   
            
                }
                $arrayIds = implode("','",$user_ids);
                $vararar =  " OR userid IN ('".$arrayIds."')";
                $do_search = ( $search ) ? " AND adminCommission LIKE '%$search%' OR fromAddress = '$search' OR toAddress = '$search' OR amount = '$search' OR txHash = '$search' OR orderId = '$search'" : '';
                if(strlen($arrayIds) != 0){
                    $do_search.= $vararar;
                }
                //echo 'SELECT * FROM wp_wallet_transaction_history where type="resellproductamount" '.$do_search.' ORDER BY create_date DESC';
                $results = $wpdb->get_results('SELECT * FROM wp_wallet_transaction_history where type="resellproductamount" '.$do_search.' ORDER BY create_date DESC');
                //echo "<pre>";print_r($results);
                  
            
        }else{

            if(!empty($_GET['orderby']))
            {
                $orderby = $_GET['orderby'];

                if($orderby == 'amount') {
                    $orderby = 'CAST(amount AS DECIMAL(18,4))';
                }
                if($orderby == 'adminCommision') {
                    $orderby = 'adminCommission';
                }
            }

            if(!empty($_GET['order']))
            {
                $order = $_GET['order'];
            }

            if(!empty($_GET['order']) && !empty($_GET['orderby'])) {
                $results = $wpdb->get_results('SELECT * FROM wp_wallet_transaction_history where type="resellproductamount" ORDER BY '.$orderby.' '.$order.'');    
            } else {
                $results = $wpdb->get_results('SELECT * FROM wp_wallet_transaction_history where type="resellproductamount" ORDER BY create_date DESC');                
            }
            

            //$results = $wpdb->get_results('SELECT * FROM wp_wallet_transaction_history where type="resellproductamount" ORDER BY create_date DESC');
        }

        $i = 1;
        $j = 1;
        
        
        foreach ($results as $data_results){

            $order_id = $data_results->orderId;
            $order = wc_get_order( $order_id );
            
            if($order) {
                foreach( $order->get_items() as $item ){
                
                    if( is_null($item->get_product_id())){
                        $product_id = '';
                  }else{
                  
                    $product_id = $item->get_product_id();
                  
                  }
                }
            }
            
            // print_r($product_id);
            // $productRoyaltyCommission = ;
            if($order_id){
                $paymentMethod = get_post_meta( $order_id, '_payment_method', true );
                if($paymentMethod == 'meta_gateway'){
                    $paymentMethod = 'MetaMask Payment Gateway';
                }
            }else{
                $paymentMethod = '';
            }
           // $data[$i]['id']= $j;
            $conversion_rate = get_option('convertion_rate');
            $productRoyaltyCommission = get_post_meta($product_id,'pv_royalty_commission_rate',true);
            if($productRoyaltyCommission) {
                $royaltyComission = $productRoyaltyCommission. '%';
            } else {
                $vendor_id = WCV_Vendors::get_vendor_from_product( $product_id );
                $user_meta = get_userdata($vendor_id);
                $user_roles = $user_meta->roles;
                if(in_array("vendor", $user_roles)){
                    $royaltyComission = get_option('wcvendors_vendor_creatore_royalty',true). '%';
                } else {
                    $royaltyComission = '';
                }
            }
            // $royaltyComission = get_option('wcvendors_vendor_creatore_royalty');

            $total =  number_format($data_results->amount,2);
            $eth = $conversion_rate->ETH;
            $normal_ETH = $data_results->amount*$eth;
            $normal_ETH = number_format($normal_ETH, 5, '.', '');

            $data[$i]['userid']= '<a href="'.get_site_url().'/wp-admin/user-edit.php?user_id='.$data_results->userid.'">'.get_user_meta($data_results->userid, 'first_name', true) . ' ' . get_user_meta($data_results->userid, 'last_name', true).'</a>';
            $data[$i]['fromAddress']= $data_results->fromAddress;
            $data[$i]['toAddress']= $data_results->toAddress;
            $data[$i]['amount']= $total.' USD  ('.$normal_ETH.' ETH)';
            $data[$i]['adminCommision']= $data_results->adminCommission;
            $data[$i]['royaltyCommision']= $royaltyComission;
            $data[$i]['totalAmount']= $data_results->totalAmount;
            $data[$i]['orderId']= '<a href="'.get_site_url().'/wp-admin/post.php?post='.$data_results->orderId.'&action=edit">'.$data_results->orderId.'</a>';
            $data[$i]['paymentMethod']= $paymentMethod;
            $data[$i]['txHash']= $data_results->txHash;
            $data[$i]['create_date']= $data_results->create_date;
               $i++;
               $j++;
        }
        return $data;
    }

    /**
     * Define what data to show on each column of the table
     *
     * @param  Array $item        Data
     * @param  String $column_name - Current column name
     *
     * @return Mixed
     */
    public function column_default( $item, $column_name )
    {
        switch( $column_name ) {
         //   case 'id':
            case 'userid':
            case 'fromAddress':
            case 'toAddress';
            case 'amount':
              case 'adminCommision':
              case 'royaltyCommision':
                case 'totalAmount':
                case 'orderId':
                  case 'paymentMethod':
                    
            case 'txHash':
            case 'create_date';
                return $item[ $column_name ];

            default:
                return print_r( $item, true ) ;
        }
    }

    /**
     * Allows you to sort the data by the variables set in the $_GET
     *
     * @return Mixed
     */
    private function sort_data( $a, $b )
    {
        // Set defaults
        $orderby = 'id';
        $order = 'asc';

        // If orderby is set, use this as the sort column
        if(!empty($_GET['orderby']))
        {
            $orderby = $_GET['orderby'];
        }

        // If order is set use this as the order
        if(!empty($_GET['order']))
        {
            $order = $_GET['order'];
        }


        $result = strcmp( $a[$orderby], $b[$orderby] );

        if($order === 'asc')
        {
            return $result;
        }

        return -$result;
    }

    


}