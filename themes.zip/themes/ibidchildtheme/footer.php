<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package ibid
 */
?>
<?php
//phpinfo();

global $ibid_redux;
	/*if(isset($_GET['akey'])){
				  $verification = base64_decode($_GET['verificationaccount']);
				
				  $key = $_GET['akey'];
				  $userData = explode('_',$verification);
				  $key_exists = get_user_meta($userData[2],'activation_pass_key',true);
				  $check_last_date = get_user_meta($userData[2], 'last_link_date', true);
				
				  //echo $key_exists;
				  //echo $key;	
				// delete_user_meta($userData[2],'activation_pass_key');
				  if(!empty($key_exists) && ($key_exists == $key) && ( strtotime(current_time('mysql')) - $check_last_date < 15 * 60)){
					  $key_status = get_user_meta($userData[2],'status',true);
					  if($key_status == 'inactive'){
						  update_user_meta($userData[2],'status','active');
						  delete_user_meta($userData[2],'activation_pass_key');
						  ?>
						  <div class="alert alert-success alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<strong>Congratulations!</strong> Your account has been verified. Please login your account with your credientials!!
</div>
						
						<?php  
					  }else{
						  
					  } 
				  }else{
					  ?>
					  			  <div class="alert alert-danger alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
your linked has been expired!!!
</div>
				 <?php 
				 }
		
	}*/

?>

    <?php if ( !class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
        <!-- BACK TO TOP BUTTON -->
        <a class="back-to-top modeltheme-is-visible modeltheme-fade-out" href="<?php echo esc_url('#0'); ?>">
            <span></span>
        </a>
    <?php }else{ ?>
        <?php if (ibid_redux('ibid_backtotop_status') == true) { ?>
            <!-- BACK TO TOP BUTTON -->
           <a class="back-to-top modeltheme-is-visible modeltheme-fade-out" href="<?php echo esc_url('#0'); ?>">
                <span></span>
            </a>
        <?php } ?>
    <?php } ?>

    <?php
        $footer_widgets = 'no-footer-widgets';
        if ( is_active_sidebar( 'footer_column_1' ) || is_active_sidebar( 'footer_column_2' ) || is_active_sidebar( 'footer_column_3' ) || is_active_sidebar( 'footer_column_4' ) || is_active_sidebar( 'footer_column_5' ) ) {
            $footer_widgets = 'has-footer-widgets';
        }
    ?>
    <!-- MAIN FOOTER -->
    <footer class="<?php echo esc_attr($footer_widgets); ?>">
        <?php if ( class_exists( 'ReduxFrameworkPlugin' ) || class_exists( 'WooCommerce' ) ) { ?>
            <?php if (ibid_redux('ibid-enable-footer-top') == true) { ?>
                <div class="top-footer row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 left"><?php esc_html_e( 'browse through our products library!', 'ibid' ); ?></div>
                            <div class="col-md-4">
                                <form name="myform" method="GET" class="woocommerce-product-search menu-search" action="<?php echo esc_url(home_url('/')); ?>">
                                    <input type="hidden" value="product" name="post_type">
                                    <input type="text"  name="s" class="search-field" maxlength="128" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php esc_attr_e('Search products...', 'ibid'); ?>">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i></button>
                                    <input type="hidden" name="post_type" value="product" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>

        <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
            <div class="container footer-top">
                <?php if ( $ibid_redux['ibid-enable-footer-widgets'] ) { ?>
                    <div class="row footer-row-1">
                        <?php
                        $columns    = 12/intval($ibid_redux['ibid_number_of_footer_columns']);
                        $nr         = array("1", "2", "3", "4", "6");

                        if (in_array($ibid_redux['ibid_number_of_footer_columns'], $nr)) {
                            $class = 'col-md-'.esc_html($columns);
                            for ( $i=1; $i <= intval( $ibid_redux['ibid_number_of_footer_columns'] ) ; $i++ ) { 

                                echo '<div class="'.esc_attr($class).' widget widget_text">';
                                    dynamic_sidebar( 'footer_column_'.esc_html($i) );
                                echo '</div>';

                            }
                        }elseif($ibid_redux['ibid_number_of_footer_columns'] == 5){
                            #First
                            if ( is_active_sidebar( 'footer_column_1' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_1' );
                                echo '</div>';
                            }
                            #Second
                            if ( is_active_sidebar( 'footer_column_2' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_2' );
                                echo '</div>';
                            }
                            #Third
                            if ( is_active_sidebar( 'footer_column_3' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_3' );
                                echo '</div>';
                            }
                            #Fourth
                            if ( is_active_sidebar( 'footer_column_4' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_4' );
                                echo '</div>';
                            }
                            #Fifth
                            if ( is_active_sidebar( 'footer_column_5' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_5' );
                                echo '</div>';
                            }
                        }
                        ?>
						
                    </div>
				
                <?php } ?>

                <?php if ($ibid_redux['ibid-enable-footer-widgets-row2']) { ?>
                    <div class="row footer-row-2">
                        <?php
                        $columns    = 12/intval($ibid_redux['ibid_number_of_footer_columns_row2']);
                        $nr         = array("1", "2", "3", "4", "6");

                        if (in_array($ibid_redux['ibid_number_of_footer_columns_row2'], $nr)) {
                            $class = 'col-md-'.esc_html($columns);
                            for ( $i=1; $i <= intval( $ibid_redux['ibid_number_of_footer_columns_row2'] ) ; $i++ ) { 

                                echo '<div class="'.esc_attr($class).' widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row2'.esc_html($i) );
                                echo '</div>';

                            }
                        }elseif($ibid_redux['ibid_number_of_footer_columns_row2'] == 5){
                            #First
                            if ( is_active_sidebar( 'footer_column_row21' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row21' );
                                echo '</div>';
                            }
                            #Second
                            if ( is_active_sidebar( 'footer_column_row22' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row22' );
                                echo '</div>';
                            }
                            #Third
                            if ( is_active_sidebar( 'footer_column_row23' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row23' );
                                echo '</div>';
                            }
                            #Fourth
                            if ( is_active_sidebar( 'footer_column_row24' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row24' );
                                echo '</div>';
                            }
                            #Fifth
                            if ( is_active_sidebar( 'footer_column_row25' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row25' );
                                echo '</div>';
                            }
                        }
                        ?>
                    </div>
                <?php } ?>

                <?php if ($ibid_redux['ibid-enable-footer-widgets-row3']) { ?>
                    <div class="row footer-row-3">
                        <?php
                        $columns    = 12/intval($ibid_redux['ibid_number_of_footer_columns_row3']);
                        $nr         = array("1", "2", "3", "4", "6");

                        if (in_array($ibid_redux['ibid_number_of_footer_columns_row3'], $nr)) {
                            $class = 'col-md-'.esc_html($columns);
                            for ( $i=1; $i <= intval( $ibid_redux['ibid_number_of_footer_columns_row3'] ) ; $i++ ) { 

                                echo '<div class="'.esc_attr($class).' widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row3'.esc_html($i) );
                                echo '</div>';

                            }
                        }elseif($ibid_redux['ibid_number_of_footer_columns_row3'] == 5){
                            #First
                            if ( is_active_sidebar( 'footer_column_row31' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row31' );
                                echo '</div>';
                            }
                            #Second
                            if ( is_active_sidebar( 'footer_column_row32' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row32' );
                                echo '</div>';
                            }
                            #Third
                            if ( is_active_sidebar( 'footer_column_row33' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row33' );
                                echo '</div>';
                            }
                            #Fourth
                            if ( is_active_sidebar( 'footer_column_row34' ) ) {
                                echo '<div class="col-md-2 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row34' );
                                echo '</div>';
                            }
                            #Fifth
                            if ( is_active_sidebar( 'footer_column_row35' ) ) {
                                echo '<div class="col-md-3 widget widget_text">';
                                    dynamic_sidebar( 'footer_column_row35' );
                                echo '</div>';
                            }
                        }
                        ?>
                    </div>
                <?php } ?>
            </div>
			
			
        <?php } ?>
			<div class="disclaimer_footer">
							<p><b>Disclaimer:</b> Our donations to the charities listed above should not be construed as an endorsement of these charities by aniseed.com or as an endorsement of aniseed.com by these charities. In short, no contract, partnership, agreement, endorsement, or other similar relationship should be implied from our support of the various charities we have listed above.</p>
						</div>

        <?php do_action('ibid_before_footer_mobile_navigation'); ?>

        <?php /*<div class="footer footer-copyright">
            <div class="container">
                <div class="row">
                    <?php if ( class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
                        <div class="col-md-6">
                            <p class="copyright"><?php echo wp_kses($ibid_redux['ibid_footer_text_left'], 'link'); ?></p>
                        </div>
                        <div class="col-md-6 payment-methods">
                            <!--p class="copyright"><?php echo wp_kses($ibid_redux['ibid_footer_text_right'], 'link'); ?></p-->
							
							<ul class="social_icon"> 
							   <li><a target="_blank" href="https://twitter.com/citiesabc__"><i class="fa fa-twitter"></i></a></li> 
							   <li><a target="_blank" href="https://www.instagram.com/citiesabc"><i class="fa fa-instagram"></i></a></li> 
							   <li><a target="_blank" href="https://www.facebook.com/citiesabc"><i class="fa fa-facebook"></i></a></li> 
						   </ul>
                        </div>
                    <?php }else { ?>
                        <div class="col-md-6">
                            <p class="copyright"><?php esc_html_e( 'Copyright by ModelTheme. All Rights Reserved.', 'ibid' ); ?></p>
                        </div>
                        <div class="col-md-6 payment-methods">
                            <p class="copyright"><?php esc_html_e( 'Elite Author on ThemeForest', 'ibid' ); ?></p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div> */ ?>
    </footer>
</div>
<div class="ApWait" style="display: none;">
  <div class="loader_child">
    <div id="loading-bar-spinner" class="spinner">
      <div class="spinner-icon"></div>
    </div>
  </div>
</div>
<input id="siteurl" value="<?php echo get_site_url();?>" type="hidden">

<?php if(is_user_logged_in()){ 
$author_ID = get_current_user_id();
$user_info = get_userdata( get_current_user_id() );
	$first_name = $user_info->first_name;
      $last_name = $user_info->last_name;
      $user_url = $user_info->user_url;
	  $full_name = $first_name?($first_name.' '.$last_name):''; 
	   $aut_dec = get_user_meta($author_ID, 'description', true);
	    $user_bio = get_field('user_biography','user_'.$author_ID);
	    $user_location = get_field('user_location','user_'.$author_ID);
	    $wall_add = get_field('creator_wallet_address','user_'.$author_ID);
		
		$user_fb = get_field('facebook_link','user_'.$author_ID);
    $user_youtube = get_field('youtube_link','user_'.$author_ID);
    $user_insta = get_field('instagram_link','user_'.$author_ID);
    $user_twitter = get_field('twitter_link','user_'.$author_ID);
	$social_arr=array();
	 if($user_fb != '' || $user_youtube != '' || $user_twitter != '' || $user_insta != ''){
		 $social_arr['fb'] = $user_fb?$user_fb:'';
	$social_arr['youtube'] = $user_youtube?$user_youtube:'';
	$social_arr['insta'] = $user_insta?$user_insta:'';
	$social_arr['twitter'] = $user_twitter?$user_twitter:'';
	 }
	
		
	$author_avatar = get_wp_user_avatar($author_ID, 279);
	
	$user_category = get_field('select_category','user_'.$author_ID);
	
	  ?>
<div class="modal" tabindex="-1" role="dialog" id="EditProfile">
  <div class="modal-dialog Custom-Edit-Profile" role="document">
    <div class="modal-content">
	<form action="" id="profile_update" method="get" accept-charset="utf-8">
      <div class="modal-body All-Info">
        <h2>edit profile</h2>
        
          <div class="Flex-Wrap-Popup">
            <div class="Popup-Child-1">
              <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12 Form-Equal">
                  <input type="text" value="<?php if($full_name){echo $full_name; } ?>" class="Custom-Input" placeholder="first and last name" id="firstname">
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12 Form-Equal">
                  <input type="text" class="Custom-Input" value="<?php echo $user_info->user_login; ?>" placeholder="username*" id="username" disabled>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12 Form-Equal">
                  <label for="email">&nbsp; </label>
                  <input type="email" value="<?php echo $user_info->user_email; ?>" class="Custom-Input" placeholder="email" id="emailaddress" disabled>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12 Form-Equal">
                  <label for="email">&nbsp; </label>
				  <?php $terms_cat = get_terms( array(
						'taxonomy' => 'product_cat',
						'hide_empty' => false,
					) ); ?>
                  <select class="Custom-Input chosen-select select_cat" id="" data-placeholder="Select Category *" multiple  name="test">
				 
				  <?php $sel_category=array();$count_sel=0;
							$count_place=0; foreach( $terms_cat as $category ) { 
						if($category->slug != 'uncategorized'){
							
							if(in_array($category->term_id, $user_category)){
								
								$sel_category[$count_sel] = $category->term_id; 
								$count_sel++;
							} if($count_sel==0 && $count_place==0){ $count_place++; ?>
							 <option disabled>select category</option>
							<?php } ?>
						
                    <option value="<?php echo $category->term_id; ?>" <?php if(in_array($category->term_id, $user_category)){echo 'selected';} ?>><?php echo strtolower($category->name); ?></option>
						<?php } } ?>
				  
                  </select>
                </div>
                <div class="col-lg-12 col-md-12 col-xs-12 Form-Equal">
                  <input type="text" value="<?php if($user_url){echo $user_url; } ?>" class="Custom-Input" placeholder="website" id="website">
                </div>
				
				<div class="col-lg-12 col-md-12 col-xs-12 Form-Equal">
                  <input type="text" value="<?php if($user_location){echo $user_location; } ?>" class="Custom-Input" placeholder="location" id="user_loc">
                </div>
				
				<div class="col-lg-12 col-md-12 col-xs-12 Form-Equal">
                  <input type="text" value="<?php if($wall_add){echo $wall_add; } ?>" class="Custom-Input" placeholder="wallet address" id="wall_add">
                </div>
				
                <div class="col-lg-12 col-md-12 col-xs-12 Form-Equal">
                  <textarea  rows="5" class="Custom-Input" placeholder="short bio" id="shortbio"><?php if( $aut_dec){echo  $aut_dec; }?></textarea>
				  <p id="remain" style="font-size: 13px;margin-bottom: 0;">90 characters only.</p>
                </div>
                <div class="col-lg-12 col-md-12 col-xs-12 Form-Equal">
                  <textarea  rows="5" class="Custom-Input Long-Bio" placeholder="long bio" id="longbio"><?php if($user_bio){echo  $user_bio; }?></textarea>
                </div>
                <div class="Copy-Div">
					<?php if(!empty($social_arr)){ 
					$scl_field_count = 0;
					foreach($social_arr as $key=>$value){
						if($value){
						$scl_field_count++; 
						 ?>
					<div class="col-lg-12 col-md-12 col-xs-12 Form-Equal Social-PopUp-Div">
						<div class="Fl-Social">
						  <!--select class="Custom-Input" id="">
							<option value="fb" <?php if($key == 'fb'){echo 'selected'; } ?>>&#xf082;</option>                        
							<option value="insta" <?php if($key == 'insta'){echo 'selected'; } ?>>&#xf16d;</option>                       
							<option value="twitter" <?php if($key == 'twitter'){echo 'selected'; } ?>>&#xf081;</option>                        
							<option value="youtube" <?php if($key == 'youtube'){echo 'selected'; } ?>>&#xf166;</option>
						  </select-->
						  
						  <select class="select2-icon Select-Input-Fa" name="icon">
						  <?php if($key == 'fb'){ ?>
							<option  value="fb" data-icon="fa fa-facebook-square" <?php echo 'selected'; ?>></option>
						  <?php }if($key == 'youtube'){ ?>
							<option value="youtube" data-icon="fa fa-youtube-square" <?php echo 'selected';  ?>></option>
						 <?php }if($key == 'insta'){ ?>
							<option value="insta" data-icon="fa fa-instagram" <?php echo 'selected';  ?>></option>
						 <?php }if($key == 'twitter'){ ?>
							<option  value="twitter" data-icon="fa fa-twitter-square" <?php echo 'selected';  ?>></option>
							<?php } ?>
						</select>
						  
						</div>
						<div class="Fl-Social-2">
						  <input type="text" value="<?php echo $value; ?>" class="Custom-Input" placeholder="add social link">
						</div>
						<a href="javascript:void(0)" class="rmv_link">
							<i class="fa fa-minus-circle"></i>
						</a>
					</div>
						<?php } } }else{ ?>
				
                  <div class="col-lg-12 col-md-12 col-xs-12 Form-Equal Social-PopUp-Div empty_one">
                    <div class="Fl-Social">
                        <!--
                      <select class="Custom-Input" id="">
                        <option value="fb">&#xf082;</option>                        
						<option value="insta">&#xf16d;</option>                       
						<option value="twitter">&#xf081;</option>                        
						<option value="youtube">&#xf166;</option>
                      </select>
                  -->

                     <select class="select2-icon Select-Input-Fa" name="icon">
    <option  value="fb" data-icon="fa fa-facebook-square"></option>
    <option value="youtube" data-icon="fa fa-youtube-square"></option>
    <option value="insta" data-icon="fa fa-instagram"></option>
    <option  value="twitter" data-icon="fa fa-twitter-square"></option>
</select>

                    </div>
                    <div class="Fl-Social-2">
                      <input type="text" class="Custom-Input" placeholder="add social link">
                    </div>
					<a href="javascript:void(0)" class="rmv_link">
						<i class="fa fa-minus-circle"></i>
					</a>
                  </div>
					<?php } ?>
				  
                </div>
                <div class="col-lg-12 col-md-12 col-xs-12">
				<?php if($scl_field_count < 4 ){ ?>
                  <a href="javascript:void(0)" class="add-more-social" id="socialinks">+ add another social</a>
				<?php } ?>
                </div>
              </div>
            </div>
            <div class="Popup-Child-2">
              <div class="Image-Update-Div">
                <div class="Up-Div">
                  <div class="Image-UP-Profile">
					<?php if($author_avatar){ 
						echo $author_avatar; 
						$site_url = get_site_url();
						$p_temp = get_stylesheet_directory_uri().'/img/Userpic.png';
						
					} else { ?>
                    <img class="profile-pic" src="<?php echo get_stylesheet_directory_uri(); ?>/img/placeholderimage.png" alt="User Pic">
					<?php } ?>
				  </div>
                </div>
                <div class="upload-btn-wrapper">
                  <button class="Btn-Upload file-upload up_btn_text">change avatar</button>
                  <input id="imageUpload" class="file-upload" type="file" accept="image/*" name="myfile" />
				  <p id="" style="font-size: 14px;margin-bottom: 0; margin-top: 5px;">please upload jpg, png and jpeg format images</p>
                </div>
              </div>
            </div>
          </div>

      </div>
      <div class="modal-footer Custom-Model-Footer">
        <button type="button" class="btn Custom-Cl-Btn" data-dismiss="modal">cancel</button>
        <button type="submit" class="btn Custom-Sv-Btn " >save</button>
      </div>
	  
	  </form>
	  
	  
    </div>
  </div>
</div>
<script>
jQuery(document).ready(function(){
	var first_name = '<?php echo $first_name;?>';
	var last_name = '<?php echo $last_name;?>';
	if(jQuery('#billing_first_name').length == 1){
		jQuery('#billing_first_name').val(first_name);
	}
	if(jQuery('#billing_last_name').length == 1){
		jQuery('#billing_last_name').val(last_name);
	}
});
</script>
<?php }  //var_dump(get_user_meta(get_current_user_id(),'select_category',true)); 
if($author_avatar){?>
	<script>
		jQuery(document).ready(function(){
			jQuery(".Image-UP-Profile img.avatar").addClass("profile-pic"); 
			var site_url = '<?php echo $site_url; ?>';
			console.log(site_url);
				jQuery(".Image-UP-Profile img.avatar:not([src^='"+site_url+"']").each(function(i){
				 // this.src = "<?php echo $p_temp; ?>";
				  var temp_src = "<?php echo $p_temp; ?>";
				  console.log(this.src);
				  jQuery(this).prop('src',temp_src);
				  jQuery(".up_btn_text").text("upload avatar"); 
				}); 
		});
	</script>
<?php } ?>
<script>
  /*tinymce.init({
    selector: 'textarea#longbio',
    menubar: false
  });*/

function remove_social_link(){
	jQuery('.rmv_link').click(function(){
		
		jQuery(this).parent('.Social-PopUp-Div').remove();
		jQuery('a#socialinks').show();
	});
}
jQuery(document).ready(function($) {
	
	var maxchars = 90;
	//Validation code for SHort Bio Character limit
	jQuery('textarea#shortbio').keyup(function () {
		var tlength = jQuery(this).val().length;
		jQuery(this).val(jQuery(this).val().substring(0, maxchars));
		var tlength = jQuery(this).val().length;
		remain = maxchars - parseInt(tlength);
		jQuery('#remain').text(remain+' Characters Remaining');
	});
	
	

	var values_selected_cat = '';
	 jQuery(".select_cat").chosen().change(function(e, params){
 values_selected_cat = jQuery(".select_cat").chosen().val();
 //values is an array containing all the results.

});
jQuery('#profile_update').submit(function (e) {
     
            e.preventDefault(); 
			var wall_add = jQuery("#wall_add").val();
			jQuery('.valid_errrr').remove();
			window.web3 = new Web3(window.ethereum);
	if(web3.utils.isAddress(wall_add)){
		
	}else{
		jQuery('#wall_add').after('<span class="valid_errrr" style="color:red">Please add the valid address.</span>');
		return false;
	}
		
var firstname = jQuery.trim(jQuery("#firstname").val());
var user_login = jQuery.trim(jQuery("#username").val());
 /* var user_email = jQuery.trim(jQuery("#emailaddress").val()); */
var user_url = jQuery.trim(jQuery("#website").val());
var description = jQuery.trim(jQuery("#shortbio").val());
var longbio = jQuery("#longbio").val();
var user_loc = jQuery("#user_loc").val();


var profile_img = jQuery('#imageUpload').prop('files')[0];

/* console.log(username);*/


 var form_data = new FormData();
form_data.append('action', 'aj_save_author_field');
form_data.append('first_name', firstname);
form_data.append('user_login', user_login);
 /* form_data.append('user_email', user_email);  */
form_data.append('description', description);
form_data.append('longbio', longbio);
form_data.append('user_url', user_url);
 form_data.append('profile_img', profile_img);
 form_data.append('user_loc', user_loc);
 form_data.append('wall_add', wall_add);
 
 jQuery('.Copy-Div .Social-PopUp-Div').each(function(){
	 var socail_sel = jQuery(this).find('.Fl-Social :selected').val();
	 var socail_sel_link = jQuery(this).find('.Fl-Social-2 > input').val();

	 if(socail_sel == 'fb'){
		form_data.append('fb_link', socail_sel_link);
	 }
	 if(socail_sel == 'insta'){
		form_data.append('insta_link', socail_sel_link);
	 }
	 if(socail_sel == 'twitter'){
		form_data.append('twitter_link', socail_sel_link);
	 }
	 if(socail_sel == 'youtube'){
		form_data.append('youtube_link', socail_sel_link);
	 }
 });

	 if(values_selected_cat){
		 form_data.append('selected_cat', values_selected_cat);
	 }else{
		/* values_selected_cat = '<?php echo json_encode($sel_category); ?>'; */
		values_selected_cat = jQuery(".select_cat").chosen().val();
		form_data.append('selected_cat', values_selected_cat);
	
	 }
 console.log(values_selected_cat);
 
jQuery.ajax({
        url         : ajax_register_object.ajaxurl,
         dataType: 'json',
          type: 'POST', 
                data: form_data,
                processData: false,
                contentType: false,
		
        success : function(result){
			console.log(result);
			if(result.message=='submitted'){
				//jQuery('#profile_update .Custom-Model-Footer').prepend('<p class="msg sucess">Profile updated successfully!</p>');
				swal('Profile updated successfully!');
				setTimeout(function(){ 
					location.reload(true);
				}, 2500);
			}
			 
		}
        });
		

});

// select option

function formatText (icon) {
    return jQuery('<span><i class="fa ' + jQuery(icon.element).data('icon') + '"></i> ' + icon.text + '</span>');
};

jQuery('.select2-icon').select2({
    width: "100%",
    templateSelection: formatText,
    templateResult: formatText
});



//Duplicating the social Link field
     var i = 0;
    jQuery(".add-more-social").click(function(){   
         
		console.log(jQuery('.Copy-Div .Social-PopUp-Div').length);
		if(jQuery('.Copy-Div .Social-PopUp-Div').length <=4){
			var social_option = '';
			var col_social = [];
			jQuery('.Copy-Div .Social-PopUp-Div').each(function(){
				col_social[i] = jQuery(this).find('.Fl-Social :selected').val();
				  i++;
			});
			if(col_social){
				if(!(jQuery.inArray("fb", col_social) != -1) && (social_option.search("fa-facebook-square") != true) ){
					 social_option += '<option value="fb" data-icon="fa fa-facebook-square"></option> ';
					
				}
				if(!(jQuery.inArray("youtube", col_social) != -1) && (social_option.includes("fa-youtube-square")!= true)){
					 social_option += '<option value="youtube" data-icon="fa fa-youtube-square"></option> ';
				}
				if(!(jQuery.inArray("insta", col_social) != -1) && (social_option.includes("fa-instagram")!= true)){
					 social_option += '<option value="insta" data-icon="fa fa-instagram"></option> ';
				}
				if(!(jQuery.inArray("twitter", col_social) != -1) && (social_option.includes("fa-twitter-square")!= true)){
					 social_option += '<option value="twitter" data-icon="fa fa-twitter-square"></option> ';
				}
				
				 console.log(social_option);
			}
				//var social_option = '<option value="fb" data-icon="fa fa-facebook-square"></option> <option value="youtube" data-icon="fa fa-youtube-square"></option> <option value="insta" data-icon="fa fa-instagram"></option> <option value="twitter" data-icon="fa fa-twitter-square"></option>';
			
		   jQuery(".Copy-Div").append('<div class="col-lg-12 col-md-12 col-xs-12 Form-Equal Social-PopUp-Div"> <div class="Fl-Social"> <select class="select2-icon Select-Input-Fa" name="icon">'+social_option+'</select> </div> <div class="Fl-Social-2"> <input type="text" class="Custom-Input" placeholder="add social link"> </div><a href="javascript:void(0)" class="rmv_link"> <i class="fa fa-minus-circle"></i></a> </div>');
		   /* jQuery(".empty_one").clone().append('.Copy-Div'); */
		   
			remove_social_link();
			jQuery('a#socialinks').show();
			if(jQuery('.Copy-Div .Social-PopUp-Div').length ==4){
				jQuery('a#socialinks').hide();
			}
		}else{
			jQuery('a#socialinks').hide();
		}

        /* function formatText (icon) {
			return jQuery('<span><i class="fa ' + jQuery(icon.element).data('icon') + '"></i> ' + icon.text + '</span>');
		} */

jQuery('.select2-icon').select2({
    width: "100%",
    templateSelection: formatText,
    templateResult: formatText
});


    });
    
    remove_social_link();

    // jQuery('body.product-type-auction').find('.woocommerce-message').addClass('test');
    // jQuery('.single_add_to_cart_button').on('click', function() {
    // if(jQuery('body.product-type-auction').find('.single_add_to_cart_button').on('click', function() {
    //     jQuery('body').find('.woocommerce-message').addClass('test');
    // });
    // // });

    // if(jQuery('body.product-type-auction').find('.bid_button')) {
    //     jQuery('body').find('.woocommerce-message').removeClass('test');
    // }

    // // jQuery('.single_add_to_cart_button').on('click', function() {
    // //     console.log('here');
    // //     jQuery('body').find('.woocommerce-message').addClass('test');
    // // })





});
</script>




<?php wp_footer(); ?>

</body>
</html>