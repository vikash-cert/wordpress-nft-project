<?php 

include 'custom-functions.php';
include 'build-functions.php';
include 'ResaleTransactions.php';

/* include 'metamask/payment.php'; */
require_once( 'twilio-lib/src/Twilio/autoload.php');
use Twilio\Rest\Client;

add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

function enqueue_parent_styles() {
	 
	wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
	wp_enqueue_style( 'custom-style', get_stylesheet_directory_uri().'/css/custom.css' );
	wp_enqueue_style( 'addition-style', get_stylesheet_directory_uri().'/css/addition.css' );
	wp_enqueue_style( 'new-style', get_stylesheet_directory_uri().'/css/new-custom.css' );
	wp_enqueue_style( 'input-tell-style', get_stylesheet_directory_uri().'/css/intlTelInput.css' );
	wp_enqueue_style( 'owl-carousel', get_stylesheet_directory_uri().'/css/owl.carousel.min.css' );
	wp_enqueue_style( 'chosen-css', get_stylesheet_directory_uri().'/css/chosen.css' );
	wp_enqueue_style( 'select-css', get_stylesheet_directory_uri().'/css/bootstrap-select.css');
	


	
	//js
	//deregister the parent bootstrap script
	wp_enqueue_script('wc-password-strength-meter');
	 wp_dequeue_script( 'bootstrap' );
    wp_deregister_script( 'bootstrap' );
	 wp_enqueue_script('bootstrap',get_stylesheet_directory_uri().'/js/bootstrap.min.js' , array(), '4.0.0', true);
   wp_enqueue_script('swaljs','https://unpkg.com/sweetalert/dist/sweetalert.min.js',array(),'1.1',true);	
    wp_enqueue_script('greenplayer-js',get_stylesheet_directory_uri().'/js/green-audio-player.min.js',array(),'1.1',true);	
	wp_enqueue_script('input-tell-js',get_stylesheet_directory_uri().'/js/intlTelInput-jquery.min.js' , array(), '1.1', true);
	wp_enqueue_script('owl-carousel-js',get_stylesheet_directory_uri().'/js/owl.carousel.min.js' , array(), '1.1', true);
	wp_enqueue_script('chosen-js',get_stylesheet_directory_uri().'/js/Chosen.js' , array(), '1.1', false);
	wp_enqueue_script('select-js',get_stylesheet_directory_uri().'/js/bootstrap-select.js' , array(), '1.1', true);

	if(is_page('my-account') || is_page('publish-product') || is_author()){
		wp_enqueue_script('web3','https://unpkg.com/web3@1.3.5/dist/web3.min.js', array(), '1.1', true);
		// wp_enqueue_script('validate-js','https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js', array(), '1.1', true);
	}
     wp_enqueue_script('custom-js',get_stylesheet_directory_uri().'/js/custom.js' , array(), '1.1', true);
    

     
      

}
function pw_load_scripts() {
	//wp_enqueue_script('metamask-admin','https://unpkg.com/@metamask/detect-provider/dist/detect-provider.min.js');	
	wp_enqueue_script('web3-admin','https://unpkg.com/web3@1.3.5/dist/web3.min.js');
    wp_enqueue_script('admin-js',get_stylesheet_directory_uri().'/js/admin-js.js' , array(), '1.1', true);	
}
add_action('admin_enqueue_scripts', 'pw_load_scripts');
add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 99 );
function woo_remove_product_tabs( $tabs ) {
   $tabs['seller'] = array(
            'title' => __('Creator Info', 'woocommerce') ,
            'callback' => 'seller_tab'
        );
   $tabs['more_seller_product'] = array(
            'title' => __('More from Creator', 'woocommerce') ,
            'callback' => 'more_seller_product'
        );
   return $tabs;
}
function more_seller_product(){
	$vendor_id  = get_the_author_meta( 'ID' );
	$user_info = get_userdata($vendor_id);
	$user_login = $user_info->user_login;
	echo do_shortcode('[wcv_recent_products  vendor="'.$user_login.'" per_page=4 orderby="date" order="desc"]' );
}
function seller_tab(){
		$vendor_id  = get_the_author_meta( 'ID' );
		 $aut_dec = get_user_meta($vendor_id, 'description', true);
		//echo '<div class="sellerInfo"> <p>'.get_user_meta($vendor_id,'pv_seller_info',true).'</div>';		
		echo '<div class="sellerInfo"> <p>'.get_the_author_meta( 'display_name', $vendor_id ).'</p><p>'.$aut_dec.'</p></div>';
	
	
}
/* add_filter( 'woocommerce_cart_needs_shipping', 'filter_cart_needs_shipping' );
function filter_cart_needs_shipping( $needs_shipping ) {
    if ( is_checkout() || is_cart()) {
        $needs_shipping = false;
    }
    return $needs_shipping;
} */

/*remove billing address field from the checkout page*/

add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );
 
function custom_override_checkout_fields( $fields ) {
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_country']);
    unset($fields['billing']['billing_state']);
    unset($fields['billing']['billing_phone']);
    unset($fields['order']['order_comments']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_city']);
    return $fields;
}

/* function for metamask plugin when product has been publish */


add_action( 'admin_enqueue_scripts', 'wpse50770_add_admin_scripts', 10, 1 );
function wpse50770_add_admin_scripts( $hook ) {
    global $post;

    
    if ( 'post.php' == $hook  && 'product' == $post->post_type && isset($_GET['message']) ) {   
		$product = wc_get_product( $post->ID );	
		$price = $product->get_regular_price();
        $message_id = absint( $_GET['message'] );
		
		/* 
        wp_enqueue_script(
            'wpse-notice',
             get_stylesheet_directory_uri() . '/js/metamask.js',
            array('jquery')
        );
        $data = array( 'Message' => $message_id,'price'=> $price);
        wp_localize_script( 'wpse-notice', 'wpsePost', $data ); */
    }
}


add_filter ( 'woocommerce_account_menu_items', 'purchasedproduct_new_menu_link', 40 );
function purchasedproduct_new_menu_link( $menu_links ){
 
	$menu_links = array_slice( $menu_links, 0, 2, true ) 
	+ array( 'purchased-product' => 'Purchased Products' )
	+ array_slice( $menu_links, 2, NULL, true );
	
		$menu_links = array_slice( $menu_links, 0, 2, true ) 
	+ array( 'user-wallet' => 'Wallets' )
	+ array_slice( $menu_links, 2, NULL, true );
 
	return $menu_links;
 
}
add_action( 'init', 'purchasedproduct_add_endpoint' );
function purchasedproduct_add_endpoint() {
 
	add_rewrite_endpoint( 'purchased-product', EP_PAGES );
	add_rewrite_endpoint( 'user-wallet', EP_PAGES );
 
}

add_action( 'woocommerce_account_purchased-product_endpoint', 'purchasedproduct_my_account_endpoint_content' );
function purchasedproduct_my_account_endpoint_content() {
   wc_get_template( 'myaccount/product-purchased.php' ); 
   //wc_get_template( 'myaccount/user-wallet.php' ); 
}

add_action( 'woocommerce_account_user-wallet_endpoint', 'userwallet_my_account_endpoint_content' );
function userwallet_my_account_endpoint_content() {
   
   wc_get_template( 'myaccount/user-wallet.php' ); 
}

/*user exists or not*/

function user_id_exists($user){

    global $wpdb;

    $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $wpdb->users WHERE ID = %d", $user));

    if($count == 1){ return true; }else{ return false; }

}

/*Product Publish function*/

add_action('wp_ajax_publishProduct', 'publishProduct');

function publishProduct(){
	$result = array();
	$update_price = $_POST['updatePrice'];
	$productId = $_POST['pid'];
	$metamaskAddress = $_POST['metamaskAddress'];
	$userId = get_current_user_id();
	if($metamaskAddress){
		update_user_meta($userId,'metamaskAddress',$metamaskAddress);
	}
	if($productId){
		$exist = wc_get_product($productId);
		/* $exist_prod_regprice = get_post_meta($productId,'_regular_price',true);
		$exist_prod_price = $exist_prod_regprice?$exist_prod_regprice:get_post_meta($productId,'_price',true);
		$exist_prod_saleprice = get_post_meta($productId,'_sale_price',true); */
		
		
		if($exist){
			$exist_prod_regprice = $exist->get_regular_price();
			$exist_prod_saleprice  = $exist->get_sale_price();
			$exist_prod_price = $exist->get_price();
			
			$post_obj    = get_post($productId);
			$resellID = get_post_meta($productId,'resellBy',true);
			if($resellID){
				$author_id = $resellID;
			}else{
				$author_id = $post_obj->post_author;
			}
			
			
			update_post_meta($productId,'_regular_price',$update_price);
			update_post_meta($productId,'_price',$update_price);
			update_post_meta($productId,'_sale_price','');
			
			update_post_meta($productId,'_stock','1');
			update_post_meta($productId,'_stock_status','instock');
			$resell = get_post_meta($productId,'resellProduct',true);
			if($resell){
				update_post_meta($productId,'resellProduct','yes');
			update_post_meta($productId,'resellBy', $userId);
			}else{
				update_post_meta($productId,'resellProduct','yes');
			update_post_meta($productId,'resellBy', $userId);
			}
			
			
			 if($exist_prod_saleprice){
					$final_price = $exist_prod_saleprice;
			}else{ 
					$final_price = $exist_prod_price;
			}
			/* delete_post_meta($productId,'user_sold_price'); */
			$user_sold_price = get_post_meta($productId,'user_sold_price',true);			
			if($user_sold_price){ 
			
				$user_sold_price[$author_id] = $final_price;
				/* array_push($user_sold_price,$temp_sold_price); */
				update_post_meta($productId,'user_sold_price',$user_sold_price);
			
			}else{
				$user_sold_price = array();
				$user_sold_price[$author_id] = $final_price;
				add_post_meta($productId,'user_sold_price',$user_sold_price);
			}
				
				
			$resell_user_id_list = get_post_meta($productId,'resell_user_id_list',true);

			if($resell_user_id_list){ 
				

				array_push($resell_user_id_list,$userId);
				update_post_meta($productId,'resell_user_id_list',$resell_user_id_list);

			}else{
				$resell_user_id_list = array();
				$resell_user_id_list[] = $userId;
				add_post_meta($productId,'resell_user_id_list',$resell_user_id_list);
			}
				
				
		
			$resell_user_pro = get_user_meta($userId,'resell_prod_id',true);
			if($resell_user_pro){
				$resell_user_pro[] = $productId;
				update_user_meta($userId,'resell_prod_id',$resell_user_pro);
			}else{
				$productId_collection[] = $productId;
				add_user_meta($userId,'resell_prod_id',$productId_collection);
			}
			
			$terms = array( 'exclude-from-catalog', 'exclude-from-search' );
			wp_set_object_terms( $productId, $terms, 'product_visibility' );
			$child_product = wc_get_product($productId);
			// Change the product visibility
			$child_product->set_catalog_visibility('visible');
			// Save and sync the product visibility
			$child_product->save();
			
			if($exist->get_type() == 'auction'){
                wp_remove_object_terms( $productId, 'auction', 'product_type' );
               wp_set_object_terms( $productId, 'simple', 'product_type', true );
            }
			/*email Shoot when product publish */
			 $current_user = wp_get_current_user();
			//$data = $current_user->data;
			$current_user = wp_get_current_user();
			$data = $current_user->data;
			$user_email = $data->user_email;
			//$user_info = get_userdata($user_id);
  			$username = $data->user_login;
			
			$toplogo = get_site_url().'/wp-content/uploads/2021/11/citiesabc-blue-logo.png';
			$logo = '<img src="'.$toplogo.'" alt="Citiesabc" style="display:block; height: auto; margin:0 auto; max-width:260px; ">';
			$subject = 'Product listed';
			$messsage = '<html><body style="background:#efefef;">';
			$messsage .= '<table class="table" cellpadding="0" cellspacing="0" width="850" align="center" style=" border-radius: 4px; overflow: hidden;">';
			$messsage .= '<tbody>	
							<tr>
						<td colspan="2" style="background:#fff;padding-bottom: 20px;border: 1px solid #17134b;">
							<table class="header" cellpadding="0" cellspacing="0" width="100%" style="padding: 30px 40px;">
								<tbody>
									<tr><td>&nbsp;</td></tr>
									<tr><td style="color: #fff; font-family: sans-serif; font-size: 32px; font-weight: normal; letter-spacing: 1px; line-height: 40px;text-align: center;">' . $logo. '</td></tr>
									<tr><td>&nbsp;</td></tr>
								</tbody>
							</table>
						</td>
					</tr>';
			$messsage .= '<tr class="col-text-tr" >
						<td class="col-text" colspan="2" 
							style="font-family: sans-serif;font-family: sans-serif;background:#fff;
							padding: 30px 40px;
							font-size: 16px;">
							<h4 style="font-size: 25px; font-weight: bold;text-align: center;">' . $subject. '</h4>			
							<p>Dear '.$username.'</p>
							<p>Congratulations! </p>
							<p>Your '.get_the_title($productId).' product is listed in the marketplace.</p>
							<p>Thank you</p>
							<br><p>-- Citiesabc Team</p>
						</td>
					</tr>
					</tbody>
					</table></body></html>';
			
		    send_mail('Product listed',$messsage,$user_email);
			
			$result['status']='success';
			$result['url']= get_the_permalink($productId);
			

		}else{
		    $result['status']='error';
			$result['msg']= "this product doesn't exists";		
		}	
	}else{
		$result['status']='error';
		$result['msg']= "Something goes wrong please try again";
	}
	echo json_encode($result);
	exit;
	
}

add_filter('manage_product_posts_columns', 'my_columns');
function my_columns($columns) {
    $columns['resellby'] = 'Resell By';
    return $columns;
}
add_action('manage_product_posts_custom_column',  'my_show_columns');
function my_show_columns($name) {
    global $post;
    switch ($name) {
        case 'resellby':
			
            $resellby = get_post_meta($post->ID, 'resellBy', true);
			if($resellby){
				$resellby = get_display_name($resellby);
			}else{
				$resellby = '-';
			}
            echo $resellby;
    }
}

add_action('admin_head', 'my_custom_css');

function my_custom_css() {
  echo '<style>
    .column-resellby{
		width:10%;	
	}
  </style>';
}

function get_display_name($user_id) {
    if (!$user = get_userdata($user_id))
        return false;
    return $user->data->display_name;
}
//validate email address //

 function checkemail($str) {
         return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
   }


function ibid_ajax_register(){

        // Nonce is checked, get the POST data and sign user on
        $info = array();
        $info['user_login'] = $_POST['username'];
        $info['user_email'] = $_POST['email'];
        $info['user_pass'] = $_POST['password'];
		$info['confirm_password'] = $_POST['confirm_password'];
        $phn_no = $_POST['billing_mobile_phone'];
		$u_name = $_POST['username'];
		 $info['role'] = 'customer';
		 
		 $email_reg = $_POST['email'];
		$pass_reg = $_POST['password'];
		 if($info['user_login'] == ''  && $info['user_email'] == ''  && $info['user_pass'] == ''){
			 
			  echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('All fields are required!!.','ibid')));
			  exit;
			 
		 }else if($info['user_login'] == ''){
			 
			  echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Username is required field!!.','ibid')));
			  exit;
			 
		 }
		 //else if ( !preg_match('/^[A-Za-z][A-Za-z0-9]{5,31}$/', $info['user_login']) ){
			 else if ( !preg_match('/^[A-Za-z][a-zA-Z0-9_]{3,20}$/', $info['user_login']) ){
			 echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Username field allowed only alphanumeric and underscore and between 3 to 20 characters!!.','ibid')));
			  exit;
		 }
		 
		 /*else if($info['user_email'] == ''  &&  !checkemail($info['user_email'])){
			  echo json_encode(array('loggedin'=>false, 'message'=>__('Please provide us valid email address!!.','ibid')));
			  exit;
		 }*/
		 else if($info['user_email'] == ''){
			  echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Email field is required!!.','ibid')));
			  exit;
		 }
		 else if(!checkemail($info['user_email'])){
			  echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Please provide us valid email address!!.','ibid')));
			  exit;
		 }
		 /*else if(!preg_match("/^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/", $phn_no)){
			 echo json_encode(array('loggedin'=>false, 'message'=>__('Please provide us valid mobile number!!.','ibid')));
			 echo $phn_no;
			  exit;
		 }*/
		 
		 else if($info['user_pass'] == ''){
			  echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Password is required field.','ibid')));
			  exit;
		 }
		 else if(strlen($info['user_pass']) < 6){
			 echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('passwordLength','ibid')));
			 //echo $info['user_pass'];
			  exit;
		 }
		 
		 else if($info['confirm_password']== ''){
			 echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('Confirm Password is required field.','ibid')));
			  exit;
		 }
		 else if(email_exists( $email_reg )){
			 echo json_encode(array('loggedin'=>false, "success" => false, 'message'=>__('You are already registered with us','ibid')));
			 //echo $info['user_pass'];
			  exit;
		 }
        $user_signup = wp_insert_user( $info);  

            if(!is_wp_error($user_signup) ){
				$unique = uniqid();
					$get_key = get_user_meta($user_signup, 'activation_pass_key', true);
					if ($get_key){
						update_user_meta($user_signup, 'activation_pass_key', $unique);
						update_user_meta($user_signup,'status','inactive');
					}else{
						update_user_meta($user_signup, 'activation_pass_key', $unique);
						update_user_meta($user_signup,'status','inactive');
						
					}
					$get_phn = get_user_meta($user_signup, 'billing_mobile_phone', true);
					if($get_phn){
						update_user_meta($user_signup,'billing_mobile_phone',$phn_no);
					}else{					
						add_user_meta($user_signup, 'billing_mobile_phone', $phn_no);
					}
					$get_last_link_date = get_user_meta($user_signup, 'last_link_date', true);
					if($get_phn){
						update_user_meta($user_signup,'last_link_date',strtotime(current_time('mysql')));
					}else{					
						add_user_meta($user_signup, 'last_link_date',strtotime(current_time('mysql')));
					}
					 add_user_meta($user_signup, 'metamaskAddress','no');
					
				$check_return =	send_sms_email_verify($user_signup,$email_reg,$pass_reg,$unique,$another_take=0); // Send EMail and SMS verificationLink
					// same function for SMS and Twilio
				/* 	$encrpytData = 'get_user_'.$user_signup.'_'.$pass_reg;
					$url = site_url() . '?verificationaccount='.base64_encode($encrpytData).'&akey=' . $unique;
					$contact_url = site_url() . '/contact-us';
					
					 //Abhinav - Twilio SMS trigger
					 $msg = 'Please click on the link below to activate your account:' . $url .'        -- RareBid Team';
					 $from = '+12542523602';
					 
						if( $phn_no == +919810078124 ) {
							// Use the REST API Client to make requests to the Twilio REST API
							// Your Account SID and Auth Token from twilio.com/console
							$sid = 'AC315b0f7c074d3696e06f164acaaaecc3';
							$token = '18ca052984d744ef7958cab2f1afe126';
							$client = new Client($sid, $token);
								// Use the client to do fun stuff like send text messages!
								$client->messages->create(
									// the number you'd like to send the message to
									$phn_no,
									[
										// A Twilio phone number you purchased at twilio.com/console
										'from' => $from,
										// the body of the text message you'd like to send
										'body' => $msg
									]
								); 
							
						}
					
					
					$to = $email_reg;
					$subject = 'Activate Your Account On RareBid';
					$body = '<p>Please click on the link below to activate your account:</p><p><a href="' . $url . '" target="_blank">' . $url . '</a></p><br><br><p>-- RareBid Team</p>';
					$headers = array(); 
					$headers[] = 'Content-Type: text/html; charset=UTF-8';
	
					$mailResult = wp_mail($to, $subject, $body, $headers); */
				// same function for SMS and Twilio
				if($check_return){
					echo json_encode(array('loggedin'=>false,"success" => true, 'message'=>__('Thank you for registering. Please check your e-mail for verify your account!!','ibid'),'mail_sent'=>$check_return,'reset_form'=> 'yes'));
					
				}
			
            }else{
                $exists = email_exists( $email_reg );
				
				if ( $exists ) {
					$user_reg = get_user_by( 'email', $email_reg );
					$userId_reg = $user_reg->ID;
					$status = get_user_meta($userId_reg,'status',true);
					$check_last_date = get_user_meta($userId_reg, 'last_link_date', true);
					
					if(($status == 'inactive') && (strtotime(current_time('mysql')) - $check_last_date > 15 * 60)){
						$unique = uniqid();
						$get_key = get_user_meta($userId_reg, 'activation_pass_key', true); 
						if($get_key){
							update_user_meta($userId_reg, 'activation_pass_key', $unique);
						}else{
							update_user_meta($userId_reg, 'activation_pass_key', $unique);
						}
						
						$get_last_link_date = get_user_meta($userId_reg, 'last_link_date', true);
						if($get_last_link_date){
							update_user_meta($userId_reg,'last_link_date',strtotime(current_time('mysql')));
						}else{					
							add_user_meta($userId_reg, 'last_link_date', strtotime(current_time('mysql')));
						}
							
					$check_return =	send_sms_email_verify($userId_reg,$email_reg,$pass_reg,$unique,$another_take=1); // Send EMail and SMS verificationLink
					if($check_return){
						echo json_encode(array('loggedin'=>false,'message'=>__('You are already registered with us, please check your e-mail for verify your account!!','ibid'),'mail_sent'=>$check_return,'reset_form'=>'yes'));
					}
					/* $encrpytData = 'get_user_'.$userId_reg.'_'.$pass_reg;
					$url = site_url() . '?verificationaccount='.base64_encode($encrpytData).'&akey=' . $unique;
					$contact_url = site_url().'/contact-us';
					
					
					 $msg = 'Please click on the link below to activate your account:'.$url.'        -- RareBid Team';
					 $from = '+12542523602'; 
					 
						if($phn_no == +919810078124){
							
							$sid = 'AC315b0f7c074d3696e06f164acaaaecc3';
							$token = '18ca052984d744ef7958cab2f1afe126';
							$client = new Client($sid, $token);
												
							
								
								$client->messages->create(								
									$phn_no,
									[									
										'from' => $from,
										
										'body' => $msg
									]
								); 
						}
					
						$to = $email_reg;
						$subject = 'Activate Your Account On RareBid';
						$body = '<p>Please click on the link below to activate your account:</p><p><a href="'.$url.'" target="_blank">' .$url. '</a></p><br><br><p>-- RareBid Team</p>';
						$headers = array(); 
						$headers[] = 'Content-Type: text/html; charset=UTF-8';
		
						wp_mail($to, $subject, $body, $headers);
					 */	/* echo json_encode(array('loggedin'=>false, 'message'=>__('We have resent you the verification link.Please check your e-mail for verify your account','ibid')));  */
						
					}else{
						echo json_encode(array('loggedin'=>false, 'message'=>__('Please wait for 12-15mins for resending the email if you have not received yet!','ibid'), 'reset_form'=>'yes'));
					} 
				}else{
				
					echo json_encode(array('loggedin'=>false, 'message'=>__('Username or email already taken.','ibid'),'reset_form'=>'no'));
					
				}
            }
            //wp_set_current_user($user_signup);
            //wp_set_auth_cookie($user_signup); 
        
        exit; 
    }

add_action( 'wp_ajax_register_user', 'ibid_ajax_register',20 );
add_action( 'wp_ajax_nopriv_register_user', 'ibid_ajax_register',20 );

function send_sms_email_verify($user_id,$email_reg,$pass_reg,$unique,$another_take){
	$encrpytData = 'get_user_'.$user_id.'_'.$pass_reg;
	$url = site_url() . '?verificationaccount='.base64_encode($encrpytData).'&akey=' . $unique;
	$contact_url = site_url() . '/contact-us';

	$user_info = get_userdata($user_id);
  	$username = $user_info->user_login;
	
	 //Abhinav - Twilio SMS trigger
	 $msg = 'Please click on the link below to activate your account:' . $url .'        -- CitiesABC Team';
	 $from = '+12542523602';
	 
		if( $phn_no == +919810078124 ) {
			// Use the REST API Client to make requests to the Twilio REST API
			// Your Account SID and Auth Token from twilio.com/console
			$sid = 'AC315b0f7c074d3696e06f164acaaaecc3';
			$token = '18ca052984d744ef7958cab2f1afe126';
			$client = new Client($sid, $token);
								
			
				// Use the client to do fun stuff like send text messages!
				$client->messages->create(
					// the number you'd like to send the message to
					$phn_no,
					[
						// A Twilio phone number you purchased at twilio.com/console
						'from' => $from,
						// the body of the text message you'd like to send
						'body' => $msg
					]
				); 
			
		}
	
	
	$to = $email_reg;
	$subject = 'Activate Your Account On CitiesABC';
	$toplogo = get_site_url().'/wp-content/uploads/2021/11/citiesabc-blue-logo.png';
	$logo = '<img src="'.$toplogo.'" alt="Citiesabc" style="display:block; height: auto; margin:0 auto; max-width:260px; ">';
	$body = '<html><body style="background:#efefef;">';
	$body .= '<table class="table" cellpadding="0" cellspacing="0" width="850" align="center" style=" border-radius: 4px; overflow: hidden;">';
	$body .= '<tbody>	
					<tr>
				<td colspan="2" style="background:#efefef;">
					<table class="header" cellpadding="0" cellspacing="0" width="100%" style="padding: 30px 40px;">
						<tbody>
							<tr><td>&nbsp;</td></tr>
							<tr><td style="color: #fff; font-family: sans-serif; font-size: 32px; font-weight: normal; letter-spacing: 1px; line-height: 40px;text-align: center;">' . $logo. '</td></tr>
							<tr><td>&nbsp;</td></tr>
						</tbody>
					</table>
				</td>
			</tr>';
	$body .= '<tr class="col-text-tr" >
				<td class="col-text" colspan="2" 
				    style="font-family: sans-serif;font-family: sans-serif;background:#fff;
					padding: 30px 40px;
					font-size: 16px;">
					<h4 style="font-size: 25px; font-weight: bold;text-align: center;">' . $subject. ' </h4>			
					<p>Hi ' . $username. ', </p>
					<p>Please click on the link below to activate your account:</p> 
					<p><a href="' . $url . '" target="_blank">' . $url . '</a> </p>
					<br><p>-- Citiesabc Team</p>
				</td>
			</tr>
			</tbody>
			</table></body></html>';
	$headers = array(); 
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	
	$emailsent = wp_mail($to, $subject, $body, $headers);
	return $emailsent;
} 
 function ibid_ajax_register_init(){

    wp_register_script('ajax-register-script', get_stylesheet_directory_uri() . '/js/ajax-register.js', array('jquery') );
    wp_enqueue_script('ajax-register-script');

    wp_localize_script( 'ajax-register-script', 'ajax_register_object', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'redirecturl' => home_url(),
        'loadingmessage' => __('Sending user info, please wait...','ibid')
    ));

    // Enable the user with no privileges to run ajax_login() in AJAX

    }
    add_action('init', 'ibid_ajax_register_init',20);
	function ibid_ajax_login(){

               // First check the nonce, if it fails the function will break
        check_ajax_referer( 'ajax-login-nonce', 'security' );

        // Nonce is checked, get the POST data and sign user on
        $info = array();
        $info['user_login'] = $_POST['username'];
        $info['user_password'] = $_POST['password'];
        $info['remember'] = true;
		//$userData = get_user_by('slug',$_POST['username']);
		$userData = wp_authenticate($_POST['username'], $_POST['password']);

			if($info['user_login'] != trim($info['user_login'])) {

				echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));
				exit;

			}
			else if($_POST['password'] != trim($_POST['password'])) {

				echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));
				exit;

			} else if($info['user_login'] == '' && $info['user_pass'] == ''){
				 
				echo json_encode(array('loggedin'=>false, 'message'=>__('All fields are required!!.','ibid')));
				exit;
			   
		   } else if($info['user_login'] == ''){
			   
				echo json_encode(array('loggedin'=>false, 'message'=>__('Username is required field!!.','ibid')));
				exit;
			   
		   } else if($info['user_password'] == ''){
			   
			echo json_encode(array('loggedin'=>false, 'message'=>__('Password is required field!!.','ibid')));
			exit;
		   
	   		}
		
		if($userData){
			$userdetails = $userData->data;
			//print_r($userdetails);
			if($userdetails){
		     $status =get_user_meta($userdetails->ID, 'status', true );
			if($status == 'inactive'){
				echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Your account has been not activated till now. Please contact with support!!', 'ibid')));
				 exit;
			}
			$verenab = get_user_meta($userdetails->ID,'2fa',true);
			if($verenab == 'yes'){
				$fourRandomDigit = rand(1000,9999);
			  $otp = update_user_meta($userdetails->ID, 'otp', $fourRandomDigit );
			  $otp_sent_time = update_user_meta($userdetails->ID, 'otp_sent_time', strtotime(current_time('mysql')));
			  
			  //Abhinav - Twilio SMS trigger
			 $phn_no = get_user_meta($userdetails->ID, 'billing_mobile_phone', true );
			 $msg = 'Please copy this otp ' . $fourRandomDigit . '.   -- Have NFT Team';
			 $from = '+12542523602';
			 
				if( $phn_no == +919810078124) {  
					// Use the REST API Client to make requests to the Twilio REST API
					// Your Account SID and Auth Token from twilio.com/console
					$sid = 'AC315b0f7c074d3696e06f164acaaaecc3';
					$token = '18ca052984d744ef7958cab2f1afe126';
					$client = new Client($sid, $token);

					// Use the client to do fun stuff like send text messages!
					$client->messages->create(
						// the number you'd like to send the message to
						$phn_no,
						[
							// A Twilio phone number you purchased at twilio.com/console
							'from' => $from,
							// the body of the text message you'd like to send
							'body' => $msg
						]
					); 
				}
				
			  $to = $userdetails->user_email;
					$subject = 'OTP - London United';
					$body = '<p>Please copy this otp ' . $fourRandomDigit . '.</p><br><br><p>-- Have NFT Team</p>';
					$headers = array(); 
					$headers[] = 'Content-Type: text/html; charset=UTF-8';
					
					wp_mail($to, $subject, $body, $headers);
			  echo json_encode(array('loggedin'=>'not', 'message'=> esc_html__('We have sent a otp in your email address. Please check it!!', 'ibid')));
				 exit;
			}else{
				
				$user_signon = wp_signon( $info, false );
				//echo $user_signon;
        if ( is_wp_error($user_signon) ){
			// echo $user_signon->get_error_message();
			delete_user_meta($userdetails->ID, 'otp');
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password or your account not verified yet.', 'ibid')));
        } else {
            echo json_encode(array('loggedin'=>true, 'class'=>'success', 'message'=> esc_html__('Login successful, redirecting...', 'ibid')));
			 wp_clear_auth_cookie();
			 wp_set_current_user ( $userdetails->ID ); // Set the current user detail
			 wp_set_auth_cookie  ( $userdetails->ID );
			//wp_set_current_user($user_signup);
			//wp_set_auth_cookie($user_signup);
        }	  
				
				
				
			}
			  
			}else{
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));	
			}
		
		}else{
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));
		}
       

        die();
    }
	//twilio API

	
	function ibid_otp_login(){

        // First check the nonce, if it fails the function will break
       // check_ajax_referer( 'ajax-login-nonce', 'security' );

        // Nonce is checked, get the POST data and sign user on
        $info = array();
        $info['user_login'] = $_POST['username'];
        $info['user_password'] = $_POST['password'];
        $info['remember'] = true;
		$userData = get_user_by('slug',$_POST['username']);
		if($userData){
			$userdetails = $userData->data;
			if($userdetails){
			  $otp =get_user_meta($userdetails->ID, 'otp', true );
			   $otp_sent_time = get_user_meta($userdetails->ID, 'otp_sent_time', true);
			   /*  var_dump( $otp_sent_time);
				var_dump(  strtotime(current_time('mysql')));  */
			   if( strtotime(current_time('mysql')) - $otp_sent_time > 15 * 60){
				    echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('OTP expired, please retry!!', 'ibid')));
					exit;
			   }
			  if($otp == trim($_POST['otp'])){
		 $user_signon = wp_signon( $info, false );
        if ( is_wp_error($user_signon) ){
			delete_user_meta($userdetails->ID, 'otp');
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('OTP is not correct!!', 'ibid')));
        } else {
            echo json_encode(array('loggedin'=>true,"success" => true, 'message'=> esc_html__('Login successful, redirecting...', 'ibid')));
			 wp_clear_auth_cookie();
			 wp_set_current_user ( $userdetails->ID ); // Set the current user detail
			wp_set_auth_cookie  ( $userdetails->ID );
        }	  
			  }else{
				  echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('OTP is not correct!!', 'ibid')));
				 exit;  
			  }
			
			}else{
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));	
			}
		
		}else{
			echo json_encode(array('loggedin'=>false, 'message'=> esc_html__('Wrong username or password.', 'ibid')));
		}
        die();
    }
	
	 function ibid_ajax_login_init(){

        wp_register_script('ibid-ajax-login', get_stylesheet_directory_uri() . '/js/ajax-login.js', array('jquery') ); 
        wp_enqueue_script('ibid-ajax-login');
		 // wp_enqueue_script('ibid-ajax-login');

        wp_localize_script( 'ibid-ajax-login', 'ajax_login_object', array( 
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'redirecturl' => home_url(),
            'loadingmessage' => esc_html__('Sending user info, please wait...', 'ibid')
        ));

        // Enable the user with no privileges to run ajax_login() in AJAX
        
    }
	add_action( 'wp_ajax_nopriv_ajaxlogin', 'ibid_ajax_login',20 );
	add_action( 'wp_ajax_nopriv_otplogin', 'ibid_otp_login',20 );
	
	
	 add_action('edit_user_profile', 'wk_custom_user_profile_status');
    add_action('show_user_profile', 'wk_custom_user_profile_status');
    add_action('edit_user_profile_update', 'wk_save_custom_user_profile_status');
    add_action('personal_options_update', 'wk_save_custom_user_profile_status');
	function wk_custom_user_profile_status($user) {
        ?>        
        <table class="form-table">
            <tr>
                <th><label for="badges">Status</label></th>    
                <td>
                    <select name="status" id="status">
                        <option value="">None</option>
                        <option value="inactive" <?php selected('inactive', get_user_meta($user->ID, 'status', true )); ?>>In-Active</option>
                        <option value="active" <?php selected('active', get_user_meta($user->ID, 'status', true )); ?>>Active</option>
             
						</select>
                </td>    
            </tr>
        </table>        
        <?php
    }

    function wk_save_custom_user_profile_status($user_id) {
        update_user_meta($user_id, 'status', $_POST['status']);
    }
	
	function new_modify_user_table( $column ) {
    $column['status'] = 'Status';
	$column['balance'] = 'ETH Balance';
	$column['transaction_history'] = 'Transaction History';
    
    return $column;
}
add_filter( 'manage_users_columns', 'new_modify_user_table' );

function new_modify_user_table_row( $val, $column_name, $user_id ) {
    switch ($column_name) {
        case 'status' :
            return get_user_meta($user_id, 'status', true );
		case 'balance' :
			return get_user_meta($user_id, 'balance', true );
		case 'transaction_history' :
			return '<a href="javascript:void(0)" onclick="showHistory('.$user_id.')">View Transaction History</a>';	
        default:
    }
    return $val;
}
add_filter( 'manage_users_custom_column', 'new_modify_user_table_row', 10, 3 );
	
if (!is_user_logged_in()) {
    add_action('init', 'ibid_ajax_login_init',20);
}

//Adding Phone number on Account Edit page
// add_action( 'woocommerce_edit_account_form_start', 'add_billing_mobile_phone_to_edit_account_form' ); // At start
add_action( 'woocommerce_edit_account_form', 'add_billing_mobile_phone_to_edit_account_form' ); // After existing fields
function add_billing_mobile_phone_to_edit_account_form() {
    $user = wp_get_current_user();
    ?>
     <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="billing_mobile_phone"><?php _e( 'Mobile phone', 'woocommerce' ); ?> <span class="required">*</span></label>
        <input type="text" class="woocommerce-Input woocommerce-Input--phone input-text" name="billing_mobile_phone" id="billing_mobile_phone" value="<?php echo esc_attr( $user->billing_mobile_phone ); ?>" required />
    </p>
    <?php
}

// Check and validate the mobile phone
add_action( 'woocommerce_save_account_details_errors','billing_mobile_phone_field_validation', 20, 1 );
function billing_mobile_phone_field_validation( $args ){
    if ( isset($_POST['billing_mobile_phone']) && empty($_POST['billing_mobile_phone']) ){
        $args->add( 'error', __( 'Please fill in your Mobile phone', 'woocommerce' ),'');
	}
	/*else if(!preg_match("/^[0-9]{10}$/", $_POST['billing_mobile_phone'])){
		$args->add( 'error', __( 'Please enter 10 digit mobile number', 'woocommerce' ),'');
	}*/
	
}

// Save the mobile phone value to user data
add_action( 'woocommerce_save_account_details', 'my_account_saving_billing_mobile_phone', 20, 1 );
function my_account_saving_billing_mobile_phone( $user_id ) {
    if( isset($_POST['billing_mobile_phone']) && ! empty($_POST['billing_mobile_phone']) ){
        
		update_user_meta( $user_id, 'billing_mobile_phone', sanitize_text_field($_POST['billing_mobile_phone']) );
	}
}

add_action( 'woocommerce_edit_account_form', 'add_2fa_to_edit_account_form' );
/*function add_2fa_to_edit_account_form() {
    $user = wp_get_current_user();
	$mainuser = $user->data;
	$data = get_user_meta($mainuser->ID,'2fa',true);
    ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">      
			<label for="2fa"><?php esc_html_e( '2fA enable setting', 'woocommerce' ); ?></label>
			<?php if($data){ ?>
				<div class="cstmFormGrpWrp">
					<div class="cstmFormGroup">
						<input id="yesRadio" type="radio" name = "2fa" value="yes" <?php if($data == 'yes') {?>checked <?php }?>>
						<label for="yesRadio">Yes</label>
					</div>
					<div class="cstmFormGroup">
						<input id="noRadio" type="radio" name = "2fa" value="no" <?php if($data == 'no') {?>checked <?php }?>>
						<label for="noRadio">No</label>
					</div>
				</div>
       
			<?php }else{ ?>
				<div class="cstmFormGrpWrp">
					<div class="cstmFormGroup">
						<input type="radio" name = "2fa" value="yes">
						<label for="yesRadio">Yes</label>
					</div>
					<div class="cstmFormGroup">
						<input type="radio" name = "2fa" value="no" checked> 
						<label for="noRadio">No</label>
					</div>
				</div>
			<?php } ?>
    </p>
    <?php
}*/


add_action( 'woocommerce_save_account_details', 'save_2fa_account_details', 12, 1 );
function save_2fa_account_details( $user_id ) {
   
    if( isset( $_POST['2fa'] ) )
        update_user_meta( $user_id, '2fa', sanitize_text_field( $_POST['2fa'] ) );

}

 function ur_theme_start_session() {
        if (!session_id())
            session_start();
    }

    add_action("init", "ur_theme_start_session", 1);
	
function admin_queue( $hook ) {
    global $post; 

    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'product' === $post->post_type ) { 
            wp_enqueue_script( 'custom-title-here', get_stylesheet_directory_uri()  . '/js/custom-web3.js', 'jquery', '', true );
        }
    }
}
add_action( 'admin_enqueue_scripts', 'admin_queue' );


function load_persistent_cart(){

    global $current_user;

    if( ! $current_user )
    return false;

    $saved_cart = get_user_meta( $current_user->ID, '_woocommerce_persistent_cart', true );

    if ( $saved_cart ){
        if ( empty( WC()->session->cart ) || ! is_array( WC()->session->cart ) || sizeof( WC()->session->cart ) == 0 ){
            WC()->session->set('cart', $saved_cart['cart'] );   
        }
    }

}

add_action( 'init', 'load_persistent_cart', 10, 1 );

  

/* call the api for sending the assets on the time of publish */

/* add_action( 'publish_product', function ( $post_id, $post )
{
      
		$id = $post->ID;
		$name = get_the_title($id);
		$description = get_the_content('','',$id);
		$featured_image = get_the_post_thumbnail_url($id);
		$featured_image = get_the_post_thumbnail_url($id);
	
		 $op = get_field('select_option', $id);
		
	if($op == 'video'){
		$full_video = get_field('full_video',$id);
		if($full_video){	
		$featured_image= $full_video;
		}else{
			$video = get_field('add_video',$id);
		$featured_image= $video;
		}
		
	}else if($op == 'audio'){
		$audio = get_field('add_audio',$id);
		$featured_image= $audio;
		
	}else{
		$featured_image= $featured_image;
	}
		
		
		$data = array(
			'tokenId' => $id,
		  'name' => $name,
		  'description'=>$description,
		  'image' => $featured_image
		);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		//exit();
		update_post_meta($id,'assetsResponse',$result);
		
   
}, 81, 2 ); */


function asset_upload($post_id) {

  if (get_post_status($post_id) == 'publish') {
	  $id = $post_id;
		$name = get_the_title($id);
		$description = get_the_content('','',$id);
		$featured_image = get_the_post_thumbnail_url($id);
		$featured_image = get_the_post_thumbnail_url($id);
	
		 $op = get_field('select_option', $id);
		
	if($op == 'video'){

		$full_video = get_field('add_video',$id);

		if($full_video){

		$featured_image= $full_video;

		}
		else{

			$video = get_field('full_video',$id);
			$featured_image= $video;
		}
		
	}
	else if($op == 'audio'){

		$audio = get_field('add_audio',$id);
		$featured_image= $audio;
		
	}
	else{
		$featured_image= $featured_image;
	}
		
		
		$data = array(
			'tokenId' => $id,
		  'name' => $name,
		  'description'=>$description,
		  'image' => $featured_image
		);
		
		$sendData = json_encode($data);
		$url = APIURL.'/assets/';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $sendData);

		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','x-api-key:'.APIKEY));
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch); 
		
		curl_close($ch);
		//exit();
		update_post_meta($id,'assetsResponse',$result);	  	
	  
  }

}

add_action( 'acf/save_post', 'asset_upload' );


	
//Changing order status from pending to proceesing on stripe payment
add_action( 'woocommerce_order_status_changed', 'change_order_status_conditionally', 10, 4 );
function change_order_status_conditionally( $order_id, $status_from, $status_to, $order ) {
    if( $order->get_payment_method() === 'stripe' && $status_to === 'processing' ) {
        $order->update_status( 'completed' );
    }
}


//Remove redirection author to shop
function enable_author_archives_for_customers() {
  remove_action('template_redirect', 'wc_disable_author_archives_for_customers');
}
add_action( 'after_setup_theme', 'enable_author_archives_for_customers' );

//add_filter( 'wpcf7_load_js', '__return_false' );

/*** ETH - Custom currency and currency symbol ****/
add_filter( 'woocommerce_currencies', 'add_eth_currency' );
function add_eth_currency( $currencies ) {
     $currencies['ETH'] = __( 'Ethereum', 'woocommerce' );
     return $currencies;
}
add_filter('woocommerce_currency_symbol', 'add_eth_currency_symbol', 10, 2);
function add_eth_currency_symbol( $currency_symbol, $currency ) {
     switch( $currency ) {
          case 'ETH': $currency_symbol = 'ETH'; break;
     }
     return $currency_symbol;
}
//my-account form redirect to homepage
add_action('woocommerce_customer_reset_password', 'lost_password_redirect');
function lost_password_redirect($user) {
    wp_redirect( home_url().'?reset-pass="true"' ); 
    exit;
}
//Add ETH price on ever product display
add_filter('woocommerce_get_price_html', 'edit_price_display', 9999, 2);
function edit_price_display($price, $product){
	//var_dump($product->get_type());
	if($product->get_type() != 'auction'){
		$currency = get_woocommerce_currency();
		$price_cstm = wc_get_price_to_display($product); // get the price without extra span tags
		if($price_cstm > 0){
			if($currency == 'USD'){
				/* $rateConversion = file_get_contents('https://min-api.cryptocompare.com/data/price?fsym=USD&tsyms=BTC,ETH,EUR'); */
				$converter = get_option('convertion_rate');
				if($converter){
					$total = $price_cstm * $converter->ETH;	
				}else{
					$total = $price_cstm * 0.00036;
				}
				$total = number_format($total,5);
				$price .= '<span class="cstm_price_api woocommerce-Price-amount amount " style="display:block;">ETH '.$total.'</span>';
			}else if($currency == 'ETH'){
				/* $rateConversion = file_get_contents('https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=BTC,USD,EUR');
				$converter = json_decode($rateConversion); */
				$converter = get_option('convertion_rate');
				if($converter){
					$total = $price_cstm * $converter->USD;	
					$brk = '<br/>';
					if(is_author()){
						$brk = '';
					}
					$price .= '<span class="cstm_price_api woocommerce-Price-amount amount" style="display:block;">'.$total.'</span>';
					$price .= '<span class="cstm_price_api woocommerce-Price-amount amount" style="display:block;">'.$brk.'( $ '.$total.')</span>';
				}	
			}
		}
	}
	/* var_dump($price); */
	return $price;
}

//Remove redirection author to shop
/*function enable_author_archives_for_customers() {
  remove_action('template_redirect', 'wc_disable_author_archives_for_customers');
}
add_action( 'after_setup_theme', 'enable_author_archives_for_customers' ); */

add_action('wp_ajax_aj_save_author_field', 'aj_save_author_field');
function aj_save_author_field(){
	  $user_id = get_current_user_id();
	  global $wpdb;
        $result = array();
		
		$input = $_POST['first_name'];
		list($f_name, $l_name) = explode(' ', $input);
	
		$profile_img = $_FILES['profile_img'];
		
		if($profile_img){
			
			$attach_id = file_upload($_FILES['profile_img']);
			
			if ($attach_id) {
				
				update_user_meta($user_id, $wpdb->get_blog_prefix() . 'user_avatar', $attach_id);
			  if (\function_exists('wp_rml_move')) { // Install Real Media Library for this feature
					wp_rml_move(1, [$attach_id]);
				}
			}
		}
     
            update_user_meta($user_id, 'first_name', $f_name);
		
            update_user_meta($user_id, 'last_name', $l_name);
		
            update_user_meta($user_id, 'description', trim($_POST['description']));
	
		
			 $user_web = trim($_POST['user_url']);
			 $user_id = wp_update_user( array( 'ID' => $user_id, 'user_url' => $user_web ) );
		
		
	
		 
			 if ( trim($_POST['user_login'])) {
			$user_login = trim($_POST['user_login']);
           /* wp_update_user( array( 'ID' => $user_id, 'user_login' => $user_login, 'user_nicename' => $user_login  ) );  */
		 }		 
		
			update_field( 'field_60da068c290e0', trim($_POST['longbio']), 'user_'.$user_id );
			update_field( 'field_60f0457f2ade5', $_POST['user_loc'], 'user_'.$user_id );
			update_field( 'field_60f12d5398183', $_POST['wall_add'], 'user_'.$user_id );
	
		
		
			update_field( 'field_60d9d9732c70e', trim($_POST['fb_link']), 'user_'.$user_id );
		
		
		
			update_field( 'field_60d9d9a92c710', $_POST['insta_link'], 'user_'.$user_id );
		
		
		
			update_field( 'field_60d9d9b52c711', $_POST['twitter_link'], 'user_'.$user_id ); 
		
		
		
			update_field( 'field_60d9d99d2c70f', trim($_POST['youtube_link']), 'user_'.$user_id );
	
		
		/* if($_POST['selected_cat']){ */
			$tags_sel = explode(',',$_POST['selected_cat']);
			/* var_dump($tags_sel);
			exit; */
			update_field( 'field_60d9da70fac89', $tags_sel, 'user_'.$user_id );
		/* } */
		
		
		 $result['success'] = true;
		 $result['message'] = 'submitted';
      
		echo json_encode($result);
		exit;
	
}
//uplaoding profile image in wordpress
function file_upload($img) {
	$attach_id = '';
	if ($img) {
		
		$uploaddir = wp_upload_dir();
		$file = $img["name"];
		$uploadfile = $uploaddir['path'] . '/' . basename($file);
		
		move_uploaded_file($img["tmp_name"], $uploadfile);
		$filename = basename($uploadfile);
		$wp_filetype = wp_check_filetype(basename($filename), null);
		$attachment = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
			'post_content' => '',
			'post_status' => 'inherit',
			/* 'menu_order' => $_i + 1000 */
		);
		$attach_id = wp_insert_attachment($attachment, $uploadfile);
		$imagenew = get_post($attach_id);
		require_once(ABSPATH . "wp-admin" . '/includes/image.php');
		$fullsizepath = get_attached_file($imagenew->ID);
		$attach_data = wp_generate_attachment_metadata($attach_id, $fullsizepath);
		wp_update_attachment_metadata($attach_id, $attach_data);
	}
	return $attach_id;
}

add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
  echo '<style>
    #energyplus-header .energyplus-menu ul li {
      margin-left: 15px !important;
    } 
	.show_if_simple.tips.show_if_auction,
	.form-field._sale_price_field a.sale_schedule,
	.form-field.uwa_auto_renew_enable_field,
	.uwa_admin_current_time{
    	display: none !important;
	}
  </style>';
}

add_filter('pre_get_posts','shop_page_filter_condition');
function shop_page_filter_condition($query) {

    global $wpdb;
    if(($_GET['orderby'] == 'uwa_bid_asc') || ($_GET['orderby'] == 'uwa_bid_desc') ){
    }else if((isset($_GET['min_price'])) || ($_GET['orderby'] == 'price') || ($_GET['orderby'] == 'price-desc')){
        $auc_prod = $wpdb->get_results("SELECT posts.ID FROM
        wp_posts AS posts
    INNER JOIN wp_term_relationships AS term_relationships ON posts.ID = term_relationships.object_id
    INNER JOIN wp_term_taxonomy AS term_taxonomy ON term_relationships.term_taxonomy_id = term_taxonomy.term_taxonomy_id
    INNER JOIN wp_terms AS terms ON term_taxonomy.term_id = terms.term_id
    WHERE
        term_taxonomy.taxonomy = 'product_type'
    AND terms.slug = 'auction'
    AND posts.post_type = 'product'",ARRAY_A);
        $auc_id =array();
        foreach( $auc_prod as $auc_prod_id ) {
            $auc_id[] = $auc_prod_id["ID"];
          }
    if ( ! $query->is_main_query() ) return;
    if ( ! $query->is_post_type_archive() ) return;
    // $min_price = $_GET['min_price'];
    if ( ! is_admin() && is_shop() ) {
        $query->set( 'post__not_in', $auc_id ); 
    }
    remove_action( 'pre_get_posts', 'searchfilter' );
    }
    // return $query;
   
   
}

add_action('wp_logout','auto_redirect_after_logout');

function auto_redirect_after_logout(){

  wp_redirect( home_url() );
  exit();

}
//------------------------//
add_filter('allow_empty_comment', '__return_true');


add_action( 'woocommerce_after_edit_account_form', 'disable_edit_email_address' );

function disable_edit_email_address( ) {
    $script = '<script type="text/javascript">'.
              'var account_email = document.getElementById("account_email");'.
              'if(account_email) { '.
              '     account_email.readOnly = true; '.
              '     account_email.className += " disable-input";'.
              '}'.
              '</script>';
    echo $script;
}

add_action( 'woocommerce_save_account_details_errors', 'prevent_user_update_email', 10, 2 );

function prevent_user_update_email( &$error, &$user ){
	$current_user = get_user_by( 'id', $user->ID );
	$current_email = $current_user->user_email;
	if( $current_email !== $user->user_email){
		$error->add( 'error', 'E-mail cannot be updated.');
	}
}

//By default set managestock  checkbox checked and stock quantity to 1
add_action( 'admin_enqueue_scripts', 'wc_default_variation_stock_quantity' );
function wc_default_variation_stock_quantity() {
  global $pagenow, $woocommerce;

  $default_stock_quantity = 1;
  $screen = get_current_screen();

  /* if ( ( $pagenow == 'post-new.php' || $pagenow == 'post.php' || $pagenow == 'edit.php' ) && $screen->post_type == 'product' ) { */
  if ( $screen->post_type == 'product' ) {

    ?>
<!-- uncomment this if jquery if it hasn't been included-->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function(){
        if ( !jQuery( '#_manage_stock' ).prop('checked') ) {
          jQuery( '#_manage_stock' ).prop('checked', 'checked');
        }
		if ( !jQuery( '#_sold_individually' ).prop('checked') ) {
          jQuery( '#_sold_individually' ).prop('checked', 'checked');
          jQuery( '#_sold_individually' ).prop('disabled', 'true');
        }
        if ( '' == jQuery( '#_stock' ).val() || 0 == jQuery( '#_stock' ).val() ) {
          jQuery( '#_stock' ).val(<?php echo $default_stock_quantity; ?>);
        }
    });
    </script>
    <?php
  }
}

add_filter('gettext', 'shareontext');
function shareontext($translated) {
	$translated = str_ireplace('Share on', 'Share this NFT on ', $translated);
	return $translated;
}

function wallet_api_ajax() {   
	require_once('wallet_api_data.php'); 
	//$return_string = ob_get_flush();
} 
add_action( 'wp_ajax_wallet_api_ajax', 'wallet_api_ajax' );
add_action( 'wp_ajax_nopriv_wallet_api_ajax', 'wallet_api_ajax' );

function wallet_api_data_script(){
	wp_enqueue_script('wallet_api_data_script', get_stylesheet_directory_uri ().'/js/custom-api.js');
	wp_localize_script( 'wallet_api_data_script', 'wapi_ajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php'))); 	
}
add_action('wp_enqueue_scripts','wallet_api_data_script');
//------------------------//
function tim_wc_add_space_currency( $currency_symbol, $currency ) {
	if ('ETH' == $currency) {
		$currency_symbol = 'ETH ';
	}
    return $currency_symbol;
}
add_filter('woocommerce_currency_symbol', 'tim_wc_add_space_currency', 10, 2);

// Allow duplicate comment 
function enable_duplicate_comments_preprocess_comment($comment_data)
{
	//add some random content to comment to keep dupe checker from finding it
	$random = md5(time());	
	$comment_data['comment_content'] .= "disabledupes{" . $random . "}disabledupes";	
	
	return $comment_data;
}
add_filter('preprocess_comment', 'enable_duplicate_comments_preprocess_comment');


add_action( 'before_delete_post', 'wpse_110037_new_posts' );
add_action( 'save_post', 'wpse_110037_new_posts' );

function wpse_110037_new_posts($post_id){
    update_post_meta($post_id, '_sold_individually', "yes");
}

/******Auction menu shrasti*******/
function uwa_front_user_bid_list_new( $user_id , $bid_status ) {
	global $wpdb, $woocommerce;
	global $product;
	global $sitepress;
	   $table = $wpdb->prefix."woo_ua_auction_log";	
	   $query   = $wpdb->prepare("SELECT auction_id, MAX(bid) as max_userbid FROM $table  WHERE userid = %d GROUP by auction_id ORDER by date DESC", $user_id);	 
	   $my_auctions = $wpdb->get_results( $query );
    $active_bids_count = 0;
    $lost_bids_count = 0;
    $won_bids_count = 0;
    $won_bids_products_ids = array();
	if ( count($my_auctions ) > 0 ) {
			$aelia_addon = "";
			$addons = uwa_enabled_addons();
			if(is_array($addons) && in_array('uwa_currency_switcher', $addons)){			
					$aelia_addon = true;			
			}
		?>
		<div class="resPonsiveTable">
		<table class="shop_table shop_table_responsive tbl_bidauc_list">
			<tr class="bidauc_heading">
			    <th class="toptable"><?php echo __( 'Image', 'woo_ua' ); ?></th>
			    <th class="toptable"><?php echo __( 'Product', 'woo_ua' ); ?></th>
			    <th class="toptable"><?php echo __( 'Your bid', 'woo_ua' ); ?></th>
			    <th class="toptable"><?php echo __( 'Current bid', 'woo_ua' ); ?></th>
			    <th class="toptable"><?php echo __( 'End date', 'woo_ua' ); ?></th>
			    <th class="toptable"><?php echo __( 'Status', 'woo_ua' ); ?></th>
			</tr>
			<?php	
			foreach ( $my_auctions as $my_auction ) {		 
			  
			   $product_id =  $my_auction->auction_id;	
				
				if (function_exists('icl_object_id') && method_exists($sitepress, 'get_current_language')) {
				
					$product_id = icl_object_id($my_auction->auction_id	,'product', false, $sitepress->get_current_language());
				}
			  
			  
			   $product = wc_get_product( $product_id );
			  
				if ( method_exists( $product, 'get_type') && $product->get_type() == 'auction' ) {
					if($aelia_addon == true){
						if($product->uwa_aelia_is_configure() == TRUE){							
							$my_auction->max_userbid = $product->uwa_aelia_base_to_active($my_auction->max_userbid);
						}						
					}	
			        $product_name = get_the_title( $product_id );
			        $product_url  = get_the_permalink( $product_id );
			        $a            = $product->get_image( 'thumbnail' );
			    	if ($bid_status == "won" && $user_id == $product->get_uwa_auction_current_bider() && $product->get_uwa_auction_expired() == '2' ){ 	        			
								$won_bids_count++;
			    		
						?>	
								
						<tr class="bidauc_won">
						<td class="bidauc_img">
						<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image() );
					
						// if ( !$product_permalink ) {
						// 	echo $thumbnail; // PHPCS: XSS ok.
							
						// }
						 $option = get_field('select_option',$product_id);
							if($option == 'video')
							{
								$video_url = get_field('add_video',$product_id );	
								
							echo '<video width="70px" muted="" loop="" autoplay="" src="'.get_field('add_video',$product_id ).'"></video>';
									
							}
							else if($option == 'audio') {
							echo '<div class="audio_minicart"><audio controls><source src="'.get_field('add_audio',$product_id ).'" type="audio/mpeg"></audio> </div>';
							
							}
						
							else {
								
								echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
					</td>
			            	<td class="bidauc_name"><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
			            	<td class="bidauc_bid"><?php echo wc_price($my_auction->max_userbid); ?></td>
			            	<td class="bidauc_curbid"><?php echo $product->get_price_html(); ?></td>
			            	<td class="bidauc_enddate"><?php echo $product->get_uwa_auction_end_dates(); ?></td>	
							<?php
			            	/* -----  Pay now button for winner ----- */
							if (($user_id == $product->get_uwa_auction_current_bider() && $product->get_uwa_auction_expired() == '2' && !$product->get_uwa_auction_payed() )) {
								$won_bids_products_ids[]= $product->get_id();
								$checkout_url = esc_attr(add_query_arg("pay-uwa-auction",$product->get_id(), uwa_auction_get_checkout_url()));
				            	?>
								<td class="bidauc_status">
									<?php
									
									/* --- when offline_addon is active --- */
									$addons = uwa_enabled_addons();
									if(is_array($addons) && in_array(
										'uwa_offline_dealing_addon', $addons)){
									
											// buyers and stripe both deactive
										if(!in_array('uwa_buyers_premium_addon',
											$addons) &&
											!in_array('uwa_stripe_auto_debit_addon', $addons)){
											//echo "in 1";
										}	// buyers active only
										elseif(in_array('uwa_buyers_premium_addon',
											$addons) &&
											!in_array('uwa_stripe_auto_debit_addon', $addons)){
											//echo "in 2";	
											?>
												<a href="<?php echo $checkout_url; ?>" class="button alt">
												<?php echo apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __( "Pay Buyer's Premium",
													'woo_ua' ),
												$product); ?>
												</a>	
											<?php 			
										}  // buyers and stripe both active
										elseif(in_array('uwa_buyers_premium_addon',
											$addons) &&
											in_array('uwa_stripe_auto_debit_addon', $addons)){
											//echo "in 3";				
										}
									}
									else{
										
										?>
										<a href="<?php echo $checkout_url; ?>"
											class="button alt">
										<?php echo apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __( 'Pay Now', 'woo_ua' ), $product); ?>
										</a>	
										<?php
									} /* end of else */
									?>									
									
								</td>
							
			            		<?php
			            	}
			            	else { ?>			            		
			            		<td class="bidauc_status"><?php echo __( 'Closed', 'woo_ua' ); ?></td>
			            		<?php
			        		}  ?>
							</tr> 	
			     	<?php } /* end of if of won  */
			    	
			    	/* ------------------------ For Lost bids  ---------------------- */
			    	elseif ($bid_status == "lost" && $user_id != $product->get_uwa_auction_current_bider() && $product->get_uwa_auction_expired() == '2' ){
								$lost_bids_count++;
			    	 ?>			
						<tr class="bidauc_lost">
						<td class="bidauc_img">
						<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image() );
					
						// if ( !$product_permalink ) {
						// 	echo $thumbnail; // PHPCS: XSS ok.
							
						// }
						 $option = get_field('select_option',$product_id);
							if($option == 'video')
							{
								$video_url = get_field('add_video',$product_id );	
								
							echo '<video width="70px" muted="" loop="" autoplay="" src="'.get_field('add_video',$product_id ).'"></video>';
									
							}
							else if($option == 'audio') {
							echo '<div class="audio_minicart"><audio controls><source src="'.get_field('add_audio',$product_id ).'" type="audio/mpeg"></audio> </div>';
							
							}
						
							else {
								
								echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
					</td>
			            	<td class="bidauc_name"><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
			            	<td class="bidauc_bid"><?php echo wc_price($my_auction->max_userbid); ?></td>
			            	<td class="bidauc_curbid"><?php echo $product->get_price_html(); ?></td>
			            	<td class="bidauc_enddate"><?php echo $product->get_uwa_auction_end_dates(); ?></td>
			            	<td class="bidauc_status"><?php echo __( 'Closed', 'woo_ua' ); ?></td>	                	
							</tr> 	
			     	<?php } /* end of if of lost */
			     	/* ------------------------ For active bids  ---------------------- */
			     	elseif($bid_status == "active" && $product->get_uwa_auction_expired() == false){
			     			$active_bids_count++;
			     		?>
			     		<tr class="bidauc_active">
						 <td class="bidauc_img">
						<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image() );
					
						// if ( !$product_permalink ) {
						// 	echo $thumbnail; // PHPCS: XSS ok.
							
						// }
						 $option = get_field('select_option',$product_id);
							if($option == 'video')
							{
								$video_url = get_field('add_video',$product_id );	
								
							echo '<video width="70px" muted="" loop="" autoplay="" src="'.get_field('add_video',$product_id ).'"></video>';
									
							}
							else if($option == 'audio') {
							echo '<div class="audio_minicart"><audio controls><source src="'.get_field('add_audio',$product_id ).'" type="audio/mpeg"></audio> </div>';
							
							}
						
							else {
								
								echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
					</td>
			            	<td class="bidauc_name"><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
			            	<td class="bidauc_bid"><?php echo wc_price($my_auction->max_userbid); ?></td>
			            	<td class="bidauc_curbid"><?php echo $product->get_price_html(); ?></td>
			            	<td class="bidauc_enddate"><?php echo $product->get_uwa_auction_end_dates(); ?></td>
			            	<td class="bidauc_status"><?php echo __( 'Started', 'woo_ua' ); ?></td>	                	
							</tr> 	
							<?php
			     	}
				}  /* end of if method exists  */
				
			} /* end of foreach */
			if($bid_status == "won" && count($won_bids_products_ids) > 1){ ?>
				<tr>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td colspan="2" style="text-align:center;">		
				  <?php
								echo '<a href="'.apply_filters( 'ultimate_woocommerce_auction_all_pay_now_button_text',esc_attr(add_query_arg("pay-uwa-auction",implode(",", $won_bids_products_ids), uwa_auction_get_checkout_url()))).'" class="button">'.__( 'Check Out All', 'woo_ua' ).'</a>';  ?>
				</td>
				</tr>
			 <?php	
			}
			elseif($bid_status == "won" && $won_bids_count == 0){ ?>
				<tr class="bidauc_msg"><td colspan="6"><div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">		
				  <?php _e( 'No bids available yet.' , 'woo_ua' ) ?>
				</div></td></tr>
			 <?php	
			}elseif($bid_status == "lost" && $lost_bids_count == 0){ ?>
				<tr class="bidauc_msg"><td colspan="6"><div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">		
				  <?php _e( 'No bids available yet.' , 'woo_ua' ) ?>
				</div></td></tr>
				
			 <?php
			}elseif($bid_status == "active" && $active_bids_count == 0){ ?>
				<tr class="bidauc_msg"><td colspan="6"><div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">		
				  <?php _e( 'No bids available yet.' , 'woo_ua' ) ?>
				</div></td></tr>
				 <?php	
			}
			?>
		</table>
		</div>
	<?php
	} /* end of if - count */
	else {
		$shop_page_id = wc_get_page_id( 'shop' );
		$shop_page_url = $shop_page_id ? get_permalink( $shop_page_id ) : '';
		?>
		<div class="woocommerce-message woocommerce-message--info woocommerce-Message 	
			woocommerce-Message--info woocommerce-info">		
			  <a class="woocommerce-Button button" href="<?php echo $shop_page_url;?>">
				<?php _e( 'Go shop' , 'woocommerce' ) ?>		</a> <?php _e( 'No bids available yet.' , 'woo_ua' ) ?>
		</div>
	                
	<?php } /* end of else */
}

/**
 * Get Auction WatchList By User Id
 *
 */
function get_uwa_auction_watchlist_by_user_new( $user_id  ) {
	
	global $wpdb;	
	$results = get_user_meta( $user_id, "woo_ua_auction_watch"); 

	return $results;
} 

function uwa_front_user_watchlist_new( $user_id ){

	$my_auctions_watchlist = get_uwa_auction_watchlist_by_user_new($user_id);

	if ( count($my_auctions_watchlist ) > 0 ) {
	?>
	<table class="shop_table shop_table_responsive tbl_watchauc_list">
	    <tr class="watchauc_heading">
	        <th class="toptable"><?php echo __( 'Image', 'woo_ua' ); ?></td>
	        <th class="toptable"><?php echo __( 'Product', 'woo_ua' ); ?></td>
	        <th class="toptable"><?php echo __( 'Current bid', 'woo_ua' ); ?></td>
	        <th class="toptable"><?php echo __( 'Status', 'woo_ua' ); ?></td>
	        <th class="toptable"></td>
	    </tr>
	    <?php
	    foreach($my_auctions_watchlist as $key => $value) {

	        $product      = wc_get_product( $value );
	        if ( !$product )
	            continue;

	        if ( method_exists( $product, 'get_type') && $product->get_type() == 'auction' ) {

		        $product_name = get_the_title( $value );
		        $product_url  = get_the_permalink( $value );
		        $a            = $product->get_image( 'thumbnail' );
				$checkout_url = esc_attr(add_query_arg("pay-uwa-auction", $product->get_id(), uwa_auction_get_checkout_url()));
		        ?>
		        <tr class="watchauc_list">
		            <td class="watchauc_img ss">

						<?php
						$thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $product->get_image() );

						// if ( !$product_permalink ) {
						// 	echo $thumbnail; // PHPCS: XSS ok.

						// }
						 $option = get_field('select_option',$value);
							if($option == 'video')
							{
								$video_url = get_field('add_video',$value );

							echo '<video width="70px" playsinline muted="" loop="" autoplay="" src="'.get_field('add_video',$value ).'"></video>';

							}
							else if($option == 'audio') {
							echo '<div class="audio_minicart bid_audio"><audio controls><source src="'.get_field('add_audio',$value ).'" type="audio/mpeg"></audio> </div>';

							}

							else {

								echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
					</td>
		            <td class="watchauc_name"><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
		            <td class="watchauc_curbid"><?php echo $product->get_price_html(); ?></td>
		            <?php

		            /* -----  Pay now button for winner ----- */

					if (($user_id == $product->get_uwa_auction_current_bider() &&
						$product->get_uwa_auction_expired() == '2' && !$product->get_uwa_auction_payed() )) {

		              	?>
						<td class="watchauc_status">
								<?php

								/* --- when offline_addon is active --- */

								$addons = uwa_enabled_addons();
								if(is_array($addons) && in_array(
									'uwa_offline_dealing_addon', $addons)){

										// buyers and stripe both deactive
									if(!in_array('uwa_buyers_premium_addon',
										$addons) &&
										!in_array('uwa_stripe_auto_debit_addon', $addons)){
										//echo "in 1";

									}	// buyers active only
									elseif(in_array('uwa_buyers_premium_addon',
										$addons) &&
										!in_array('uwa_stripe_auto_debit_addon', $addons)){
										//echo "in 2";
										?>
											<a href="<?php echo $checkout_url; ?>"
												class="button alt">
												<?php echo apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __(
													"Pay Buyer's Premium",
													'woo_ua' ), $product); ?>
											</a>

									<?php

									}  // buyers and stripe both active
									elseif(in_array('uwa_buyers_premium_addon',
										$addons) &&
										in_array('uwa_stripe_auto_debit_addon', $addons)){
										//echo "in 3";
									}

								}
								else{
									?>
									<a href="<?php echo $checkout_url; ?>"
										class="button alt">
										<?php echo apply_filters('ultimate_woocommerce_auction_pay_now_button_text', __( 'Pay Now',
											'woo_ua' ), $product); ?>
									</a>

									<?php

								} /* end of else */

								?>

						</td>
		            	<?php
		        	} elseif ( $product->is_uwa_expired() ){ ?>

						<td class="watchauc_status"><?php echo __( 'Closed', 'woo_ua' ); ?></td>

						<?php } else { ?>
		                <td class="watchauc_status"><?php echo __( 'Started', 'woo_ua' ); ?></td>
		                <?php
		            }
		            ?>
					<td class="product-remove">
						<a href="javascript:void(0)" data-auction-id="<?php echo esc_attr( $product->get_id() ); ?>"
						class="remove-uwa uwa-watchlist-action remove" aria-label="Remove this item">×</a>
					</td>

		        </tr>
	        <?php
	    	}
		} ?>

	</table>

	  <?php
	}
	else { ?>

	   	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info watchauc_msg">

			   <?php _e( 'No auctions in watchlist' , 'woo_ua' ) ?>
		</div>

	<?php }
}

/*******end aution menu*********/


function empty_cart_on_logout() {
    global $woocommerce;
	$woocommerce->cart->empty_cart();
}
add_action('clear_auth_cookie', 'empty_cart_on_logout');

add_filter('comment_flood_filter', '__return_false');


add_action( 'admin_print_scripts-user-new.php', 'add_jquery' );

function add_jquery(){

    wp_enqueue_script(
        'add_input_field',get_stylesheet_directory_uri().'/js/addUserField.js',
        array( 'jquery' ),
        false,
        true
    );

}

function my_enqueue() {

      wp_enqueue_script(
        'add_input_field_new',get_stylesheet_directory_uri().'/js/addUserField.js',
        array( 'jquery' ),
        false,
        true
    );
}

add_action('admin_print_scripts-user-edit.php', 'my_enqueue');

add_action( 'wp_footer', 'load_custom_verification');

function load_custom_verification(){

		if(isset($_GET['akey'])){
				  $verification = base64_decode($_GET['verificationaccount']);
				
				  $key = $_GET['akey'];
				  $userData = explode('_',$verification);
				  $key_exists = get_user_meta($userData[2],'activation_pass_key',true);
				  $check_last_date = get_user_meta($userData[2], 'last_link_date', true);
				
				  //echo $key_exists;
				  //echo $key;	
				// delete_user_meta($userData[2],'activation_pass_key');
				  if(!empty($key_exists) && ($key_exists == $key) && ( strtotime(current_time('mysql')) - $check_last_date < 15 * 60)){
					  $key_status = get_user_meta($userData[2],'status',true);
					  if($key_status == 'inactive'){
						  update_user_meta($userData[2],'status','active');
						  delete_user_meta($userData[2],'activation_pass_key');
						  ?>
						  <div class="alert alert-success alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<strong>Congratulations!</strong> Your account has been verified. Please login your account with your credentials!!
</div>
						
						<?php  
					  }else{
						  
					  } 
				  }else{
					  ?>
					  			  <div class="alert alert-danger alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
your link has been expired!!!
</div>
				 <?php 
				 }
		
	} ?>
	<div class="ApWait" style="display: none;">
  <div class="loader_child">
    <div id="loading-bar-spinner" class="spinner">
      <div class="spinner-icon"></div>
    </div>
  </div>
</div>
	<script>
		jQuery( document ).ready(function() {

		setTimeout(function(){
    jQuery('.alert.alert-dismissible').remove();
},5000);
if(jQuery('body').hasClass('logged-in')) {
    jQuery('.alert.alert-danger.alert-dismissible').remove();    
}
});
	</script>
<?php }