
	jQuery( document ).ready(

    function($){
		$('#description').attr('maxlength','90');

        var insertElements = 
            '<tr class="form-field">' +
            '   <th scope="row"><label for="description">Biographical Info(short bio)</label></th>' +
            '   <td><textarea name="description" id="description" rows="5" cols="30" maxlength="90"></textarea><br /><span class="description">90 characters only. Share a little biographical information to fill out your profile. This may be shown publicly.</span></td>' +
            '</tr>';

        $( '#createuser .form-table[role="presentation"] tbody' ).append( insertElements );
		
		$('.user-description-wrap .description').prepend('90 characters only. ');

    }

);
