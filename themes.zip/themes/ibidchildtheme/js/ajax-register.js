function ValidateUsername(name) {
    var expr = /^[a-zA-Z0-9_]{3,20}$/;
    if (!expr.test(name)) {
        return false;
    }
    return true;
}

jQuery(document).ready(function($) {
if (!$("body").hasClass("dokan-theme-ibid")) {
 var pass_message = '';
	$('#reg_confirm_password').keypress(function(){
		$('span.msg').remove();
		if($('#reg_confirm_password').val() == $('#reg_password').val()){
			$('#reg_confirm_password').after('<span class="msg pass" style="font-size:15px;padding-left:10px;font-weight:500;">Matched</span>');
			pass_message='Matched';
		}else{
			$('#reg_confirm_password').after("<span class='msg error' style='font-size:15px;padding-left:10px;font-weight:500;'>Password doesn't match</span>");
			pass_message="Password doesn't match";
		}
		//return;
	});

$('#reg_confirm_password').keyup(function(){
		/* if($('#reg_password').val().length < 5){
			$('#reg_password').trigger('blur');
			$('#reg_confirm_password').val('');
			setTimeout(function() {
				$('#reg_password').after("<span class='msg error' style='font-size:15px;padding-left:10px;font-weight:500;'>you have to enter at least 6 digit password!!</span>");
				jQuery('#reg_password').focus();
			}, 1000);
		} */
		$('span.msg').remove();
		if($('#reg_confirm_password').val() == $('#reg_password').val()){
			$('#reg_confirm_password').after('<span class="msg pass" style="font-size:15px;padding-left:10px;font-weight:500;">Matched</span>');
		}else{
			$('#reg_confirm_password').after("<span class='msg error' style='color:red;font-size:15px;padding-left:10px;font-weight:500;'>Password doesn't match</span>");
		}
	}); 
	
	$('#reg_password').keyup(function(){
		if($('#reg_confirm_password').val()){
			$('span.msg').remove();
			if($('#reg_confirm_password').val() == $('#reg_password').val()){
				$('#reg_confirm_password').after('<span class="msg pass" style="font-size:15px;padding-left:10px;font-weight:500;">Matched</span>');
			}else{
				$('#reg_confirm_password').after("<span class='msg error' style='color:red;font-size:15px;padding-left:10px;font-weight:500;'>Password doesn't match</span>");
			}

		}
	}); 
	
$('#reg_confirm_password').change(function(){
		$('span.msg').remove();
		if($('#reg_confirm_password').val() == $('#reg_password').val()){
			$('#reg_confirm_password').after('<span class="msg pass" style="font-size:15px;padding-left:10px;font-weight:500;">Matched</span>');
			pass_message='Matched';
		}else{
			$('#reg_confirm_password').after("<span class='msg error' style='font-size:15px;padding-left:10px;font-weight:500;'>Password doesn't match</span>");
			pass_message="Password doesn't match";
		}
		//return;
	});

	/*$('#reg_password').blur(function(){
		$("span.msg").remove();
		if($('#reg_password').val().length > 5){
			$('span.msg').remove();
		}else{
			$('#reg_password').after("<span class='msg error' style='font-size:15px;padding-left:10px;font-weight:500;color:red;'>you have to enter at least 6 digit password!!</span>");
			$('#reg_password').focus();
		}
	}); */

	jQuery('input#reg_username').on('keyup', function(){
		var uname = jQuery(this).val();
        jQuery.ajax({
              url : '/wp-admin/admin-ajax.php',
              type : 'post',
              dataType: 'json',
              data : {
                  action : 'checkUsername',
                  uname: uname
              },
              success : function( response ) {
                console.log(response);
                if (response.msg == 'u_not_taken') {
                	// jQuery('#reg_username_message').text(response.message);
                	//jQuery('#reg_username_message').addClass( "reg_username_message_success" );
                	if(uname == '')
						{
							jQuery('#valid_username').text('');
							// jQuery('#reg_username_message').removeClass( "reg_username_message_success" );
						} else {
							jQuery('#valid_username').text('');
						}
                }
                else
                {
                	jQuery('#valid_username').show().text(response.message);
                	// jQuery('#reg_username_message').removeClass( "reg_username_message_success" );
                }
              }
          });		
	});
	
    
    $('form#register').on('submit', function(e){
		//alert($('span.error').text());
		if($('span.error').length > 0){
			if($('span.error').text()=="Password doesn't match"){				
				$('span.error').css("display","block");				
				/* $('#reg_confirm_password').focus(); */
				//alert($('span.error').text());
				return false;
			}else{$('#reg_confirm_password').after(' ');}

			return false;
			}else{$('#reg_confirm_password').after(' ');}
			
        $('form#register p.status').show().text(ajax_login_object.loadingmessage);
        $('form#register #valid_username').hide();
		var cntry_code = $('#iti-0__country-listbox > li[aria-selected="true"]').find('span.iti__dial-code').text();
		var phn_no =  cntry_code+$('form#register #reg_billing_mobile_phone').val();
		var username = $('form#register #reg_username').val();
		if(ValidateUsername(username) == false){
			 $('form#register p.status').hide();
			$('form#register #valid_username').show().text('Username field allowed only alphanumeric and underscore and between 3 to 20 characters.!!!');
			$('form#register #reg_username').focus();			
			return false;
		}else if(ValidateUsername(username) == false){
			$('form#register p.status').hide();
			$('form#register #valid_username').show().text('Username field allowed only alphanumeric and underscore and between 3 to 20 characters.!!!');
			$('form#register #reg_username').focus();
			return false;
		}
		else{
			$('form#register #valid_username').hide();
		}
		
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_register_object.ajaxurl,
            data: {
                action: 'register_user',
                'username': $('form#register #reg_username').val(),
                'email': $('form#register #reg_email').val(),
                'password': $('form#register #reg_password').val(),
				'confirm_password': $('form#register #reg_confirm_password').val(),
                'security': $('form#register #security').val(),
                'billing_mobile_phone': phn_no },
            success: function(data){
			$('#reg_password').after('');
				if(data.message == 'passwordLength'){
					$('#password-strength-status').text('');
					$('#reg_password').after('<span class="msg pass" style="font-size:15px;padding-left:10px;font-weight:500;color:red">You have to enter at least 6 digit password!!</span>');
					$('form#register p.status').text('');
					
				}
				if(data.message != 'passwordLength'){
                $('form#register p.status').text(data.message);
				$('#reg_password').after('');
				}
				console.log('success -'+data.reset_form);
				if(data.reset_form == 'yes'){
					$('form#register')[0].reset();
					$('#password-strength-status').text('');
				}
				console.log('success -'+data.message);
				if(data.success == true){
					$('.woocommerce-password-strength,.woocommerce-password-hint').hide();
					$('p.status').hide();
					swal(data.message);
					
				}
               /*  if (data.loggedin == true){
                    document.location.href = ajax_register_object.redirecturl;
                } */
				//$('#register').reset();
				//$('#register').trigger("reset"); 
				//$('#register')[0].reset();
            },error:function(data){
				 $('form#register p.status').text('Something goes wrong!! Please try again');
				 console.log('error -'+data.message);
			}

        });
        e.preventDefault();
    });
}
});
