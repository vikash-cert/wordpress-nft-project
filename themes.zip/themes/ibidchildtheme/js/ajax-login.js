jQuery(document).ready(function($) {

	var urlParams = new URLSearchParams(window.location.search); //get all parameters
	var res_pass = urlParams.get('reset-pass');
	if(res_pass == 'true'){
		var ModalEffects = (function() {
            function init_modal() {

                var overlay = document.querySelector( '.modeltheme-overlay' );

                [].slice.call( document.querySelectorAll( '.modeltheme-trigger' ) ).forEach( function( el, i ) {

                    var modal = document.querySelector( '#' + el.getAttribute( 'data-modal' ) ),
                        close = modal.querySelector( '.modeltheme-close' );

                    function removeModal( hasPerspective ) {
                        classie.remove( modal, 'modeltheme-show' );

                        if( hasPerspective ) {
                            classie.remove( document.documentElement, 'modeltheme-perspective' );
                        }
                    }

                    function removeModalHandler() {
                        removeModal( classie.has( el, 'modeltheme-setperspective' ) ); 
                    }

                  
                        classie.add( modal, 'modeltheme-show' );
                        overlay.removeEventListener( 'click', removeModalHandler );
                        overlay.addEventListener( 'click', removeModalHandler );

                        if( classie.has( el, 'modeltheme-setperspective' ) ) {
                            setTimeout( function() {
                                classie.add( document.documentElement, 'modeltheme-perspective' );
                            }, 25 );
                        }
                    

                } );

            }

        if (!jQuery("body").hasClass("login-register-page")) {
            init_modal();
        }

    })();
	}


    // Show the login dialog box on click
    $('a#show_login').on('click', function(e){
        $('body').prepend('<div class="login_overlay"></div>');
        $('form#login').fadeIn(500);
        $('div.login_overlay, form#login a.close').on('click', function(){
            $('div.login_overlay').remove();
            $('form#login').hide();
        });
        e.preventDefault();
    });

    // Perform AJAX login on form submit
    $('form#login').on('submit', function(e){
        $('form#login p.status').show().text(ajax_login_object.loadingmessage);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_login_object.ajaxurl,
            data: { 
                'action': 'ajaxlogin', //calls wp_ajax_nopriv_ajaxlogin
                'username': $('form#login #username').val(), 
                'password': $('form#login #password').val(), 
                'security': $('form#login #security').val() },
            success: function(data){
				if(data.success == true){
					$('form#login p.status').css('color','green');
				}
                $('form#login p.status').text(data.message);
                if (data.loggedin == 'not'){
                    //document.location.href = ajax_login_object.redirecturl;
					$('form#OtpForm p.status').text(data.message);
					$('form#login').hide();
					$('form#OtpForm').show();
                }else if (data.loggedin == true){
                    $("form#login p.status").addClass("success");
                    document.location.href = ajax_login_object.redirecturl;
					
					
                }
            }
        });
        e.preventDefault();
    });
	 $('form#OtpForm').on('submit', function(e){
        $('form#OtpForm p.status').show().text(ajax_login_object.loadingmessage);
	var form_data = new FormData();
    
    form_data.append('action', 'otplogin');
    form_data.append("username", $('form#login #username').val());
	form_data.append("password", $('form#login #password').val());
	form_data.append("otp", $('form#OtpForm #otp').val());

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_login_object.ajaxurl,
            data: form_data,
            processData: false,
            contentType: false,
            success: function(data){
                $('form#OtpForm p.status').text(data.message);
                if (data.loggedin == true){
                    document.location.href = ajax_login_object.redirecturl;
					
					
                }
            }
        });
        e.preventDefault();
    });
	
	$('#resend').on('click',function(e){
	
        $('form#login p.status').show().text(ajax_login_object.loadingmessage);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_login_object.ajaxurl,
            data: { 
                'action': 'ajaxlogin', //calls wp_ajax_nopriv_ajaxlogin
                'username': $('form#login #username').val(), 
                'password': $('form#login #password').val(), 
                'security': $('form#login #security').val() },
            success: function(data){
                $('form#login p.status').text(data.message);
                if (data.loggedin == true){
                    //document.location.href = ajax_login_object.redirecturl;
					$('form#OtpForm p.status').text(data.message);
					$('form#login').hide();
					$('form#OtpForm').show();
					
					
                }
            }
        });
        e.preventDefault();
 
		
	});
	
	  $("#otp").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
        //$("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
    }
   });

});