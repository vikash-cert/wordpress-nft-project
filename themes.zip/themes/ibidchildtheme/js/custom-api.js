jQuery(document).ready(function() {
	jQuery('#max-amount').click(function() {
		jQuery('#withdraw-amount').val(jQuery('#eth-balance').val());
	});
});