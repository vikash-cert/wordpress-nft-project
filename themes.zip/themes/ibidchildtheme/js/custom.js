// var modal = document.getElementById("myModal");


// function openModal(e,pId = 0){

//   modal.style.display = "block";
//   console.log("abc");
 

// }
// window.onclick = function(event) {
//   if (event.target == modal) {
//     modal.style.display = "none";
//   }
// }

// function closePopup(){
	
//   modal.style.display = "none";
  
// }
function addAmount(){
	jQuery('.amountForm').show();
}

/*function generateAddress(){
	
	var url = jQuery('#adminurl').val();
		
		var form_data = new FormData();
		form_data.append('action','generateaddress');
	    jQuery.ajax({
        url: url,
        method: 'POST',
		data : form_data,
		dataType: 'json',
		contentType: false,
		processData: false,
		 beforeSend: function() {
        jQuery('.ApWait').show();
		},
        success: function(results) {
			jQuery('.ApWait').hide();
			if(results.status == 'success'){
				swal("Success!", "Wallet address has been generated successfully!!", "success");
				setTimeout(function(){
				location.reload(true);
				},2000);
				
			}else{
				swal("Error!", results.msg, "error");
			}
			jQuery('#register').trigger("reset"); 
			//jQuery('#register')[0].reset();
		},
		error: function(error) {
        jQuery('.ApWait').hide();
		swal("Error!", "Somethings goes wrong! please try again", "error");  
		console.log('wallet '+error);
        }
	});
	
}*/

function generateAddress(){
    var url = jQuery('#adminurl').val();
//	console.log(url);
        var form_data = new FormData();
        form_data.append('action','generateaddress');
        jQuery.ajax({
        url: url,
        method: 'POST',
        data : form_data,
        dataType: 'json',
        contentType: false,
        processData: false,
         beforeSend: function() {
        jQuery('.ApWait').show();
        },
        success: function(results) {
			alert("in success");
            jQuery('.ApWait').hide();
            if(results.status == 'success'){
                swal("Success!", "Wallet address has been generated successfully!!", "success");
                setTimeout(function(){
                location.reload(true);
                },2000);
            }else{
                swal("Error!", results.msg, "error");
            }
        },
        error: function(error) {
        jQuery('.ApWait').hide();
        swal("Error!", "Somethings goes wrong! please try again", "error");  
        }
    });
}

/*audio player js */
 document.addEventListener('DOMContentLoaded', function() {
            GreenAudioPlayer.init({
                selector: '.player',
                stopOthersOnPlay: true
            });
        });

/* ajax for price update and publish produc */
jQuery(window).on('load',function(){

    jQuery("a.remove").on('click', function(event){
        setTimeout(function(){ 
            GreenAudioPlayer.init({
                    selector: '.player',
                    stopOthersOnPlay: true
                });
         }, 5000);    
    });

	if(jQuery("#reg_billing_mobile_phone").length == 1){
	jQuery("#reg_billing_mobile_phone").intlTelInput();
	}
	if (jQuery("#payment_method_meta_gateway").is(":checked") || jQuery("#payment_method_fortmatic").is(":checked")) {
		jQuery('#place_order').css('visibility',"hidden");
		
	}

	jQuery('#payment .wc_payment_method label').on('click touchstart',function(){
		jQuery('#place_order').css('visibility',"visible");
		
	});
	jQuery('.payment_method_fortmatic label, .payment_method_meta_gateway label').on('click touchstart',function(){
		jQuery('#place_order').css("visibility", "hidden");
		
	});
});
jQuery(document).ready(function(){ 

	// single product - on click of play icon...load video/audio
	jQuery('.single-product .play_pro').on('click',function(){
		if(jQuery('.vid-aud').length > 0){
			jQuery('.woocommerce-product-gallery__image--placeholder').hide();
			jQuery('.play_pro').hide();
			jQuery('.vid-aud').show(); 
			jQuery('#shrt_vid_sp').trigger('play');
		}else{
			jQuery('.woocommerce-product-gallery__image--placeholder').hide();
			jQuery('.play_pro').hide();
			jQuery('.aud_cstm').show(); 
			jQuery('#shrt_aud_sp').trigger('play');
		}
	});
	
	
	if(jQuery('.user-role').length > 0){
		jQuery('.user-role label:eq(1)').html('<input type="radio" name="role" value="seller"> I am a creator');
	}
	
	/* if(jQuery('.post-type-archive-product .sidebar-content .widget_price_filter').length > 0){
		var siteurl = jQuery('#siteurl').val();
		jQuery('.sidebar-content .widget_price_filter form').removeAttr('action');
		jQuery('.sidebar-content .widget_price_filter form').attr('action',siteurl+'/index.php/shop');
	} */
	
	
	jQuery("#submitData").click(function(e) {

        EThAppDeployApproval.loadEtherium();
		console.log('test');

        /* */
    });
	
	
/* jQuery("#submitData").click(function(e){	
		var url = jQuery('#url').val();
		var updatePrice = jQuery('#update-price').val();
		var pid = jQuery('#pid').val();
			
		var form_data = new FormData();
		form_data.append('updatePrice',updatePrice);
		form_data.append('pid',pid);
		form_data.append('action','publishProduct');
	    jQuery.ajax({
        url: url,
        method: 'POST',
		data : form_data,
		dataType: 'json',
		contentType: false,
		processData: false,
		 beforeSend: function() {
        jQuery('.ApWait').show();
		},
        success: function(results) {
			jQuery('.ApWait').hide();
			if(results.status == 'success'){
				swal("Success!", "Your product has been updated successfully!!", "success").then(okay => {
   if (okay) {
    window.location.href = results.url;
  }
});
				setTimeout(function(){
					window.location.href = results.url;
				},2000);
				
			}else{
				swal("Error!", results.msg, "error");
			}

		},
		error: function(error) {
        jQuery('.ApWait').hide();
		swal("Error!", "Somethings goes wrong! please try again", "error");  
        }
	});
}); */

/*if(jQuery('#withdrawForm').length > 0){
console.log('withdraw');
 
        jQuery('#withdrawForm').validate({
            ignore: "",
            rules: {

                withdrawAddress: {
                    required: true,
                },
                confirmAddress: {
                    required: true,
                    equalTo: "#withdraw-address"
                },
                withdrawAmount: {
                    required: true,
                    max: function() {
                        return parseFloat(jQuery('#eth-balance').val());
                    }
                },

            },
            messages: {

                withdrawAddress: {
                    required: "Please enter the field"
                },
                confirmAddress: {
                    required: "Please enter the field",
                    equalTo: "Please Enter Same address"
                },
                withdrawAmount: {
                    required: "Please enter the field",
                    max: "Please enter wallet amount or below amount"
                },

            },
			
			submitHandler: function(form) {

        var withdrawAddr = jQuery("#withdraw-address").val();
        var withdrawAmt = jQuery("#withdraw-amount").val();
        var withdrawApi = jQuery("#wallet-apiurl").val();
        var withdrawApikey = jQuery("#wallet-apikey").val();
        jQuery('.ApWait').show();

        var formData = {
            'toAddress': withdrawAddr,
            'amount': withdrawAmt,
			
        };

        jQuery.ajax({
            url: withdrawApi,
            type: "post",
            data: formData,
			beforeSend: function(xhr){xhr.setRequestHeader('x-api-key', withdrawApikey);},
            success: function(response) {
                if (response.success == true) {
                    var ajax_url = jQuery('#adminurl').val();
                    var trx_address = response.result.txHash;
                    var from_walAddress = jQuery('#wallet-address').val();
                    var from_walUserid = jQuery('#wallet-userid').val();
                    var Datas = {
                        'toAddress': withdrawAddr,
                        'amount': withdrawAmt,
                        'hash': trx_address,
                        'from_walAddress': from_walAddress,
                        'action': 'insert_transaction_history',
                        'type': 'withdraw',
                        'user_id': from_walUserid
                    };
                    jQuery.post(ajax_url, Datas, function(response) {
                        if (response.status = 200) {
                            jQuery('.ApWait').hide();
                           location.reload();


                        }
                    });
                } else {
                    jQuery('.ApWait').hide();
                    window.alert('Something went wrong, Please try again later.');
                    location.reload();
                }
                jQuery("#withdraw-address").val('');
                jQuery("#confirm-address").val('');
                jQuery("#withdraw-amount").val('');

            }

        });
    }

			
			/*submitHandler: function(form) {
                var withdrawAddr = jQuery("#withdraw-address").val();
                var withdrawAmt = jQuery("#withdraw-amount").val();
                var withdrawApi = jQuery("#wallet-apiurl").val();
                var api_key = jQuery('#api-key').val();
                
                    if(withdrawAmt <= 0){
                        alert('No Balance to Process Withdrawal');
                        return false;
                    }
                    jQuery('.ApWait').show();
                var formData = {
                    'toAddress': withdrawAddr,
                    'amount': withdrawAmt,
                };
                
                jQuery.ajax({
                    url: withdrawApi,
                    type: "post",
                    data: formData,
                    headers: {
                        "x-api-key": api_key
                    },
                    success: function(response) {
                        if (response.success == true) {
                            var ajax_url = jQuery('#adminurl').val();
                            var trx_address = response.result.txHash;
                            var from_walAddress = jQuery('#wallet-address').val();
                            var from_walUserid = jQuery('#wallet-userid').val();
                            
                        
                          
                            var Datas = {
                                'toAddress': withdrawAddr,
                                'amount': withdrawAmt,
                                'hash': trx_address,
                                'from_walAddress': from_walAddress,
                                'action': 'insert_transaction_history',
                                'type': 'withdraw',
                                'user_id': from_walUserid
                            };
                            jQuery.post(ajax_url, Datas, function(response) {
                                debugger;
                                if (response.status = 200) {
                                    jQuery('.ApWait').hide();
                                    location.reload();


                                }
                            });
                        } else {
                            jQuery('.ApWait').hide();
                            window.alert('Something went wrong, Please try again later.');
                            location.reload();
                        }
                        jQuery("#withdraw-address").val('');
                        jQuery("#confirm-address").val('');
                        jQuery("#withdraw-amount").val('');

                    }

                });
            }*/
			
            /*submitHandler: function(form) {

                var data = {
                    'action' : 'insert_transaction_history',
                    'toAddress': jQuery("#withdraw-address").val(),
                    'amount': jQuery("#withdraw-amount").val(),
                    'walletAdress': jQuery('#wallet-address').val(),
                    'from_walUserid': jQuery('#wallet-userid').val(),
                    
                };
                 jQuery.ajax({
                    url: jQuery('#adminurl').val(),
                    type: 'post',
                    data: data,
                    dataType: 'json',
                    beforeSend: function() {
                        jQuery('.ApWait').show();
                    },
                    success: function(response) {
						
                        if (response.success === true) {
                            jQuery('.ApWait').hide();
                            swal("Success!", "Wallet Withdraw has been completed successfully!!", "success");
                            setTimeout(function() {
                                location.reload(true);
                            }, 2000);
                        } else {
                            jQuery('.ApWait').hide();
                            swal("Error!", "Somethings goes wrong! please try again", "error");
                            location.reload();
                        }
            
                    },
                    error: function(error) {
                        jQuery('.ApWait').hide();
                        swal("Error!", "Somethings goes wrong! please try again", "error");
                        location.reload();
                    }
                 });
            }*/

        /*});
   
}



	  jQuery('#max-amount').click(function() {
		  jQuery('#withdraw-amount').val(jQuery('#eth-balance').val());
	  })*/



});

if(jQuery('#withdrawForm').length > 0){
    jQuery(document).ready(function($){

        jQuery('#withdraw-amount').on("change keyup keypress input",function(event) { 
            if (event.which != 46 && (event.which < 47 || event.which > 59))
            {
                event.preventDefault();
                if ((event.which == 46) && (jQuery(this).indexOf('.') != -1)) {
                    event.preventDefault();
                }
            }
        });
        
        $('#withdrawForm').validate({
            ignore: "",
            rules: {
                withdrawAddress: {
                    required: true,
                },
                confirmAddress: {
                    required: true,
                    equalTo: "#withdraw-address"
                },
                withdrawAmount: {
                    required: true,
                    max: function() {
                        return parseFloat(jQuery('#eth-balance').val());
                    }
                },
            },
            messages: {
                withdrawAddress: {
                    required: "Please enter withdrawal address"
                },
                confirmAddress: {
                    required: "Please enter Confirm withdrawal address",
                    equalTo: "Please Enter Same address"
                },
                withdrawAmount: {
                    required: "Please enter withdrawal amount",
                    max: "Please enter wallet amount or below amount"
                },
            },
            submitHandler: function(form) {
                var withdrawAmt = jQuery("#withdraw-amount").val();
                var data = {
                    'action' : 'insert_transaction_history',
                    'toAddress': jQuery("#withdraw-address").val(),
                    'amount': jQuery("#withdraw-amount").val(),
                    'walletAdress': jQuery('#wallet-address').val(),
                    'from_walUserid': jQuery('#wallet-userid').val(),
                    
                };
                var regex = RegExp('^[0.0]+$');
                if(regex.test(withdrawAmt)) {
                    //alert('Please enter value to Proceed Withdrawal');
                    swal("Alert!", "Please enter valid value to proceed withdrawal", "error");
                    return false;
                }
               
                
                 jQuery.ajax({
                    url: jQuery('#adminurl').val(),
                    type: 'post',
                    data: data,
                    dataType: 'json',
                    beforeSend: function() {
                        jQuery('.ApWait').show();
                    },
                    success: function(response) {
                        
                        if (response.success === true) {
                            jQuery('.ApWait').hide();
                            swal("Success!", "Wallet Withdraw has been completed successfully!!", "success");
                            setTimeout(function() {
                                location.reload(true);
                            }, 2000);
                        } else {
                            jQuery('.ApWait').hide();
                            swal("Error!", "Somethings goes wrong! please try again", "error");
                            location.reload();
                        }
            
                    },
                    error: function(error) {
                        jQuery('.ApWait').hide();
                        swal("Error!", "Somethings goes wrong! please try again", "error");
                        location.reload();
                    }
                 });
            }
        });
    });
}
/* add aproval contract for resale product */

EThAppDeployApproval = {
    loadEtherium: async () => {
        if (typeof window.ethereum !== 'undefined') {
            if (jQuery('#contract-address').val()) {
                window.web3 = new Web3(window.ethereum);
                var network = window.ethereum.networkVersion;
                var metamask_network = jQuery('#metamask-network').val();
                if (network != metamask_network) {
                    if (metamask_network == 1) {
                        swal("Alert!", "Please change metamask network into Mainnet network", "error");
                    } else if (metamask_network == 42) {
                        swal("Alert!", "Please change metamask network into Kovan network", "error");
                    } else if (metamask_network == 3) {
                        swal("Alert!", "Please change metamask network into Ropsten network", "error");
                    } else if (metamask_network == 4) {
                        swal("Alert!", "Please change metamask network into Rinkeby network", "error");
                    } else if (metamask_network == 5) {
                        swal("Alert!", "Please change metamask network into Goerli network", "error");
                    }else if (metamask_network == 137) {
						swal("Alert!", "Please change metamask network into Polygon mainnet", "error");
                    }else if (metamask_network == 80001) {
						swal("Alert!", "Please change metamask network into Polygon mumbai", "error");
                    }
					return false;
                }else if (network == metamask_network){
					EThAppDeployApproval.requestAccount(ethereum);
				}else{
					swal("Alert!", "Something goes wrong please try again later!!", "error");
					return false;
				}

                
            } else {
                swal("Alert!", "Something goes wrong please try again later!!", "error");
				return false;
            }
        } else {
            alert(
                "Not able to locate an Ethereum connection, please install a Metamask wallet"
            );
        }
    },
    /****
     * Request A Account
     * **/
    requestAccount: async (ethereum) => {
        ethereum
            .request({
                method: 'eth_requestAccounts'
            })
            .then((resp) => {
                console.log(resp);
                console.log(jQuery('#billing_wallet_address').val());
                console.log(jQuery('#wallet_store_onprod_purchase').val());
				if((jQuery('#billing_wallet_address').val() == resp[0]) || (jQuery('#wallet_store_onprod_purchase').val() == resp[0]) ){ 
					
				

                const contract = new web3.eth.Contract([{ "inputs": [], "stateMutability": "nonpayable", "type": "constructor" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "account", "type": "address" }, { "indexed": true, "internalType": "address", "name": "operator", "type": "address" }, { "indexed": false, "internalType": "bool", "name": "approved", "type": "bool" }], "name": "ApprovalForAll", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "previousOwner", "type": "address" }, { "indexed": true, "internalType": "address", "name": "newOwner", "type": "address" }], "name": "OwnershipTransferred", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "operator", "type": "address" }, { "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": false, "internalType": "uint256[]", "name": "ids", "type": "uint256[]" }, { "indexed": false, "internalType": "uint256[]", "name": "values", "type": "uint256[]" }], "name": "TransferBatch", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": true, "internalType": "address", "name": "operator", "type": "address" }, { "indexed": true, "internalType": "address", "name": "from", "type": "address" }, { "indexed": true, "internalType": "address", "name": "to", "type": "address" }, { "indexed": false, "internalType": "uint256", "name": "id", "type": "uint256" }, { "indexed": false, "internalType": "uint256", "name": "value", "type": "uint256" }], "name": "TransferSingle", "type": "event" }, { "anonymous": false, "inputs": [{ "indexed": false, "internalType": "string", "name": "value", "type": "string" }, { "indexed": true, "internalType": "uint256", "name": "id", "type": "uint256" }], "name": "URI", "type": "event" }, { "inputs": [{ "internalType": "address", "name": "account", "type": "address" }, { "internalType": "uint256", "name": "id", "type": "uint256" }], "name": "balanceOf", "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address[]", "name": "accounts", "type": "address[]" }, { "internalType": "uint256[]", "name": "ids", "type": "uint256[]" }], "name": "balanceOfBatch", "outputs": [{ "internalType": "uint256[]", "name": "", "type": "uint256[]" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "account", "type": "address" }, { "internalType": "address", "name": "operator", "type": "address" }], "name": "isApprovedForAll", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "account", "type": "address" }], "name": "isApprovedForOwner", "outputs": [{ "internalType": "bool", "name": "approval", "type": "bool" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "receiver", "type": "address" }, { "internalType": "uint256", "name": "collectibleId", "type": "uint256" }, { "internalType": "uint256", "name": "ntokens", "type": "uint256" }, { "internalType": "bytes", "name": "IPFS_hash", "type": "bytes" }], "name": "mint", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "receiver", "type": "address" }, { "internalType": "uint256[]", "name": "collectibleIds", "type": "uint256[]" }, { "internalType": "uint256[]", "name": "ntokens", "type": "uint256[]" }, { "internalType": "bytes", "name": "IPFS_hash", "type": "bytes" }], "name": "mintBatch", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [], "name": "owner", "outputs": [{ "internalType": "address", "name": "", "type": "address" }], "stateMutability": "view", "type": "function" }, { "inputs": [], "name": "renounceOwnership", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "from", "type": "address" }, { "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256[]", "name": "ids", "type": "uint256[]" }, { "internalType": "uint256[]", "name": "amounts", "type": "uint256[]" }, { "internalType": "bytes", "name": "data", "type": "bytes" }], "name": "safeBatchTransferFrom", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "from", "type": "address" }, { "internalType": "address", "name": "to", "type": "address" }, { "internalType": "uint256", "name": "id", "type": "uint256" }, { "internalType": "uint256", "name": "amount", "type": "uint256" }, { "internalType": "bytes", "name": "data", "type": "bytes" }], "name": "safeTransferFrom", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "operator", "type": "address" }, { "internalType": "bool", "name": "approved", "type": "bool" }], "name": "setApprovalForAll", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "bool", "name": "approval", "type": "bool" }], "name": "setApprovalForOwner", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "bytes4", "name": "interfaceId", "type": "bytes4" }], "name": "supportsInterface", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "newOwner", "type": "address" }], "name": "transferOwnership", "outputs": [], "stateMutability": "nonpayable", "type": "function" }, { "inputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }], "name": "uri", "outputs": [{ "internalType": "string", "name": "", "type": "string" }], "stateMutability": "view", "type": "function" }], jQuery('#contract-address').val());


                contract.methods.isApprovedForOwner(resp[0]).call().then(function(result) {
                    if (result) {
                        productPublish('',resp[0]);

                    } else {
                        contract.methods.setApprovalForOwner(true).send({
                            from: resp[0],
                            gas: '2000000',
                            gasPrice: '20000000000'
                        }).then(function(result) {
                            if (result.status == true) {
                                productPublish(result.blockHash ,resp[0]);
                            } else {
                                swal("Alert!", 'Contract has not approved!! Please try again', "error");
                                jQuery('.ApWait').hide();

                            }
                        }).catch(function(error){
							jQuery('.ApWait').hide();
						});
                    }
                }); 

                setTimeout(function() { 
                    jQuery('.ApWait').show();
                }, 2000);


				}else {
					 swal("Alert!", "Please choose the last used Wallet Address Account.", "error");
				return false;
				}
                //EThAppDeploy.payNow(ethereum, resp[0]);
            })
            .catch((err) => {
                // Some unexpected error.
                console.log(err);
            });
    },
}
/*product publish */

function productPublish(txhash = '', metamaskAddress = '') {


    var url = jQuery('#url').val();
    var updatePrice = jQuery('#update-price').val();
    var pid = jQuery('#pid').val();
    var form_data = new FormData();
    form_data.append('updatePrice', updatePrice);
    form_data.append('pid', pid);
    form_data.append('action', 'publishProduct');
    form_data.append('txhash', txhash);
	form_data.append('metamaskAddress', metamaskAddress);
    jQuery.ajax({
        url: url,
        method: 'POST',
        data: form_data,
        dataType: 'json',
        contentType: false,
        processData: false,
        beforeSend: function() {
            jQuery('.ApWait').show();
        },
        success: function(results) {
            jQuery('.ApWait').hide();
            if (results.status == 'success') {
                swal("Success!", "Your product has been updated successfully!!", "success").then(okay => {
                    if (okay) {
                        window.location.href = results.url;
                    }
                });
                setTimeout(function() {
                    window.location.href = results.url;
                }, 2000);

            } else {
                swal("Error!", results.msg, "error");
            }

        },
        error: function(error) {
            jQuery('.ApWait').hide();
            swal("Alert!", "Somethings goes wrong! please try again", "error");
        }
    });


}
// product page testimonials slider
var base_url = window.location.origin;
jQuery(".cstmReviewsWrap.owl-carousel").owlCarousel({
    loop:false,
    nav:true,
    dots: false,
    margin: 0,
	navText: ["<img src="+base_url+"/wp-content/themes/ibidchildtheme/img/previous.png>","<img src="+base_url+"/wp-content/themes/ibidchildtheme/img/next.png>"],
    autoHeight:true,
    responsive:{
      0:{
          items:1.1,
		  margin: 30
      },
      600:{
          items:1,
      },
	  768:{
		  items: 2,
		  margin: 15
	  },
      1000:{
          items:3,
      }
    }
});



jQuery('#reviewFormOpen').on('click', function(){
	jQuery('#reviewFormModal').css('display', 'block');
});

jQuery('.reviewFormCloseBtn').on('click', function(){
	jQuery('#reviewFormModal').css('display', 'none');
});




jQuery(document).ready(function(){
	
	
	  /* **********************  passwordStrength meter customly set  *************************  */

		  jQuery( document ).on( 'keyup', '.woocommerce-account #reg_password ', function( event ) {
			if( jQuery( this ).val() != '' ) {
				jQuery("#password-strength-header").show();
				wdmChkPwdStrength(
					jQuery('.woocommerce-account #reg_password'),
					jQuery('.woocommerce-account #reg_password'),
					jQuery('.woocommerce-account #modal-log-in #password-strength-header'),
					jQuery('.woocommerce-account #modal-log-in button[type=submit]'),
					[] // blacklisted words
				);    
			} else{
				jQuery( '.woocommerce-account #modal-log-in small.cstm_woo_hint,.woocommerce-account #modal-log-in #password-strength-header' ).hide();
			}
			
		  }); 
	
		jQuery( 'body' ).on( 'keyup', '.lost_reset_password input[name=password_1]', function( event ) {
			if( jQuery( this ).val() != '' ) {
				jQuery(".lost_reset_password #password-strength").show();
				wdmChkPwdStrength(
					jQuery('.lost_reset_password input[name=password_1]'),
					jQuery('.lost_reset_password input[name=password_1]'),
					jQuery('.lost_reset_password #password-strength'),
					jQuery('.lost_reset_password button[type=submit]'),
					[] // blacklisted words
				);    
			} else{
			jQuery( '.lost_reset_password small.cstm_woo_hint,.lost_reset_password #password-strength' ).hide();
			}
			
		  }); 
	
	
	function wdmChkPwdStrength( $pwd , $confirmPwd , $strengthStatus, $submitBtn , blacklistedWords) {
		
		var pwd = $pwd.val(); 
		var confirmPwd = $confirmPwd.val();
		
		$submitBtn.attr( 'disabled', 'disabled' );
		$strengthStatus.removeClass( 'short bad good strong' );
	
		// calculate the password strength
		var pwdStrength = wp.passwordStrength.meter( pwd , blacklistedWords , confirmPwd  );
	
		// check the password strength
	   switch ( pwdStrength ) {
			case 2:
				$strengthStatus.addClass( 'bad' ).html( 'weak - Please enter a stronger password.' );
			break;
			case 3:
				$strengthStatus.addClass( 'good' ).html( 'Medium' );
			break;
			case 4:
				$strengthStatus.addClass( 'strong' ).html( 'Strong' );
			break;
			case 5:
				$strengthStatus.addClass( 'short' ).html( pwsL10n.mismatch );
			break;
			default:
				$strengthStatus.addClass( 'short' ).html( 'Very weak - Please enter a stronger password.' );
		}
		console.log(pwdStrength);
		if( pwdStrength < 3 ){
			jQuery( 'small.cstm_woo_hint' ).show();
		}else{
			jQuery( 'small.cstm_woo_hint' ).hide();
		}
		if ( 3 === pwdStrength ) {
			$submitBtn.removeAttr( 'disabled' );
		}
		return pwdStrength;
		
	}
	
	
	/* **********************  passwordStrength meter customly set  *************************  */
	
	

	jQuery('.modeltheme-modal').click(function(){
		if ( jQuery('body').hasClass('page-id-9')) { 
			jQuery(this).removeClass('modeltheme-show');
			window.location.href='/';
		}
		
		jQuery(this).removeClass('modeltheme-show');
		jQuery(this).find('form').trigger('reset');	
		jQuery(this).find('.status').html('');
		
		jQuery('.woocommerce-password-strength,.woocommerce-password-hint').hide();
	});

	jQuery('.modeltheme-content').click(function(e){
       e.stopPropagation();
    });

	jQuery('#withdrawModal').on('hidden.bs.modal', function () {
		jQuery(this).find('form').trigger('reset');	
		jQuery(this).find('.error').html('');
	});

    jQuery('#modal-log-in').on('hidden.bs.modal', function () {
         jQuery('form#register #valid_username').text(" ");
         jQuery('form#register .show-password-input').removeClass('display-password');
         });
	
	

	



if ( jQuery('body').hasClass('search')) {
	var cat_count = jQuery('.widget_product_categories').length;
	var search_count = jQuery('.widget_product_search').length;
	//console.log('category: '+cat_count+' Search: '+search_count);
	if(cat_count > 1){jQuery(this).find('.widget_product_categories').last().remove();}
	if(search_count > 1){jQuery(this).find('.widget_product_search').last().remove();}
  //jQuery(this).find('.widget_product_categories').last().remove();
  //jQuery(this).find('.widget_product_search').last().remove();  
}


if(jQuery('body').hasClass('single-product')){
	
	jQuery(this).find('.wpss_social_share_buttons').prepend('<p>Share this NFT on</p>');
}

    });

  
jQuery(document).ready(function(){
	jQuery('#login-modal').click(function(){
		 jQuery('#register')[0].reset();
		 jQuery(this).find('.status').html('');
		 jQuery('#reg_confirm_password').next("span.msg").remove();
		 jQuery('#password-strength-status').text(" ");
		 jQuery('#reg_password').next("span.msg").remove();
		 	jQuery('.woocommerce-password-strength,.woocommerce-password-hint').hide();
		 
	});
	jQuery('#register').click(function(){
		 jQuery('#login')[0].reset();
		 jQuery(this).find('.status').html('');
	});
	
	//jQuery('.products').equalHeights();
});





// jQuery.fn.equalHeights = function(){
// 	var max_height = 0;
// 	jQuery(this).each(function(){
// 		max_height = Math.max(jQuery(this).height(), max_height);
// 	});
// 	jQuery(this).each(function(){
// 		jQuery(this).height(max_height);
// 	});
// };





// jQuery(document).ready(function(){
//     jQuery('.padding-20-border').equalHeights();
// });


// /* ajax for price update and publish produc */
// jQuery(window).on('load',function(){
	
// 	jQuery('.padding-20-border').equalHeights();

	
// });



// jQuery(window).resize(function() {
// 	jQuery('.padding-20-border').equalHeights();
//jQuery('.product').equalHeights();
// });



/*jQuery(document).ready(function(){
    var e=[];
    jQuery(".Child-Flx-1").each(function(){
        e.push(jQuery(this).height())
    });
        var t=Math.max.apply(null,e);
        jQuery(".Child-Flx-1").height(t); 
    });
*/

jQuery(document).ready(function(){
/*$.noConflict();*/
 

    jQuery(document).on('click', '.remove-tr', function(){  
         jQuery(this).parents('#remove-row').remove();
    });
	jQuery('#register').click(function(){
		jQuery('span.msg ').hide();
	});

});





    
  jQuery(document).ready(function() {

    var cat_data = jQuery('.single-product .entry-summary .product_cat').text();
	if(cat_data.trim() != ''){
		 jQuery('.single-product .entry-summary .product_cat').text('Catergory: '+cat_data);
	}
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
               jQuery('.profile-pic').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    

   jQuery(".file-upload").on('change', function(){
        readURL(this);
    });
    
    jQuery(".Btn-Upload").on('click', function() {
      jQuery(".file-upload").click();
    });
	
	/*jQuery('.search-field').blur(function(){      
	  jQuery('.search-field').val('');
	  jQuery('#datafetch').html('');
      
    });*/
	
	jQuery( "#sumanForm" ).on('submit', function(e){
        e.preventDefault();
		var cat_name = jQuery('#product_cat').val();
		var prod_name = jQuery('#keyword').val();
		
		if(cat_name){
		window.location.href='/product-category/'+cat_name; 
		}
		else if(prod_name){
			prod_name = prod_name.replace(/\s+/g, '-');
			window.location.href='/product/'+prod_name; 
		}
		else{
			window.location.href='/shop/';
		}
	  
	});
	
	
});

jQuery(document).click(function (e) {
    var target = e.target;
    if (!jQuery(target).is('#suman') && !jQuery(target).parents().is('#suman')) {
		jQuery('#datafetch').html('');
        jQuery('#sumanForm').trigger("reset");
    }
});
/*
 jQuery(document).on('click', function(e) {	
    var container = jQuery('#suman');	
    if (!container.is(e.target) && container.has(e.target).length === 0) {
		jQuery('#datafetch').html('');
      jQuery(container).validate().resetForm();	  
	  	  
	  jQuery('form.header-search-form')[0].reset();
    };
  });
*/

jQuery(document).ready(function() {
jQuery(".chosen-select").chosen({
});



 jQuery('.modeltheme-trigger').click(function(){
       jQuery('#modal-log-in').modal('show');
      
    });

});



jQuery(document).ready(function() {
jQuery(".search-field").attr("autocomplete","off");



});



function checkPasswordStrength() {
	var number = /([0-9])/;
	var alphabets = /([a-zA-Z])/;
	var special_characters = /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/;
	
	if(jQuery('#reg_password').val().length<6) {
		jQuery('#password-strength-status').removeClass();
		jQuery('#password-strength-status').addClass('weak-password');
		jQuery('#password-strength-status').html("Weak (should be atleast 6 characters.)");
		jQuery('#reg_password').focus();
		return false;
	} else {  	
	    if(jQuery('#reg_password').val().match(number) && jQuery('#reg_password').val().match(alphabets) && jQuery('#reg_password').val().match(special_characters)) {            
			jQuery('#password-strength-status').removeClass();
			jQuery('#password-strength-status').addClass('strong-password');
			jQuery('#password-strength-status').html("Strong");
			return true;
        } else {
			jQuery('#password-strength-status').removeClass();
			jQuery('#password-strength-status').addClass('medium-password');
			jQuery('#password-strength-status').html("Medium (should include alphabets, numbers and special characters.)");
			jQuery('#reg_password').focus();
			return false;
        } 
	}
}

jQuery( document ).ajaxComplete(function() {
	if ( jQuery('body').hasClass('single-product')) { 
	//jQuery('form#uwa_private_msg_form')[0].reset();
	jQuery('form#uwa_private_msg_form').trigger("reset");
	//console.log('complete ajex: uwa_private_msg_form').trigger("reset");;
	}
  
});

jQuery( document ).ready(function() {
	jQuery(".price_label .from").each(function() {
		var text = jQuery(this).text();
		text = text.replace("ETH", "ETH ");
		jQuery(this).text(text);
	});
	jQuery(".price_label .to").each(function() {
		var text = jQuery(this).text();
		text = text.replace("ETH", "ETH ");
		jQuery(this).text(text);
	});
    jQuery('.custom-hide').attr('disabled',false);
});


function setEqualHeight(htmlSelector) {
	var eleHeight = 1;
	jQuery(htmlSelector).css('height', 'auto');
	jQuery(htmlSelector).each(function () {
	eleHeight = (eleHeight > jQuery(this).outerHeight()) ? eleHeight : jQuery(this).outerHeight();
	});
	jQuery(htmlSelector).css('height', eleHeight);
	var height = eleHeight  > 1 ? eleHeight : 450;
	jQuery(htmlSelector).css('height', height );
}
jQuery(window).on('load',function(){
	
	setEqualHeight("li.product");
	setEqualHeight("div.products-wrapper");
	setEqualHeight("div.thumbnail-and-details");
	setEqualHeight("body.single-charity .nfts-on-offer .products-height");
	
});
jQuery(document).ajaxStop(function(){
    if(jQuery('.woocommerce-cart').length == 1){
        jQuery('.woo_catalog_media_images').each(function(){
            if(jQuery(this).children('div').hasClass('ready-player-1')){
                if(jQuery(this).children('.green-audio-player').length == 0){
                    var classData = jQuery(this).children('div.ready-player-1').attr('class');
                       classData = classData.split(' ');
                        GreenAudioPlayer.init({
                        selector: '.'+classData[1],
                        stopOthersOnPlay: true
                        
                    });
                }
            }
            

            
        });
        
    }
  
       
	
});