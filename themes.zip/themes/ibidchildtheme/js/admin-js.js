setTimeout(function(){
	
var modal = document.getElementById("myModal");


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
	
  }
}
 
	
},2500);


function showHistory(userid){

	var url = jQuery('#adminurl').val();
	
	
	    jQuery.ajax({
        url: url,
        method: 'POST',
		data : { 'action' : 'transactionHistory', 'userid' : userid },
		 beforeSend: function() {
        jQuery('.ApWait').show();
		},
        success: function(results) {
			jQuery('.ApWait').hide();
			jQuery('#myModal').show();
			
			jQuery('#myModal .Umodal-content div').html(results);

		},
		error: function(error) {
        jQuery('.ApWait').hide();
		jQuery('#myModal').show();
		jQuery('#myModal .Umodal-content div').html('<h3>Somethings goes wrong! please try again</h3>');
	 
        }
	});
	
}

jQuery(document).ready(function($) {  
	if(jQuery('body').hasClass('users-php')){
		jQuery('body').append('<style>.ApWait{display: none;width: 100%;height: 100%;border: 0 solid black; position: fixed;top: 0;left: 0;padding: 2px; box-shadow: inset 0 0 0 8000px rgba(0, 0, 0, 0.30); z-index: 99999;} .loader_child{position:absolute;top:50%;left:50%;padding:15px; -webkit-transform:translate(-50%,-50%); -moz-transform:translate(-50%,-50%); -o-transform:translate(-50%,-50%); transform:translate(-50%,-50%); } #loading-bar-spinner.spinner { left: 50%;margin-left: -20px;top: 50%;margin-top: -20px; position: absolute; animation: loading-bar-spinner 500ms linear infinite; } #loading-bar-spinner.spinner .spinner-icon { width: 40px;height: 40px;border:  solid 4px transparent; border-top-color:  #2695FF; border-left-color: #2695FF; border-radius: 50%; -webkit-animation: initial; animation: initial; } @keyframes loading-bar-spinner { 0%   { transform: rotate(0deg);   transform: rotate(0deg); } 100% { transform: rotate(360deg); transform: rotate(360deg); } } .Umodal { display: none; /* Hidden by default */ position: fixed; /* Stay in place */ z-index: 1; /* Sit on top */ padding-top: 100px; /* Location of the box */ left: 0; top: 0; width: 100%; /* Full width */ height: 100%; /* Full height */ overflow: auto; /* Enable scroll if needed */ background-color: rgb(0,0,0); /* Fallback color */ background-color: rgba(0,0,0,0.4); /* Black w/ opacity */ } /* Modal Content */ .Umodal-content { background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 100%; max-width:1000px;} /* The Close Button */ .Uclose { color: #aaaaaa; float: right; font-size: 28px; font-weight: bold; } .Uclose:hover, .Uclose:focus { color: #000; text-decoration: none; cursor: pointer; } </style><div id="myModal" class="Umodal"><div class="Umodal-content"> <span class="Uclose">&times;</span> <div>Some text in the Modal..</div> </div> </div><div class="ApWait" style="display: none;"> <div class="loader_child"> <div id="loading-bar-spinner" class="spinner"> <div class="spinner-icon"></div> </div> </div> </div>');	
	}
	
	jQuery('span.Uclose').click(function(){
		
			jQuery('#myModal').hide();
		
		
	});
	
	
});
