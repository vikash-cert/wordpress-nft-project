<?php //Changing order status from pending to proceesing on stripe payment
add_action( 'woocommerce_order_status_completed', 'so_payment_complete', 10, 4 );
function so_payment_complete( $order_id ) {

      $order = wc_get_order( $order_id );
    foreach($order->get_items() as $item) {
		   $product = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
		   $product_name = $item['name'];
		   $resellby = get_post_meta($product->get_id(),'resellBy',true);
		 
		   if($resellby){
			    
			$vendor_id = WCV_Vendors::get_vendor_from_product( $product->get_id() );
				$user_meta = get_userdata($vendor_id);
				$user_roles = $user_meta->roles;
				$commision = get_post_meta($product->get_id(),'pv_commission_rate',true);
				$commision = $commision?$commision:get_option('wcvendors_vendor_commission_rate'); // Global comission rate will be pick from plugin
				// echo $commision;
				// exit();
				$adminComission = get_option('wcvendors_vendor_admin_fee');
				$productRoyaltyCommission = get_post_meta($product->get_id(),'pv_royalty_commission_rate',true);
				if($productRoyaltyCommission) {
					$royaltyComission  = $productRoyaltyCommission;
				} else {

					$royaltyComission = get_option('wcvendors_vendor_creatore_royalty');
				}
				$totalAmount =  $adminComission + $royaltyComission;
				 if(in_array("vendor", $user_roles)){
					 $adminComission = $adminComission;
				 }else{
					 $adminComission = $totalAmount;
				 }
				 
				 if($totalAmount == 0){
					 $commision = $commision;
				 }else{
					 $commision = $totalAmount;
				 }
				 if($commision){
					$commison_admin =  $commision; 
				 }else{
					$commison_admin = '0'; 
				 }
				  
				 $productPrice = $product->get_price();
			
				 $currency = get_woocommerce_currency();
				 $totalamount = $currency.' '.$productPrice;
			
			  if($commision){
				$percentage = $commision / 100 ;
				$percentageOfresellAmount = $percentage * $productPrice;
				$conversion_rate = get_option('convertion_rate2');
				$percentageOfresellAmount = $productPrice - $percentageOfresellAmount;
				
				/*if($conversion_rate){
					//$total = $percentageOfresellAmount * round($conversion_rate->ETH,5);
					$total = $percentageOfresellAmount * round($conversion_rate->USD,5);	
			    }else{
					$total = '';				
				}*/

					$total = $percentageOfresellAmount;
					$total =  number_format($total,5);
					$conversion_rate = get_option('convertion_rate2');
					$eth = $conversion_rate->ETH;
					$normal_ETH = $total*$eth;

				 $balance = get_user_meta($resellby , 'balance',true); 
				if($balance){
					 $total2 = $total + $balance; 
					
					 
					update_user_meta($resellby,'balance',$total2);
				}else{
					update_user_meta($resellby,'balance',$total);
					
				}  
			  }else{
				  	$conversion_rate = get_option('convertion_rate2');
				  	
			 if($conversion_rate){
				$total = $productPrice * round($conversion_rate->ETH,5);
			  }else{
				  $total = '';
			  }
			  	$total =  number_format($total,5);

				  $balance = get_user_meta($resellby , 'balance',true);
				if($balance){
					$total2 = $total + $balance;
					
					update_user_meta($resellby,'balance',$total2);
				}else{
					update_user_meta($resellby,'balance',$total);
					
				}  
				  
				  
			  }
			  
			  $walletAddress = get_user_meta($resellby,'walletAddress',true);

			  $txhash = get_post_meta($order_id,'txhash',true);
			  
			  $fromAddress = AdminWallletAddress;
			  global $wpdb;	
			 
			 /* add coloumn in wp_wallet_transaction_history table */

              $walletTable = $wpdb->get_row("SELECT * FROM wp_wallet_transaction_history");
				//Add column if not present.
				if(!isset($walletTable->orderId)){
				$wpdb->query("ALTER TABLE wp_wallet_transaction_history ADD orderId VARCHAR(250) NULL DEFAULT '' ");
				}
				if(!isset($walletTable->adminCommission)){
				$wpdb->query("ALTER TABLE wp_wallet_transaction_history ADD adminCommission VARCHAR(250) NULL DEFAULT '' ");
				}
				if(!isset($walletTable->totalAmount)){
				$wpdb->query("ALTER TABLE wp_wallet_transaction_history ADD totalAmount VARCHAR(250) NULL DEFAULT '' ");
				}
              /* add coloumn in wp_wallet_transaction_history table end*/				
					
			  $sql_insert = 'INSERT INTO  `wp_wallet_transaction_history` (`userid`,`fromAddress`,`toAddress`,`amount`,`txHash`,`type`,`orderId`,`totalAmount`,`adminCommission`)VALUES("' . $resellby. '","' . $fromAddress. '","' . $walletAddress. '","' . $total. '","' . $txhash. '","resellproductamount","' . $order_id. '","' . $totalamount. '","'.$adminComission.'%")';
			 
               $wpdb->query($sql_insert);
			     /*mail shoot when product purchase */
			 //$date = date('l jS \of F Y h:i:s A');
			$date = current_time( 'l, F jS, Y h:i:s A');
			 $user = get_user_by( 'ID', $resellby );
			 $userData = $user->data;
			 $user_email = $userData->user_email;
			$username = $userData->user_login;

			 $subject = "Credit";

			 $toplogo = get_site_url().'/wp-content/uploads/2021/11/citiesabc-blue-logo.png';
			 $logo = '<img src="'.$toplogo.'" alt="Citiesabc" style="display:block; height: auto; margin:0 auto; max-width:260px; ">';
			 $subject = 'Credit';
			 $messsage = '<html><body style="background:#efefef;">';
			 $messsage .= '<table class="table" cellpadding="0" cellspacing="0" width="850" align="center" style=" border-radius: 4px; overflow: hidden;">';
			 $messsage .= '<tbody>	
							<tr>
						<td colspan="2" style="background:#f7f7f7;padding-bottom: 20px;border: 1px solid #17134b;">
							<table class="header" cellpadding="0" cellspacing="0" width="100%" style="padding: 30px 40px;">
								<tbody>
									<tr><td>&nbsp;</td></tr>
									<tr><td style="color: #fff; font-family: sans-serif; font-size: 32px; font-weight: normal; letter-spacing: 1px; line-height: 40px;text-align: center;">' . $logo. '</td></tr>
									<tr><td>&nbsp;</td></tr>
								</tbody>
							</table>
						</td>
					</tr>';
			 $messsage .= '<tr class="col-text-tr" >
						 <td class="col-text" colspan="2" 
							 style="font-family: sans-serif;font-family: sans-serif;background:#fff;
							 padding: 30px 40px;
							 font-size: 16px;">
							 <h4 style="font-size: 25px; font-weight: bold;text-align: center;background:#393e7c;width:100%;color:#ffffff">' . $subject. '</h4>			
							 <p>Dear '.$username.'</p>
							 <p>Your account is credited with a value '.number_format($total,2).' USD ('.convert_usd_to_eth($total).' ETH )  from '.$fromAddress.' at '. $date.'.</p>
							 <p>Thank you</p>
							 <br><p>-- Citiesabc Team</p>
						 </td>
					 </tr>
					 </tbody>
					 </table></body></html>';			
				send_mail('Credit',$messsage,$user_email);		
				
			 }
		
		}
    
}


add_filter('comment_flood_filter', '__return_false');


add_action('admin_head', 'remomveCommisionTab');

function remomveCommisionTab() {
  echo '<style>
    .product_data .commission_tab{display:none!important;}
  </style>';
}





